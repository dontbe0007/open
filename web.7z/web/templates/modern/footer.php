            </div>
        </div>
    </nav>

    <div class="container">
        <!-- 页面内容将在这里插入 -->
        <?php
        // 如果定义了$page_content，则输出
        if (isset($page_content)) {
            echo $page_content;
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php include dirname(dirname(__FILE__)) . '/site_footer.php'; ?>
</body>
</html>

