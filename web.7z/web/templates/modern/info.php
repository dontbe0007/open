<?php
/**
 * 现代简约模板信息
 */
return [
    'name' => '现代简约',
    'description' => '现代简约风格，渐变背景，圆角设计，视觉效果更佳',
    'version' => '1.0',
    'author' => 'System',
    'preview' => 'templates/modern/preview.jpg'
];


