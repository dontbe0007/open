<?php
/**
 * 默认模板 - 头部文件
 */
if (!function_exists('get_site_setting')) {
    require_once dirname(dirname(__FILE__)) . '/get_site_setting.php';
}

$site_name = get_site_setting('site_name', '仓库管理系统');
$site_logo = get_site_setting('site_logo', '');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title><?php echo htmlspecialchars($site_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card { 
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .btn {
            border-radius: 5px;
        }
        .form-control {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
        .plan-card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .plan-info {
            flex: 1;
            margin-bottom: 15px;
        }
        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }
        .info-label {
            color: #666;
        }
        .info-value {
            font-weight: 500;
        }
        .product-code {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }
        .plan-name {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }
        .plan-actions {
            margin-top: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 10px;
        }
        .plan-actions .btn {
            padding: 8px 12px;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .card-header {
                flex-direction: column;
                align-items: flex-start !important;
                gap: 10px;
            }
            .card-header h5 {
                width: 100%;
                margin-bottom: 0;
            }
            .date-query-form {
                width: 100%;
                flex-wrap: wrap;
            }
            .date-query-form input[type="date"] {
                flex: 1;
                min-width: 120px;
                max-width: none !important;
            }
            .date-query-form .btn {
                flex: 0 0 auto;
            }
            .d-flex.justify-content-between {
                flex-direction: column;
                gap: 15px;
            }
            .nav-buttons {
                flex-direction: row;
                flex-wrap: wrap;
                width: 100%;
                justify-content: flex-start;
            }
            .nav-buttons .btn {
                flex: 1;
                min-width: 120px;
                margin-bottom: 5px;
            }
            .plan-card {
                padding: 12px;
            }
            .info-item {
                font-size: 13px;
            }
            .plan-actions .btn {
                padding: 8px 15px;
            }
        }
    </style>
    <?php include dirname(dirname(__FILE__)) . '/site_header.php'; ?>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <?php if (!empty($site_logo) && file_exists($site_logo)): ?>
                    <img src="<?php echo htmlspecialchars($site_logo); ?>" alt="Logo" style="max-height: 30px; margin-right: 10px;">
                <?php endif; ?>
                <?php echo htmlspecialchars($site_name); ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <!-- 导航菜单内容将由页面提供 -->
