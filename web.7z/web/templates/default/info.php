<?php
/**
 * 默认模板信息
 */
return [
    'name' => '默认模板',
    'description' => '经典的默认风格，简洁实用',
    'version' => '1.0',
    'author' => 'System',
    'preview' => 'templates/default/preview.jpg'
];


