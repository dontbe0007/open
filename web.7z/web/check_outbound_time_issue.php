<?php
/**
 * 检查出库时间问题
 * 诊断脚本
 */
require_once 'config.php';

// 检查特定时间的出库记录
$check_date = '2025-12-24';
$check_time_start = '19:00:00';
$check_time_end = '19:30:00';

echo "<h2>出库时间问题诊断</h2>";
echo "<p>检查日期：{$check_date} {$check_time_start} - {$check_time_end}</p>";

try {
    // 检查该时间段的所有出库记录
    $stmt = $pdo->prepare("
        SELECT 
            o.id,
            o.outbound_date,
            o.outbound_quantity,
            o.remark,
            p.product_code,
            u.username,
            DATE(o.outbound_date) as outbound_date_only,
            TIME(o.outbound_date) as outbound_time_only
        FROM outbound_records o
        INNER JOIN production_plans p ON o.plan_id = p.id
        LEFT JOIN users u ON o.user_id = u.id
        WHERE DATE(o.outbound_date) = ?
        AND TIME(o.outbound_date) >= ? AND TIME(o.outbound_date) <= ?
        ORDER BY o.outbound_date ASC
    ");
    $stmt->execute([$check_date, $check_time_start, $check_time_end]);
    $records = $stmt->fetchAll();
    
    echo "<h3>找到 " . count($records) . " 条记录</h3>";
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>出库时间</th><th>日期</th><th>时间</th><th>数量</th><th>备注</th><th>产品编码</th><th>操作人</th></tr>";
    
    foreach ($records as $record) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($record['id']) . "</td>";
        echo "<td>" . htmlspecialchars($record['outbound_date']) . "</td>";
        echo "<td>" . htmlspecialchars($record['outbound_date_only']) . "</td>";
        echo "<td>" . htmlspecialchars($record['outbound_time_only']) . "</td>";
        echo "<td>" . htmlspecialchars($record['outbound_quantity']) . "</td>";
        echo "<td>" . htmlspecialchars($record['remark'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($record['product_code'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($record['username'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 检查MySQL时区设置
    echo "<h3>MySQL时区设置</h3>";
    $tz_stmt = $pdo->query("SELECT @@global.time_zone AS global_tz, @@session.time_zone AS session_tz, NOW() AS mysql_now");
    $tz_info = $tz_stmt->fetch();
    echo "<p>全局时区：{$tz_info['global_tz']}</p>";
    echo "<p>会话时区：{$tz_info['session_tz']}</p>";
    echo "<p>MySQL当前时间：{$tz_info['mysql_now']}</p>";
    
    // 检查PHP时区
    echo "<h3>PHP时区设置</h3>";
    echo "<p>PHP时区：" . date_default_timezone_get() . "</p>";
    echo "<p>PHP当前时间：" . date('Y-m-d H:i:s') . "</p>";
    
    // 检查是否有记录使用了默认时间（可能没有指定outbound_date）
    echo "<h3>检查可能的问题记录</h3>";
    $problem_stmt = $pdo->prepare("
        SELECT 
            o.id,
            o.outbound_date,
            o.created_at,
            o.outbound_quantity,
            o.remark,
            p.product_code
        FROM outbound_records o
        INNER JOIN production_plans p ON o.plan_id = p.id
        WHERE DATE(o.outbound_date) = ?
        AND TIME(o.outbound_date) >= ? AND TIME(o.outbound_date) <= ?
        AND ABS(TIMESTAMPDIFF(SECOND, o.outbound_date, o.created_at)) > 5
        ORDER BY o.outbound_date ASC
    ");
    $problem_stmt->execute([$check_date, $check_time_start, $check_time_end]);
    $problem_records = $problem_stmt->fetchAll();
    
    if (count($problem_records) > 0) {
        echo "<p style='color: red;'>⚠️ 发现 " . count($problem_records) . " 条可能的问题记录（outbound_date 和 created_at 时间差超过5秒）</p>";
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>outbound_date</th><th>created_at</th><th>时间差(秒)</th><th>数量</th><th>备注</th></tr>";
        foreach ($problem_records as $pr) {
            $time_diff = abs(strtotime($pr['outbound_date']) - strtotime($pr['created_at']));
            echo "<tr>";
            echo "<td>" . htmlspecialchars($pr['id']) . "</td>";
            echo "<td>" . htmlspecialchars($pr['outbound_date']) . "</td>";
            echo "<td>" . htmlspecialchars($pr['created_at']) . "</td>";
            echo "<td>" . $time_diff . "</td>";
            echo "<td>" . htmlspecialchars($pr['outbound_quantity']) . "</td>";
            echo "<td>" . htmlspecialchars($pr['remark'] ?? '') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: green;'>✓ 未发现明显的时间问题</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>错误：" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

