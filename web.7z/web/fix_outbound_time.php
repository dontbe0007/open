<?php
/**
 * 修复出库记录时间
 * 检查并修复时间错误的出库记录
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$messages = [];
$warnings = [];
$errors = [];
$fixed_count = 0;

// 获取最近24小时的出库记录，检查时间问题
try {
    // 获取最近24小时的记录
    $records = $pdo->query("
        SELECT id, outbound_date, created_at, remark, outbound_quantity
        FROM outbound_records 
        WHERE outbound_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ORDER BY id DESC
        LIMIT 50
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    $messages[] = "找到 " . count($records) . " 条最近24小时的出库记录";
    
    // 分析时间问题
    $php_time = time();
    $problematic_records = [];
    
    foreach ($records as $record) {
        $record_time = strtotime($record['outbound_date']);
        $time_diff = $php_time - $record_time;
        $hours_diff = $time_diff / 3600;
        
        // 如果时间差在7-9小时之间，可能是UTC时间（应该+8小时）
        if ($hours_diff > 7 && $hours_diff < 9) {
            $problematic_records[] = [
                'id' => $record['id'],
                'current_time' => $record['outbound_date'],
                'should_be' => date('Y-m-d H:i:s', $record_time + 8*3600),
                'hours_off' => $hours_diff
            ];
        }
    }
    
    if (!empty($problematic_records)) {
        $warnings[] = "发现 " . count($problematic_records) . " 条可能时间错误的记录（相差约8小时）";
        
        // 显示问题记录
        echo "<h4>问题记录列表：</h4>";
        echo "<table class='table table-sm'>";
        echo "<thead><tr><th>ID</th><th>当前时间</th><th>应该为</th><th>差异</th></tr></thead>";
        echo "<tbody>";
        foreach ($problematic_records as $prob) {
            echo "<tr>";
            echo "<td>{$prob['id']}</td>";
            echo "<td>{$prob['current_time']}</td>";
            echo "<td>{$prob['should_be']}</td>";
            echo "<td>" . number_format($prob['hours_off'], 2) . " 小时</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
    } else {
        $messages[] = "✓ 未发现明显的时间错误记录";
    }
    
    // 处理修复请求
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fix_records'])) {
        $fix_hours = isset($_POST['fix_hours']) ? (float)$_POST['fix_hours'] : 8;
        $fix_seconds = $fix_hours * 3600;
        
        try {
            $pdo->beginTransaction();
            
            // 修复最近24小时的记录，将时间向前调整
            $update_sql = "
                UPDATE outbound_records 
                SET outbound_date = DATE_ADD(outbound_date, INTERVAL ? SECOND),
                    created_at = DATE_ADD(created_at, INTERVAL ? SECOND)
                WHERE outbound_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                AND outbound_date < DATE_SUB(NOW(), INTERVAL ? HOUR)
            ";
            
            $stmt = $pdo->prepare($update_sql);
            $stmt->execute([$fix_seconds, $fix_seconds, $fix_hours - 1]);
            $fixed_count = $stmt->rowCount();
            
            $pdo->commit();
            
            $messages[] = "✓ 已修复 {$fixed_count} 条记录的时间";
            $messages[] = "✓ 时间调整: +" . number_format($fix_hours, 2) . " 小时";
            
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = "✗ 修复失败: " . $e->getMessage();
        }
    }
    
    // 处理修复特定记录
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fix_specific']) && isset($_POST['record_ids'])) {
        $record_ids = explode(',', $_POST['record_ids']);
        $record_ids = array_map('intval', $record_ids);
        $record_ids = array_filter($record_ids);
        
        if (!empty($record_ids)) {
            try {
                $pdo->beginTransaction();
                
                $fix_hours = isset($_POST['fix_hours']) ? (float)$_POST['fix_hours'] : 8;
                $fix_seconds = $fix_hours * 3600;
                
                $placeholders = implode(',', array_fill(0, count($record_ids), '?'));
                $update_sql = "
                    UPDATE outbound_records 
                    SET outbound_date = DATE_ADD(outbound_date, INTERVAL ? SECOND),
                        created_at = DATE_ADD(created_at, INTERVAL ? SECOND)
                    WHERE id IN ($placeholders)
                ";
                
                $params = array_merge([$fix_seconds, $fix_seconds], $record_ids);
                $stmt = $pdo->prepare($update_sql);
                $stmt->execute($params);
                $fixed_count = $stmt->rowCount();
                
                $pdo->commit();
                
                $messages[] = "✓ 已修复 {$fixed_count} 条指定记录的时间";
                
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = "✗ 修复失败: " . $e->getMessage();
            }
        }
    }
    
} catch (PDOException $e) {
    $errors[] = "✗ 查询失败: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修复出库记录时间</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 1000px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .message {
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .message.warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .action-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        table {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">🕐 修复出库记录时间</h2>
        
        <!-- 消息显示 -->
        <?php foreach ($messages as $msg): ?>
            <div class="message success"><?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <?php foreach ($warnings as $msg): ?>
            <div class="message warning"><?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <?php foreach ($errors as $msg): ?>
            <div class="message error"><?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <!-- 修复操作 -->
        <?php if (!empty($problematic_records)): ?>
            <div class="action-box">
                <h5>修复最近24小时的记录</h5>
                <p>将最近24小时中时间错误的记录向前调整8小时（UTC转北京时间）</p>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">时间调整（小时）:</label>
                        <input type="number" name="fix_hours" class="form-control" value="8" step="0.1" required>
                        <small class="form-text text-muted">通常为8小时（UTC转北京时间）</small>
                    </div>
                    <button type="submit" name="fix_records" class="btn btn-warning" 
                            onclick="return confirm('确定要修复最近24小时的记录时间吗？\n\n此操作将调整记录时间，请谨慎操作！');">
                        修复最近24小时的记录
                    </button>
                </form>
            </div>
            
            <div class="action-box">
                <h5>修复指定记录</h5>
                <p>只修复上面列出的问题记录</p>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">记录ID（逗号分隔）:</label>
                        <input type="text" name="record_ids" class="form-control" 
                               value="<?php echo implode(',', array_column($problematic_records, 'id')); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">时间调整（小时）:</label>
                        <input type="number" name="fix_hours" class="form-control" value="8" step="0.1" required>
                    </div>
                    <button type="submit" name="fix_specific" class="btn btn-primary" 
                            onclick="return confirm('确定要修复这些指定记录的时间吗？');">
                        修复指定记录
                    </button>
                </form>
            </div>
        <?php endif; ?>
        
        <div class="mt-4">
            <a href="check_time.php" class="btn btn-secondary">返回时间检测</a>
            <a href="index.php" class="btn btn-primary">返回主页</a>
        </div>
    </div>
</body>
</html>



