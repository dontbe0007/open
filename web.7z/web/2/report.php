<?php
session_start();
require_once 'config.php';

// 检查登录状态
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 获取用户信息
$user_id = $_SESSION['user_id'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 获取日期范围
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// 获取报表数据
try {
    if ($is_admin || $is_storage) {
        $stmt = $pdo->prepare("
            SELECT 
                p.id,
                p.plan_name,
                p.product_code,
                p.created_at as plan_date,
                p.planned_quantity,
                p.created_at,
                u.username as user_name,
                COALESCE(SUM(o.outbound_quantity), 0) as total_outbound,
                (p.planned_quantity - COALESCE(SUM(o.outbound_quantity), 0)) as remaining_quantity,
                (
                    SELECT GROUP_CONCAT(
                        CONCAT(
                            o2.outbound_date, '|',
                            o2.outbound_quantity, '|',
                            u2.username
                        ) SEPARATOR '||'
                    )
                    FROM outbound_records o2
                    LEFT JOIN users u2 ON o2.user_id = u2.id
                    WHERE o2.plan_id = p.id
                    ORDER BY o2.outbound_date DESC
                ) as outbound_details
            FROM production_plans p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN outbound_records o ON p.id = o.plan_id
            WHERE DATE(p.created_at) BETWEEN ? AND ?
            GROUP BY p.id, p.plan_name, p.product_code, p.created_at, p.planned_quantity, u.username
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$start_date, $end_date]);
    } else {
        $stmt = $pdo->prepare("
            SELECT 
                p.id,
                p.plan_name,
                p.product_code,
                p.created_at as plan_date,
                p.planned_quantity,
                p.created_at,
                COALESCE(SUM(o.outbound_quantity), 0) as total_outbound,
                (p.planned_quantity - COALESCE(SUM(o.outbound_quantity), 0)) as remaining_quantity,
                (
                    SELECT GROUP_CONCAT(
                        CONCAT(
                            o2.outbound_date, '|',
                            o2.outbound_quantity, '|',
                            u2.username
                        ) SEPARATOR '||'
                    )
                    FROM outbound_records o2
                    LEFT JOIN users u2 ON o2.user_id = u2.id
                    WHERE o2.plan_id = p.id
                    ORDER BY o2.outbound_date DESC
                ) as outbound_details
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id
            WHERE p.user_id = ? AND DATE(p.created_at) BETWEEN ? AND ?
            GROUP BY p.id, p.plan_name, p.product_code, p.created_at, p.planned_quantity
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$user_id, $start_date, $end_date]);
    }
    $plans = $stmt->fetchAll();

    // 计算统计数据
    $total_plans = count($plans);
    $total_quantity = 0;
    $total_outbound = 0;
    $completion_rate = 0;

    foreach ($plans as $plan) {
        $total_quantity += $plan['planned_quantity'];
        $total_outbound += $plan['total_outbound'];
    }

    if ($total_quantity > 0) {
        $completion_rate = round(($total_outbound / $total_quantity) * 100, 2);
    }
} catch(PDOException $e) {
    $error = "获取报表数据失败：" . $e->getMessage();
    $plans = [];
    $total_plans = 0;
    $total_quantity = 0;
    $total_outbound = 0;
    $completion_rate = 0;
}

// 初始化错误变量
if (!isset($error)) {
    $error = '';
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>一键报表 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .plan-card { 
            margin-bottom: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            background-color: white;
            overflow: hidden;
        }
        .plan-header {
            background-color: #f8f9fa;
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .plan-body {
            padding: 15px;
        }
        .plan-info {
            margin-bottom: 15px;
        }
        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 8px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        .outbound-records-list {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
        }
        .outbound-record-item {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 6px 10px;
            margin: 2px;
        }
        .outbound-quantity {
            font-weight: 600;
            font-size: 15px;
            color: #007bff;
            background-color: #e7f3ff;
            padding: 4px 8px;
            border-radius: 4px;
            min-width: 50px;
            text-align: center;
        }
        .outbound-remark {
            font-weight: 500;
            font-size: 14px;
            color: #6c757d;
            background-color: #f8f9fa;
            padding: 4px 10px;
            border-radius: 4px;
            border-left: 2px solid #dee2e6;
        }
        .alert {
            border-radius: 10px;
        }
        @media print {
            .plan-card {
                break-inside: avoid;
                margin-bottom: 20px;
            }
            .no-print {
                display: none;
            }
        }
        #copyContent {
            position: absolute;
            left: -9999px;
        }
        .header-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .header-buttons .btn {
            flex: 1;
            min-width: 120px;
            white-space: nowrap;
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .container {
                padding-left: 10px;
                padding-right: 10px;
            }
            .navbar {
                padding: 0.5rem 1rem;
            }
            .navbar-collapse {
                margin-top: 10px;
            }
            .navbar-nav {
                padding: 10px 0;
            }
            .nav-link {
                padding: 8px 15px;
            }
            .d-flex.justify-content-between {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start !important;
            }
            .d-flex.gap-2 {
                width: 100%;
                flex-wrap: wrap;
            }
            .d-flex.gap-2 .btn {
                flex: 1 1 auto;
                min-width: 120px;
            }
            .card-body .d-flex.gap-2 {
                flex-direction: column;
            }
            .card-body .d-flex.gap-2 .form-control,
            .card-body .d-flex.gap-2 .btn {
                width: 100%;
                margin-bottom: 8px;
            }
            .card-body .d-flex.gap-2 .align-self-center {
                display: none;
            }
            .product-info {
                grid-template-columns: 90px 1fr;
                gap: 6px;
            }
            .info-line {
                font-size: 13px;
                padding: 6px 0;
                word-break: break-word;
                overflow-wrap: break-word;
            }
            .info-line:nth-child(odd) {
                font-size: 12px;
            }
            .report-section {
                padding: 12px;
                margin-bottom: 15px;
            }
            .outbound-records-list {
                gap: 6px;
                width: 100%;
            }
            .outbound-record-item {
                padding: 5px 8px;
                gap: 4px;
                flex-wrap: wrap;
                width: 100%;
                max-width: 100%;
            }
            .outbound-quantity {
                font-size: 14px;
                padding: 3px 6px;
                min-width: 45px;
                flex-shrink: 0;
            }
            .outbound-remark {
                font-size: 12px;
                padding: 3px 8px;
                flex: 1;
                min-width: 0;
                word-break: break-word;
            }
            .card-header h5 {
                font-size: 16px;
            }
            h1.h3 {
                font-size: 20px;
            }
        }
        @media (max-width: 480px) {
            .product-info {
                grid-template-columns: 80px 1fr;
                gap: 4px;
            }
            .info-line {
                font-size: 12px;
                padding: 4px 0;
            }
            .info-line:nth-child(odd) {
                font-size: 11px;
            }
            .outbound-record-item {
                flex-direction: column;
                align-items: flex-start;
            }
            .outbound-quantity,
            .outbound-remark {
                width: 100%;
            }
        }
        .report-section {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .product-info {
            display: grid;
            grid-template-columns: 140px 1fr;
            gap: 8px;
            align-items: start;
        }
        .info-line {
            padding: 8px 0;
            font-size: 14px;
            font-weight: 500;
            word-break: break-word;
        }
        .info-line:nth-child(odd) {
            color: #666;
        }
        .info-line:nth-child(even) {
            color: #333;
            font-weight: 600;
        }
        .card-title {
            font-weight: 600;
        }
        .display-6 {
            font-weight: 600;
        }
        @media print {
            .navbar, .btn, .card-header {
                display: none !important;
            }
            .card {
                border: none !important;
                box-shadow: none !important;
            }
            .card-body {
                padding: 0 !important;
            }
            .report-section {
                page-break-inside: avoid;
                border: none;
                padding: 0;
                margin-bottom: 30px;
            }
        }
        .outbound-date-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 10px;
        }
        .outbound-date {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
            padding-bottom: 5px;
            border-bottom: 1px solid #dee2e6;
        }
        .outbound-record-card {
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 8px;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .outbound-product-code {
            font-weight: 500;
            color: #333;
        }
        .outbound-quantity {
            font-weight: 600;
            color: #0d6efd;
        }
        .outbound-record-card:last-child {
            margin-bottom: 0;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .card {
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="report.php">一键报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="js.php">尾数计算</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="repeat_check.php">重复检测</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
        </div>
      </div>
    </nav>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">一键报表</h1>
            <div class="d-flex gap-2">
                <button onclick="copyReport()" class="btn btn-success">一键复制</button>
                <a href="index.php" class="btn btn-secondary">返回主页</a>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- 日期查询表单 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">选择日期范围</h5>
            </div>
            <div class="card-body">
                <form method="GET" class="d-flex gap-2">
                    <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>" max="<?php echo date('Y-m-d'); ?>" required>
                    <span class="align-self-center">至</span>
                    <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>" max="<?php echo date('Y-m-d'); ?>" required>
                    <button type="submit" class="btn btn-primary">查询</button>
                </form>
            </div>
        </div>

        <div id="reportContent">
            <!-- 统计信息 -->
            <!-- 删除原有四个卡片统计信息的HTML结构，直接进入详细数据部分 -->
            <!-- 详细数据 -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">出库日报表</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($plans as $plan): ?>
                    <div class="report-section mb-4">
                        <div class="product-info">
                            <div class="info-line">计划名称：</div>
                            <div class="info-line"><?php echo htmlspecialchars($plan['plan_name']); ?></div>
                            <div class="info-line">产品编号：</div>
                            <div class="info-line"><?php echo htmlspecialchars($plan['product_code'] ?? '未设置'); ?></div>
                            <div class="info-line">计划数量：</div>
                            <div class="info-line"><?php echo $plan['planned_quantity']; ?> 个</div>
                            <div class="info-line">已出库数量：</div>
                            <div class="info-line"><?php echo $plan['total_outbound']; ?> 个</div>
                            <div class="info-line">剩余数量：</div>
                            <div class="info-line"><?php echo max(0, $plan['remaining_quantity']); ?> 个</div>
                            <div class="info-line">出库记录</div>
                            <div class="info-line">
                                <div class="outbound-records-list">
                                <?php
                                try {
                                    if ($is_admin || $is_storage) {
                                        $stmt = $pdo->prepare("
                                                SELECT outbound_quantity, remark 
                                            FROM outbound_records 
                                            WHERE plan_id = ? 
                                            ORDER BY outbound_date ASC
                                        ");
                                        $stmt->execute([$plan['id']]);
                                    } else {
                                        $stmt = $pdo->prepare("
                                                SELECT outbound_quantity, remark 
                                            FROM outbound_records 
                                            WHERE plan_id = ? AND user_id = ? 
                                            ORDER BY outbound_date ASC
                                        ");
                                        $stmt->execute([$plan['id'], $user_id]);
                                    }
                                        $outbound_records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                        foreach ($outbound_records as $record) {
                                            $quantity = $record['outbound_quantity'];
                                            $remark = $record['remark'] ?? '';
                                            echo '<span class="outbound-record-item">';
                                            echo '<span class="outbound-quantity">' . htmlspecialchars($quantity) . '</span>';
                                            if (!empty($remark)) {
                                                echo '<span class="outbound-remark">' . htmlspecialchars($remark) . '</span>';
                                            }
                                            echo '</span>';
                                        }
                                } catch(PDOException $e) {
                                    echo '<div class="text-danger">获取出库记录失败</div>';
                                }
                                ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- 用于复制的隐藏文本区域 -->
    <textarea id="copyContent" readonly></textarea>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function copyReport() {
        let reportText = '';
        const reportSections = document.querySelectorAll('.report-section');
        
        reportSections.forEach(section => {
            const planName = section.querySelector('.info-line:nth-child(2)').textContent;
            const productCode = section.querySelector('.info-line:nth-child(4)').textContent;
            const plannedQuantity = section.querySelector('.info-line:nth-child(6)').textContent;
            const totalOutbound = section.querySelector('.info-line:nth-child(8)').textContent;
            const remainingQuantity = section.querySelector('.info-line:nth-child(10)').textContent;
            
            // 获取出库记录，提取数量和备注
            const outboundRecordsList = section.querySelector('.outbound-records-list');
            let outboundRecordsText = '';
            if (outboundRecordsList) {
                const recordItems = outboundRecordsList.querySelectorAll('.outbound-record-item');
                const recordParts = [];
                recordItems.forEach(item => {
                    const quantity = item.querySelector('.outbound-quantity')?.textContent || '';
                    const remark = item.querySelector('.outbound-remark')?.textContent || '';
                    if (remark) {
                        recordParts.push(quantity + ' ' + remark);
                    } else {
                        recordParts.push(quantity);
                    }
                });
                outboundRecordsText = recordParts.join(' ');
            }
            
            reportText += `计划名称：${planName}\n`;
            reportText += `产品编号：${productCode}\n`;
            reportText += `计划数量：${plannedQuantity}\n`;
            reportText += `已出库数量：${totalOutbound}\n`;
            reportText += `剩余数量：${remainingQuantity}\n`;
            reportText += `出库记录：${outboundRecordsText}\n\n`;
        });
        
        navigator.clipboard.writeText(reportText).then(() => {
            alert('报表已复制到剪贴板');
        }).catch(err => {
            console.error('复制失败:', err);
            alert('复制失败，请手动复制');
        });
    }
    </script>
</body>
</html> 