<?php
session_start();
require_once 'config.php';

// 检查登录状态
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 获取用户信息
$user_id = $_SESSION['user_id'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 初始化错误变量
$error = '';

// 获取日期和班次参数
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$shift = isset($_GET['shift']) ? $_GET['shift'] : 'day'; // day: 白班, night: 夜班

// 根据班次设置时间条件
$time_condition = '';
$time_params = [];

if ($shift === 'day') {
    // 白班：07:30 - 19:30
    $time_condition = "AND TIME(o.outbound_date) >= '07:30:00' AND TIME(o.outbound_date) <= '19:30:00'";
    $shift_name = '白班 (07:30-19:30)';
} else {
    // 夜班：19:30 - 次日07:30
    $time_condition = "AND (
        (DATE(o.outbound_date) = ? AND TIME(o.outbound_date) > '19:30:00') OR
        (DATE(o.outbound_date) = DATE_ADD(?, INTERVAL 1 DAY) AND TIME(o.outbound_date) <= '07:30:00')
    )";
    $time_params = [$date, $date];
    $shift_name = '夜班 (19:30-次日07:30)';
}

// 获取日报表数据
try {
    // 构建时间条件
    if ($shift === 'day') {
        // 白班：当天 07:30 - 19:30
        $time_where = "((DATE(o.outbound_date) = ? AND TIME(o.outbound_date) >= '07:30:00' AND TIME(o.outbound_date) <= '19:30:00'))";
        $params_base = [$date];
    } else {
        // 夜班：当天 19:30 之后 + 次日 07:30 之前
        $time_where = "((DATE(o.outbound_date) = ? AND TIME(o.outbound_date) > '19:30:00') OR (DATE(o.outbound_date) = DATE_ADD(?, INTERVAL 1 DAY) AND TIME(o.outbound_date) <= '07:30:00'))";
        $params_base = [$date, $date];
    }
    
    if ($is_admin || $is_storage) {
        $sql = "
            SELECT 
                p.id,
                p.plan_name,
                p.product_code,
                p.planned_quantity,
                p.plan_date,
                u.username as creator_name,
                COALESCE(SUM(o.outbound_quantity), 0) as total_outbound,
                COUNT(o.id) as outbound_count
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id AND $time_where
            LEFT JOIN users u ON p.user_id = u.id
            WHERE EXISTS (
                SELECT 1 FROM outbound_records o2 
                WHERE o2.plan_id = p.id AND $time_where
            )
            GROUP BY p.id
            ORDER BY p.plan_date DESC, p.id DESC
        ";
        $params = array_merge($params_base, $params_base);
    } else {
        $sql = "
            SELECT 
                p.id,
                p.plan_name,
                p.product_code,
                p.planned_quantity,
                p.plan_date,
                u.username as creator_name,
                COALESCE(SUM(o.outbound_quantity), 0) as total_outbound,
                COUNT(o.id) as outbound_count
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id AND $time_where
            LEFT JOIN users u ON p.user_id = u.id
            WHERE EXISTS (
                SELECT 1 FROM outbound_records o2 
                WHERE o2.plan_id = p.id AND $time_where
            ) AND p.user_id = ?
            GROUP BY p.id
            ORDER BY p.plan_date DESC, p.id DESC
        ";
        $params = array_merge($params_base, $params_base, [$user_id]);
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $plans = $stmt->fetchAll();
} catch(PDOException $e) {
    $error = '获取日报表数据失败：' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>日报表 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #64748b;
            --success: #059669;
            --light-bg: #f1f5f9;
            --border-color: #e2e8f0;
        }

        body { 
            background-color: var(--light-bg);
            min-height: 100vh;
        }

        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        .page-header {
            background: white;
            padding: 1.5rem;
            margin: 1rem 0;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .page-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 1.25rem;
        }

        .search-form {
            display: flex;
            gap: 0.75rem;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .search-form select {
            min-width: 180px;
        }

        .form-control {
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            padding: 0.625rem 0.875rem;
            font-size: 0.9375rem;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .btn {
            padding: 0.625rem 1rem;
            font-weight: 500;
            border-radius: 0.5rem;
            font-size: 0.9375rem;
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: #1d4ed8;
            border-color: #1d4ed8;
        }

        .btn-secondary {
            background-color: #f8fafc;
            border-color: var(--border-color);
            color: var(--secondary);
        }

        .btn-secondary:hover {
            background-color: #f1f5f9;
            border-color: #cbd5e1;
            color: #475569;
        }

        .report-card {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-color);
            margin-bottom: 1rem;
            overflow: hidden;
        }

        .report-date {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-color);
            font-weight: 600;
            color: #1e293b;
            background-color: #f8fafc;
            font-size: 0.9375rem;
        }

        .report-item {
            padding: 1rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
        }

        .report-item:last-child {
            border-bottom: none;
        }

        .product-code {
            color: #1e293b;
            font-weight: 500;
            font-size: 0.9375rem;
        }

        .quantity {
            background-color: #f1f5f9;
            padding: 0.375rem 0.75rem;
            border-radius: 0.375rem;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.875rem;
        }

        @media (max-width: 768px) {
            .navbar {
                padding: 0.75rem 1rem;
            }

            .navbar-collapse {
                background: white;
                padding: 1rem;
                border-radius: 0.75rem;
                margin-top: 0.5rem;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            }

            .nav-link {
                padding: 0.75rem 1rem;
            }

            .page-header {
                margin: 0.75rem 0;
                padding: 1.25rem;
                border-radius: 0.5rem;
            }

            .search-form {
                flex-direction: column;
                width: 100%;
            }

            .search-form .form-control,
            .search-form .btn {
                width: 100%;
            }

            .report-card {
                border-radius: 0.5rem;
                margin: 0.75rem 0;
            }

            .report-item {
                padding: 0.875rem 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1 class="page-title">出库日报表 - <?php echo $shift_name; ?></h1>
            <form method="GET" class="search-form">
                <input type="date" name="date" class="form-control" value="<?php echo $date; ?>" max="<?php echo date('Y-m-d'); ?>">
                <select name="shift" class="form-control">
                    <option value="day" <?php echo $shift === 'day' ? 'selected' : ''; ?>>白班 (07:30-19:30)</option>
                    <option value="night" <?php echo $shift === 'night' ? 'selected' : ''; ?>>夜班 (19:30-次日07:30)</option>
                </select>
                <button type="submit" class="btn btn-primary">查询</button>
                <a href="index.php" class="btn btn-secondary">返回主页</a>
            </form>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (empty($plans)): ?>
            <div class="report-card">
                <div class="report-date"><?php echo $date . ' ' . $shift_name; ?> - 无出库记录</div>
            </div>
        <?php else: ?>
            <div class="report-card">
                <div class="report-date"><?php echo $date . ' ' . $shift_name; ?> 出库记录</div>
                <?php foreach ($plans as $plan): ?>
                    <div class="report-item">
                        <div>
                            <div class="product-code"><?php echo htmlspecialchars($plan['product_code'] ?? '未设置'); ?></div>
                            <small class="text-muted"><?php echo htmlspecialchars($plan['plan_name']); ?></small>
                        </div>
                        <span class="quantity"><?php echo $plan['total_outbound']; ?> 个</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 