<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 获取日期参数
$selected_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>出库记录调试 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 15px; background-color: #f8f9fa; }
        .card { margin-bottom: 15px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .debug-section { background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 15px; }
        .sql-query { background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 5px; font-family: monospace; }
        .result-table { font-size: 14px; }
        .highlight { background-color: #fff3cd !important; }
    </style>
</head>
<body>
    <div class="container">
        <h1>出库记录调试信息</h1>
        <p>查询日期：<?php echo htmlspecialchars($selected_date); ?></p>
        
        <?php
        try {
            // 1. 查询该日期所有出库记录（不限制班次）
            echo '<div class="card">';
            echo '<div class="card-header"><h5>1. 该日期所有出库记录（不限制班次）</h5></div>';
            echo '<div class="card-body">';
            
            $all_stmt = $pdo->prepare("
                SELECT 
                    o.id,
                    o.outbound_date,
                    o.outbound_quantity,
                    o.remark,
                    o.user_id,
                    p.product_code,
                    u.username as operator_name
                FROM outbound_records o
                INNER JOIN production_plans p ON o.plan_id = p.id
                LEFT JOIN users u ON o.user_id = u.id
                WHERE DATE(o.outbound_date) = ?
                AND p.deleted_at IS NULL
                ORDER BY o.outbound_date ASC
            ");
            $all_stmt->execute([$selected_date]);
            $all_records = $all_stmt->fetchAll();
            
            echo '<p>总计：' . count($all_records) . ' 条记录</p>';
            
            if (!empty($all_records)) {
                echo '<table class="table result-table">';
                echo '<thead><tr><th>ID</th><th>时间</th><th>数量</th><th>产品编码</th><th>操作人</th><th>备注</th></tr></thead>';
                echo '<tbody>';
                foreach ($all_records as $record) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($record['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_date']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_quantity']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['product_code']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['operator_name']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['remark']) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div></div>';
            
            // 2. 白班记录
            echo '<div class="card">';
            echo '<div class="card-header"><h5>2. 白班记录 (07:30-19:30)</h5></div>';
            echo '<div class="card-body">';
            
            $day_stmt = $pdo->prepare("
                SELECT 
                    o.id,
                    o.outbound_date,
                    o.outbound_quantity,
                    o.remark,
                    o.user_id,
                    p.product_code,
                    u.username as operator_name
                FROM outbound_records o
                INNER JOIN production_plans p ON o.plan_id = p.id
                LEFT JOIN users u ON o.user_id = u.id
                WHERE DATE(o.outbound_date) = ? 
                AND TIME(o.outbound_date) >= '07:30:00' 
                AND TIME(o.outbound_date) <= '19:30:00'
                AND p.deleted_at IS NULL
                ORDER BY o.outbound_date ASC
            ");
            $day_stmt->execute([$selected_date]);
            $day_records = $day_stmt->fetchAll();
            
            echo '<p>白班总计：' . count($day_records) . ' 条记录</p>';
            
            if (!empty($day_records)) {
                echo '<table class="table result-table">';
                echo '<thead><tr><th>ID</th><th>时间</th><th>数量</th><th>产品编码</th><th>操作人</th></tr></thead>';
                echo '<tbody>';
                foreach ($day_records as $record) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($record['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_date']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_quantity']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['product_code']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['operator_name']) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div></div>';
            
            // 3. 夜班记录
            echo '<div class="card">';
            echo '<div class="card-header"><h5>3. 夜班记录 (19:30-次日07:30)</h5></div>';
            echo '<div class="card-body">';
            
            $night_stmt = $pdo->prepare("
                SELECT 
                    o.id,
                    o.outbound_date,
                    o.outbound_quantity,
                    o.remark,
                    o.user_id,
                    p.product_code,
                    u.username as operator_name
                FROM outbound_records o
                INNER JOIN production_plans p ON o.plan_id = p.id
                LEFT JOIN users u ON o.user_id = u.id
                WHERE (
                    (DATE(o.outbound_date) = ? AND TIME(o.outbound_date) >= '19:30:00') 
                    OR (DATE(o.outbound_date) = DATE_ADD(?, INTERVAL 1 DAY) AND TIME(o.outbound_date) <= '07:30:00')
                )
                AND p.deleted_at IS NULL
                ORDER BY o.outbound_date ASC
            ");
            $night_stmt->execute([$selected_date, $selected_date]);
            $night_records = $night_stmt->fetchAll();
            
            echo '<p>夜班总计：' . count($night_records) . ' 条记录</p>';
            
            if (!empty($night_records)) {
                echo '<table class="table result-table">';
                echo '<thead><tr><th>ID</th><th>时间</th><th>数量</th><th>产品编码</th><th>操作人</th></tr></thead>';
                echo '<tbody>';
                foreach ($night_records as $record) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($record['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_date']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_quantity']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['product_code']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['operator_name']) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div></div>';
            
            // 4. 边界时间检查
            echo '<div class="card">';
            echo '<div class="card-header"><h5>4. 边界时间记录检查</h5></div>';
            echo '<div class="card-body">';
            
            $boundary_stmt = $pdo->prepare("
                SELECT 
                    o.id,
                    o.outbound_date,
                    TIME(o.outbound_date) as time_only,
                    o.outbound_quantity,
                    p.product_code,
                    u.username as operator_name
                FROM outbound_records o
                INNER JOIN production_plans p ON o.plan_id = p.id
                LEFT JOIN users u ON o.user_id = u.id
                WHERE DATE(o.outbound_date) = ?
                AND (
                    TIME(o.outbound_date) = '07:30:00' 
                    OR TIME(o.outbound_date) = '19:30:00'
                    OR TIME(o.outbound_date) = '07:29:59'
                    OR TIME(o.outbound_date) = '19:29:59'
                    OR TIME(o.outbound_date) = '07:30:01'
                    OR TIME(o.outbound_date) = '19:30:01'
                )
                AND p.deleted_at IS NULL
                ORDER BY o.outbound_date ASC
            ");
            $boundary_stmt->execute([$selected_date]);
            $boundary_records = $boundary_stmt->fetchAll();
            
            echo '<p>边界时间记录：' . count($boundary_records) . ' 条</p>';
            if (!empty($boundary_records)) {
                echo '<div class="alert alert-warning">⚠️ 发现边界时间记录，可能存在时间边界问题</div>';
                echo '<table class="table result-table">';
                echo '<thead><tr><th>ID</th><th>完整时间</th><th>时间部分</th><th>数量</th><th>产品编码</th></tr></thead>';
                echo '<tbody>';
                foreach ($boundary_records as $record) {
                    echo '<tr class="highlight">';
                    echo '<td>' . htmlspecialchars($record['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_date']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['time_only']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['outbound_quantity']) . '</td>';
                    echo '<td>' . htmlspecialchars($record['product_code']) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div></div>';
            
            // 5. 按用户分组统计
            if ($is_admin || $is_storage) {
                echo '<div class="card">';
                echo '<div class="card-header"><h5>5. 按操作人统计</h5></div>';
                echo '<div class="card-body">';
                
                $user_stmt = $pdo->prepare("
                    SELECT 
                        o.user_id,
                        u.username,
                        COUNT(*) as record_count,
                        SUM(o.outbound_quantity) as total_quantity
                    FROM outbound_records o
                    INNER JOIN production_plans p ON o.plan_id = p.id
                    LEFT JOIN users u ON o.user_id = u.id
                    WHERE DATE(o.outbound_date) = ?
                    AND p.deleted_at IS NULL
                    GROUP BY o.user_id, u.username
                    ORDER BY u.username
                ");
                $user_stmt->execute([$selected_date]);
                $user_records = $user_stmt->fetchAll();
                
                if (!empty($user_records)) {
                    echo '<table class="table result-table">';
                    echo '<thead><tr><th>用户ID</th><th>用户名</th><th>记录数</th><th>总数量</th></tr></thead>';
                    echo '<tbody>';
                    foreach ($user_records as $record) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($record['user_id']) . '</td>';
                        echo '<td>' . htmlspecialchars($record['username']) . '</td>';
                        echo '<td>' . htmlspecialchars($record['record_count']) . '</td>';
                        echo '<td>' . htmlspecialchars($record['total_quantity']) . '</td>';
                        echo '</tr>';
                    }
                    echo '</tbody></table>';
                }
                echo '</div></div>';
            }
            
        } catch(PDOException $e) {
            echo '<div class="alert alert-danger">数据库错误：' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        ?>
        
        <div class="card">
            <div class="card-header">
                <h5>建议的解决方案</h5>
            </div>
            <div class="card-body">
                <h6>如果发现记录不完整，可能的原因：</h6>
                <ol>
                    <li><strong>时间边界问题</strong>：检查边界时间（07:30, 19:30）的记录是否被正确分类</li>
                    <li><strong>权限问题</strong>：确认当前用户权限，如果需要查看所有记录请联系管理员</li>
                    <li><strong>数据完整性</strong>：检查数据库中是否确实存在更多记录</li>
                    <li><strong>班次交叉</strong>：某些记录可能在班次边界，需要调整时间条件</li>
                </ol>
                
                <h6>修复建议：</h6>
                <ul>
                    <li>调整时间边界条件，使用更宽松的时间范围</li>
                    <li>增加调试日志，记录查询条件和结果</li>
                    <li>优化用户权限显示，让普通用户也能看到部分调试信息</li>
                </ul>
            </div>
        </div>
        
        <div class="mt-3">
            <a href="product_outbound_records.php?date=<?php echo urlencode($selected_date); ?>" class="btn btn-primary">返回出库记录页面</a>
        </div>
    </div>
</body>
</html>