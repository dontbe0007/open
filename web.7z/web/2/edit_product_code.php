<?php
session_start();

if (!file_exists('config.php')) {
    header('Location: install_check.php');
    exit;
}

require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'] ?? '';
$is_admin = $role === ROLE_ADMIN;
$is_storage = $role === ROLE_STORAGE;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product_code'])) {
    $plan_id = isset($_POST['plan_id']) ? (int)$_POST['plan_id'] : 0;
    $product_code = trim($_POST['product_code'] ?? '');

    if ($plan_id <= 0) {
        $error = '无效的计划信息';
    } elseif ($product_code === '') {
        $error = '产品编码不能为空';
    } else {
        try {
            $pdo->beginTransaction();

            if ($is_admin) {
                $stmt = $pdo->prepare("UPDATE production_plans SET product_code = ? WHERE id = ?");
                $stmt->execute([$product_code, $plan_id]);
            } else {
                $stmt = $pdo->prepare("UPDATE production_plans SET product_code = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$product_code, $plan_id, $user_id]);
            }

            if ($stmt->rowCount() === 0) {
                throw new Exception('计划不存在或无权限修改');
            }

            $pdo->commit();
            $success = '产品编码修改成功！';
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = '修改失败：' . $e->getMessage();
        }
    }
}

$selected_date = isset($_GET['date']) && $_GET['date'] !== '' ? $_GET['date'] : date('Y-m-d');
$keyword = trim($_GET['keyword'] ?? '');

try {
    $params = [];

    if ($is_admin || $is_storage) {
        $baseQuery = "
            SELECT p.*, u.username as user_name,
                   COALESCE((SELECT SUM(outbound_quantity) FROM outbound_records WHERE plan_id = p.id), 0) as total_outbound,
                   p.planned_quantity - COALESCE((SELECT SUM(outbound_quantity) FROM outbound_records WHERE plan_id = p.id), 0) as remaining_quantity
            FROM production_plans p
            LEFT JOIN users u ON p.user_id = u.id
            WHERE DATE(p.plan_date) = ?
        ";
        $params[] = $selected_date;
    } else {
        $baseQuery = "
            SELECT p.*, u.username as user_name,
                   COALESCE((SELECT SUM(outbound_quantity) FROM outbound_records WHERE plan_id = p.id), 0) as total_outbound,
                   p.planned_quantity - COALESCE((SELECT SUM(outbound_quantity) FROM outbound_records WHERE plan_id = p.id), 0) as remaining_quantity
            FROM production_plans p
            LEFT JOIN users u ON p.user_id = u.id
            WHERE p.user_id = ? AND DATE(p.plan_date) = ?
        ";
        $params[] = $user_id;
        $params[] = $selected_date;
    }

    if ($keyword !== '') {
        $baseQuery .= " AND (p.product_code LIKE ? OR p.plan_name LIKE ?)";
        $like = '%' . $keyword . '%';
        $params[] = $like;
        $params[] = $like;
    }

    $baseQuery .= " ORDER BY p.plan_date DESC, p.id DESC";

    $stmt = $pdo->prepare($baseQuery);
    $stmt->execute($params);
    $plans = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '获取计划列表失败：' . $e->getMessage();
    $plans = [];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改产品编码 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card { 
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .alert {
            border-radius: 10px;
        }
        .plan-card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .plan-info {
            flex: 1;
            margin-bottom: 15px;
        }
        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }
        .info-label {
            color: #666;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .product-code-form .form-control {
            border-radius: 5px;
        }
        .product-code-form .btn {
            border-radius: 5px;
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .plan-card {
                padding: 12px;
            }
            .info-item {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="report.php">一键报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="js.php">尾数计算</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="repeat_check.php">重复检测</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="edit_product_code.php">修改产品编码</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
            <div>
                <h1 class="h3 mb-1">产品编码管理</h1>
                <p class="text-muted mb-0">快速定位并修改生产计划中的产品编码</p>
            </div>
            <a href="index.php" class="btn btn-outline-secondary">返回首页</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-body">
                <form class="row g-3 align-items-end" method="GET">
                    <div class="col-md-4">
                        <label class="form-label">计划日期</label>
                        <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($selected_date); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">关键词（计划名称/产品编码）</label>
                        <input type="text" name="keyword" class="form-control" placeholder="输入关键词搜索" value="<?php echo htmlspecialchars($keyword); ?>">
                    </div>
                    <div class="col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary flex-grow-1">筛选</button>
                        <a href="edit_product_code.php" class="btn btn-outline-secondary">重置</a>
                    </div>
                </form>
            </div>
        </div>

        <?php if (empty($plans)): ?>
            <div class="alert alert-info">当前日期下暂无可修改的生产计划。</div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($plans as $plan): 
                    $can_edit_plan = $is_admin || (!$is_storage && $plan['user_id'] == $user_id);
                ?>
                <div class="col">
                    <div class="plan-card">
                        <div class="plan-info">
                            <div class="info-item">
                                <span class="info-label">计划名称：</span>
                                <span><?php echo htmlspecialchars($plan['plan_name']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">计划日期：</span>
                                <span><?php echo htmlspecialchars(date('Y-m-d', strtotime($plan['plan_date']))); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">计划数量：</span>
                                <span><?php echo (int)$plan['planned_quantity']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">已出库：</span>
                                <span><?php echo (int)$plan['total_outbound']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">剩余数量：</span>
                                <span><?php echo (int)$plan['remaining_quantity']; ?></span>
                            </div>
                            <?php if ($is_admin): ?>
                            <div class="info-item">
                                <span class="info-label">创建用户：</span>
                                <span><?php echo htmlspecialchars($plan['user_name']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <form method="POST" class="product-code-form d-flex flex-column gap-2">
                                <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                                <label class="form-label mb-1">产品编码</label>
                                <input type="text" name="product_code" class="form-control" value="<?php echo htmlspecialchars($plan['product_code'] ?? ''); ?>" <?php echo $can_edit_plan ? '' : 'readonly'; ?>>
                                <?php if ($can_edit_plan): ?>
                                <button type="submit" name="update_product_code" class="btn btn-primary">保存编码</button>
                                <?php else: ?>
                                <div class="alert alert-warning mb-0">您没有权限修改此计划的产品编码</div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

