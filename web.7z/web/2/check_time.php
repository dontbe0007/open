<?php
/**
 * 服务器时间检测页面
 * 用于检查服务器时间设置和时区配置
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

// 获取各种时间信息
$php_timezone = date_default_timezone_get();
$php_current_time = date('Y-m-d H:i:s');
$php_timestamp = time();
$php_timezone_offset = date('P');

// MySQL时间
try {
    // 分别查询，避免某些MySQL版本的语法问题
    $mysql_now = $pdo->query("SELECT NOW() as current_time")->fetch(PDO::FETCH_ASSOC);
    $mysql_global_tz = $pdo->query("SELECT @@global.time_zone as tz")->fetch(PDO::FETCH_ASSOC);
    $mysql_session_tz = $pdo->query("SELECT @@session.time_zone as tz")->fetch(PDO::FETCH_ASSOC);
    
    $mysql_time = [
        'current_time' => $mysql_now['current_time'],
        'global_tz' => $mysql_global_tz['tz'],
        'session_tz' => $mysql_session_tz['tz']
    ];
} catch (PDOException $e) {
    $mysql_time = ['error' => $e->getMessage()];
}

// 系统时间（如果可用）
$system_time = @shell_exec('date') ?: '无法获取';

    // 检查数据库中的时间记录
try {
    $latest_outbound = $pdo->query("SELECT id, outbound_date, created_at FROM outbound_records ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    $latest_inbound = $pdo->query("SELECT id, inbound_date FROM inbound_records ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $latest_outbound = [];
    $latest_inbound = [];
    $db_error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>服务器时间检测</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 1000px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .time-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #007bff;
        }
        .time-box h5 {
            color: #007bff;
            margin-bottom: 10px;
        }
        .time-value {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            font-family: 'Courier New', monospace;
        }
        .warning {
            background: #fff3cd;
            border-left-color: #ffc107;
        }
        .warning h5 {
            color: #856404;
        }
        .error {
            background: #f8d7da;
            border-left-color: #dc3545;
        }
        .error h5 {
            color: #721c24;
        }
        .success {
            background: #d4edda;
            border-left-color: #28a745;
        }
        .success h5 {
            color: #155724;
        }
        table {
            margin-top: 10px;
        }
        .refresh-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">🕐 服务器时间检测</h2>
        
        <!-- PHP时区信息 -->
        <div class="time-box">
            <h5>PHP 时区配置</h5>
            <div class="time-value">时区: <?php echo htmlspecialchars($php_timezone); ?></div>
            <div class="time-value">时区偏移: <?php echo htmlspecialchars($php_timezone_offset); ?></div>
        </div>
        
        <!-- PHP当前时间 -->
        <div class="time-box success">
            <h5>PHP 当前时间</h5>
            <div class="time-value" id="php-time"><?php echo htmlspecialchars($php_current_time); ?></div>
            <div style="font-size: 14px; color: #666; margin-top: 5px;">
                时间戳: <?php echo $php_timestamp; ?>
            </div>
        </div>
        
        <!-- MySQL时间 -->
        <div class="time-box <?php echo isset($mysql_time['error']) ? 'error' : 'success'; ?>">
            <h5>MySQL 数据库时间</h5>
            <?php if (isset($mysql_time['error'])): ?>
                <div style="color: #dc3545;">错误: <?php echo htmlspecialchars($mysql_time['error']); ?></div>
            <?php else: ?>
                <div class="time-value">当前时间: <?php echo htmlspecialchars($mysql_time['current_time']); ?></div>
                <div style="font-size: 14px; color: #666; margin-top: 5px;">
                    全局时区: <?php echo htmlspecialchars($mysql_time['global_tz']); ?><br>
                    会话时区: <?php echo htmlspecialchars($mysql_time['session_tz']); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- 系统时间 -->
        <div class="time-box">
            <h5>系统时间</h5>
            <div class="time-value"><?php echo htmlspecialchars(trim($system_time)); ?></div>
        </div>
        
        <!-- 时间对比 -->
        <div class="time-box <?php 
            $php_time_obj = new DateTime($php_current_time);
            $mysql_time_obj = isset($mysql_time['current_time']) ? new DateTime($mysql_time['current_time']) : null;
            if ($mysql_time_obj) {
                $diff = abs($php_time_obj->getTimestamp() - $mysql_time_obj->getTimestamp());
                echo $diff > 5 ? 'warning' : 'success';
            }
        ?>">
            <h5>时间对比</h5>
            <?php if ($mysql_time_obj): ?>
                <?php 
                $diff = $php_time_obj->getTimestamp() - $mysql_time_obj->getTimestamp();
                $diff_abs = abs($diff);
                ?>
                <div class="time-value">
                    PHP 与 MySQL 时间差: 
                    <span style="color: <?php echo $diff_abs > 5 ? '#ffc107' : '#28a745'; ?>;">
                        <?php 
                        if ($diff > 0) {
                            echo "+{$diff_abs} 秒 (PHP 比 MySQL 快)";
                        } elseif ($diff < 0) {
                            echo "-{$diff_abs} 秒 (PHP 比 MySQL 慢)";
                        } else {
                            echo "0 秒 (完全一致)";
                        }
                        ?>
                    </span>
                </div>
                <?php if ($diff_abs > 5): ?>
                    <div style="color: #856404; margin-top: 10px;">
                        ⚠️ 警告：PHP 和 MySQL 时间差异超过 5 秒，可能导致时间记录不准确！
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div style="color: #dc3545;">无法对比（MySQL 时间获取失败）</div>
            <?php endif; ?>
        </div>
        
        <!-- 数据库中的最新记录 -->
        <div class="time-box">
            <h5>数据库中的最新出库记录时间</h5>
            <?php if (!empty($latest_outbound)): ?>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>出库时间 (outbound_date)</th>
                            <th>创建时间 (created_at)</th>
                            <th>时间差</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($latest_outbound as $record): ?>
                            <?php
                            $outbound_dt = new DateTime($record['outbound_date']);
                            $created_dt = new DateTime($record['created_at']);
                            $record_diff = $created_dt->getTimestamp() - $outbound_dt->getTimestamp();
                            ?>
                            <tr>
                                <td><?php echo $record['id'] ?? 'N/A'; ?></td>
                                <td><?php echo htmlspecialchars($record['outbound_date']); ?></td>
                                <td><?php echo htmlspecialchars($record['created_at']); ?></td>
                                <td style="color: <?php echo abs($record_diff) > 3600 ? '#dc3545' : '#666'; ?>;">
                                    <?php 
                                    if (abs($record_diff) > 86400) {
                                        echo number_format($record_diff / 86400, 1) . ' 天';
                                    } elseif (abs($record_diff) > 3600) {
                                        echo number_format($record_diff / 3600, 1) . ' 小时';
                                    } else {
                                        echo number_format($record_diff / 60, 1) . ' 分钟';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="color: #666;">暂无出库记录</div>
            <?php endif; ?>
        </div>
        
        <!-- 数据库中的最新入库记录 -->
        <div class="time-box">
            <h5>数据库中的最新入库记录时间</h5>
            <?php if (!empty($latest_inbound)): ?>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>入库时间 (inbound_date)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($latest_inbound as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['inbound_date']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="color: #666;">暂无入库记录</div>
            <?php endif; ?>
        </div>
        
        <!-- 建议 -->
        <div class="time-box warning">
            <h5>💡 建议</h5>
            <ul style="margin-bottom: 0;">
                <li>确保 PHP 和 MySQL 使用相同的时区设置</li>
                <li>推荐时区：Asia/Shanghai (UTC+8)</li>
                <li>如果时间不一致，请检查：
                    <ul>
                        <li>PHP 配置：<code>date.timezone</code> 或 <code>date_default_timezone_set()</code></li>
                        <li>MySQL 时区：<code>SET time_zone = '+08:00'</code></li>
                        <li>服务器系统时间</li>
                    </ul>
                </li>
            </ul>
        </div>
        
        <div class="mt-4">
            <a href="index.php" class="btn btn-primary">返回主页</a>
            <button onclick="location.reload()" class="btn btn-secondary">刷新页面</button>
        </div>
    </div>
    
    <script>
        // 实时更新时间显示
        function updateTime() {
            const now = new Date();
            const timeStr = now.getFullYear() + '-' + 
                String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                String(now.getDate()).padStart(2, '0') + ' ' + 
                String(now.getHours()).padStart(2, '0') + ':' + 
                String(now.getMinutes()).padStart(2, '0') + ':' + 
                String(now.getSeconds()).padStart(2, '0');
            document.getElementById('php-time').textContent = timeStr;
        }
        
        // 每秒更新一次
        setInterval(updateTime, 1000);
    </script>
</body>
</html>

