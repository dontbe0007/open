<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 日期处理
$selected_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// 查询所有排产计划的出库记录
$sql = "
    SELECT p.product_code, o.outbound_quantity, o.remark, o.outbound_date
    FROM production_plans p
    JOIN outbound_records o ON p.id = o.plan_id
    WHERE DATE(o.outbound_date) = ?
    ORDER BY p.product_code, o.outbound_quantity, o.remark, o.outbound_date
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$selected_date]);
$records = $stmt->fetchAll();

// 查找重复（出库数量+识别码）
$repeat_map = [];
foreach ($records as $rec) {
    $key = $rec['outbound_quantity'] . '|' . $rec['remark'];
    if (!isset($repeat_map[$key])) {
        $repeat_map[$key] = 0;
    }
    $repeat_map[$key]++;
}

// 按产品编码分组
$product_groups = [];
foreach ($records as $rec) {
    $product_groups[$rec['product_code']][] = $rec;
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>重复检测 - 出库记录</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .repeat-row {
            background-color: #ffeaea !important;
            color: #d8000c !important;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
    </style>
</head>
<body>
<?php // 导航栏 ?>
<nav class="navbar navbar-expand-lg navbar-light mb-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">仓库管理系统</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 flex-row flex-wrap">
                <li class="nav-item"><a class="nav-link" href="index.php">排产计划</a></li>
                <li class="nav-item"><a class="nav-link" href="daily_report.php">日报表</a></li>
                <li class="nav-item"><a class="nav-link" href="report.php">一键报表</a></li>
                <li class="nav-item"><a class="nav-link" href="js.php">尾数计算</a></li>
                <li class="nav-item"><a class="nav-link active" href="repeat_check.php">重复检测</a></li>
                <li class="nav-item"><a class="nav-link" href="product_outbound_records.php">产品出库记录</a></li>
                <li class="nav-item"><a class="nav-link" href="navigation.php">不迷路</a></li>
                <?php if ($is_admin): ?>
                <li class="nav-item"><a class="nav-link" href="manage_users.php">用户管理</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav mb-2 mb-lg-0 flex-row flex-wrap">
                <li class="nav-item"><span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span></li>
                <li class="nav-item"><a class="nav-link" href="change_password.php">修改密码</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">退出</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h4">重复检测 - 出库记录</h1>
        <form method="get" class="d-flex gap-2">
            <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($selected_date); ?>">
            <button type="submit" class="btn btn-primary">查询</button>
        </form>
    </div>
    <div class="card">
        <div class="card-header">出库记录（<?php echo htmlspecialchars($selected_date); ?>）</div>
        <div class="card-body p-0">
            <?php if (empty($product_groups)): ?>
                <div class="p-3 text-muted">无出库记录</div>
            <?php else: ?>
                <?php foreach ($product_groups as $product_code => $group): ?>
                    <div class="p-3">
                        <h5 class="mb-3">产品编码：<?php echo htmlspecialchars($product_code); ?></h5>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered mb-0">
                                <thead>
                                    <tr>
                                        <th>出库数量</th>
                                        <th>识别码</th>
                                        <th>出库时间</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($group as $rec):
                                    $key = $rec['outbound_quantity'] . '|' . $rec['remark'];
                                    $is_repeat = $repeat_map[$key] > 1;
                                ?>
                                    <tr<?php if ($is_repeat) echo ' class="repeat-row"'; ?>>
                                        <td><?php echo htmlspecialchars($rec['outbound_quantity']); ?></td>
                                        <td><?php echo htmlspecialchars($rec['remark']); ?></td>
                                        <td><?php echo htmlspecialchars($rec['outbound_date']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="mt-3 text-muted">有相同"出库数量+识别码"的记录将高亮标红。</div>
</div>
</body>
</html> 