<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

$error = '';
$success = '';

// 检查并添加 deleted_at 字段（如果不存在）
try {
    $check = $pdo->query("SHOW COLUMNS FROM inventory LIKE 'deleted_at'");
    if ($check->rowCount() == 0) {
        // 字段不存在，添加它
        $pdo->exec("
            ALTER TABLE inventory 
            ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL 
            AFTER updated_at
        ");
        // 添加索引
        try {
            $pdo->exec("CREATE INDEX idx_inventory_deleted_at ON inventory(deleted_at)");
        } catch (PDOException $e) {
            // 索引可能已存在，忽略错误
        }
    }
} catch (PDOException $e) {
    // 忽略检查错误，继续执行
}

// 处理恢复库存
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['restore_inventory'])) {
    $inventory_id = (int)$_POST['inventory_id'];
    
    try {
        $stmt = $pdo->prepare("UPDATE inventory SET deleted_at = NULL WHERE id = ?");
        $stmt->execute([$inventory_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('库存记录不存在或无权限恢复');
        }
        
        $success = '库存恢复成功！';
        header('Location: inventory_trash.php?success=1');
        exit;
    } catch (Exception $e) {
        $error = '恢复失败：' . $e->getMessage();
    }
}

// 处理永久删除库存
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['permanent_delete'])) {
    $inventory_id = (int)$_POST['inventory_id'];
    
    try {
        // 检查记录是否存在且已删除
        $stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ? AND deleted_at IS NOT NULL");
        $stmt->execute([$inventory_id]);
        $inventory = $stmt->fetch();
        
        if (!$inventory) {
            throw new Exception('库存记录不存在或无权限删除');
        }
        
        // 永久删除库存
        $stmt = $pdo->prepare("DELETE FROM inventory WHERE id = ?");
        $stmt->execute([$inventory_id]);
        
        $success = '库存已永久删除！';
        header('Location: inventory_trash.php?success=1');
        exit;
    } catch (Exception $e) {
        $error = '删除失败：' . $e->getMessage();
    }
}

// 获取成功消息
if (isset($_GET['success'])) {
    $success = '操作成功！';
}

// 获取已删除的库存
try {
    $stmt = $pdo->prepare("
        SELECT * FROM inventory 
        WHERE deleted_at IS NOT NULL
        ORDER BY deleted_at DESC
    ");
    $stmt->execute();
    $deleted_inventory = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '获取回收站记录失败：' . $e->getMessage();
    $deleted_inventory = [];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>库存回收站 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .form-control, .btn {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
        .table {
            background-color: white;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .btn-action {
            padding: 2px 8px;
            font-size: 12px;
            margin: 2px;
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="report.php">一键报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="js.php">尾数计算</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="repeat_check.php">重复检测</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="inventory_trash.php">库存回收站</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="trash.php">计划回收站</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">库存回收站</h1>
            <a href="inventory.php" class="btn btn-secondary">返回库存管理</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="alert alert-warning">
            <strong>提示：</strong>回收站中的库存可以恢复。从回收站永久删除后，将无法恢复。
        </div>

        <!-- 已删除的库存列表 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">已删除的库存</h5>
            </div>
            <div class="card-body">
                <?php if (empty($deleted_inventory)): ?>
                    <p class="text-muted">回收站为空</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>产品编码</th>
                                    <th>库位</th>
                                    <th>数量</th>
                                    <th>删除时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($deleted_inventory as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                                        <td><?php echo htmlspecialchars($item['location']); ?></td>
                                        <td><?php echo number_format($item['quantity']); ?></td>
                                        <td><?php echo date('m-d H:i', strtotime($item['deleted_at'])); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('确定要恢复此库存吗？');">
                                                <input type="hidden" name="inventory_id" value="<?php echo $item['id']; ?>">
                                                <button type="submit" name="restore_inventory" class="btn btn-sm btn-success btn-action">恢复</button>
                                            </form>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('确定要永久删除此库存吗？此操作无法恢复！');">
                                                <input type="hidden" name="inventory_id" value="<?php echo $item['id']; ?>">
                                                <button type="submit" name="permanent_delete" class="btn btn-sm btn-danger btn-action">永久删除</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

