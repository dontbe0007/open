<?php
/**
 * 创建所有数据库表的脚本
 * 用于服务器迁移时重建数据库结构
 * 运行此文件一次即可创建所有所需的表结构
 * 
 * 注意：此脚本会创建表结构，但不会导入数据
 * 数据需要从backups文件夹中的SQL备份文件导入
 */

require_once 'config.php';

try {
    $pdo->beginTransaction();
    
    echo "<h2>开始创建数据库表...</h2>";
    echo "<pre>";
    
    // 1. 创建用户表 (users)
    echo "正在创建 users 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `users` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
            `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
            `last_login` timestamp NULL DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `username` (`username`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ users 表创建成功\n\n";
    
    // 2. 创建生产计划表 (production_plans)
    echo "正在创建 production_plans 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `production_plans` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `plan_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
            `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `planned_quantity` int(11) NOT NULL,
            `plan_date` date NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `deleted_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `user_id` (`user_id`),
            KEY `idx_deleted_at` (`deleted_at`),
            CONSTRAINT `production_plans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ production_plans 表创建成功\n\n";
    
    // 3. 创建出库记录表 (outbound_records)
    echo "正在创建 outbound_records 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `outbound_records` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `plan_id` int(11) NOT NULL,
            `user_id` int(11) NOT NULL,
            `outbound_quantity` int(11) NOT NULL,
            `remark` text COLLATE utf8mb4_unicode_ci,
            `photo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `outbound_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `plan_id` (`plan_id`),
            KEY `user_id` (`user_id`),
            CONSTRAINT `outbound_records_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `production_plans` (`id`) ON DELETE CASCADE,
            CONSTRAINT `outbound_records_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ outbound_records 表创建成功\n\n";
    
    // 4. 创建入库记录表 (inbound_records)
    echo "正在创建 inbound_records 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `inbound_records` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `inbound_quantity` int(11) NOT NULL,
            `location` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `remark` text COLLATE utf8mb4_unicode_ci,
            `user_id` int(11) NOT NULL,
            `inbound_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `deleted_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `product_code` (`product_code`),
            KEY `location` (`location`),
            KEY `user_id` (`user_id`),
            KEY `inbound_date` (`inbound_date`),
            KEY `idx_inbound_records_deleted_at` (`deleted_at`),
            CONSTRAINT `inbound_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ inbound_records 表创建成功\n\n";
    
    // 5. 创建库存表 (inventory)
    echo "正在创建 inventory 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `inventory` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `location` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `quantity` int(11) NOT NULL DEFAULT 0,
            `remark` text COLLATE utf8mb4_unicode_ci,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            `deleted_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `product_location` (`product_code`, `location`),
            KEY `product_code` (`product_code`),
            KEY `location` (`location`),
            KEY `idx_inventory_deleted_at` (`deleted_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ inventory 表创建成功\n\n";
    
    // 6. 创建班次记录表 (shift_records) - 可选表
    echo "正在创建 shift_records 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `shift_records` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `plan_id` int(11) NOT NULL,
            `user_id` int(11) NOT NULL,
            `record_type` enum('night_shift','night_help','help_night') NOT NULL,
            `quantity` int(11) NOT NULL,
            `record_date` date NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `plan_id` (`plan_id`),
            KEY `user_id` (`user_id`),
            CONSTRAINT `shift_records_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `production_plans` (`id`),
            CONSTRAINT `shift_records_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ shift_records 表创建成功\n\n";
    
    $pdo->commit();
    
    echo "</pre>";
    echo "<h3 style='color: green;'>✓ 所有数据库表创建成功！</h3>";
    echo "<hr>";
    echo "<h4>下一步操作：</h4>";
    echo "<ol>";
    echo "<li>表结构已创建完成</li>";
    echo "<li>请从 <code>backups</code> 文件夹中的SQL备份文件导入数据</li>";
    echo "<li>可以使用以下命令导入数据（在MySQL命令行中）：</li>";
    echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px;'>";
    echo "mysql -u " . DB_USER . " -p" . DB_NAME . " < backups/backup_2025-12-23_08-58-29.sql";
    echo "</pre>";
    echo "<li>或者使用phpMyAdmin等工具导入备份文件</li>";
    echo "</ol>";
    echo "<p><a href='index.php' class='btn btn-primary'>返回主页</a></p>";
    
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "</pre>";
    echo "<h3 style='color: red;'>✗ 创建表失败</h3>";
    echo "<p style='color: red;'>错误信息：" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><a href='index.php'>返回主页</a></p>";
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>创建数据库表</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        pre {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #007bff;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        h3 {
            margin-top: 20px;
        }
        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            color: #e83e8c;
        }
        .btn {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- PHP输出内容会显示在这里 -->
    </div>
</body>
</html>

