<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 获取用户信息
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>不迷路 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .navigation-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        .navigation-header {
            background-color: #f8f9fa;
            padding: 15px 20px;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        .navigation-body {
            padding: 20px;
        }
        .nav-link-item {
            display: block;
            padding: 12px 15px;
            margin-bottom: 8px;
            background-color: #f8f9fa;
            border-radius: 8px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        .nav-link-item:hover {
            background-color: #e9ecef;
            color: #007bff;
            border-left-color: #007bff;
            text-decoration: none;
        }
        .nav-link-item .link-title {
            font-weight: 600;
            margin-bottom: 2px;
        }
        .nav-link-item .link-desc {
            font-size: 12px;
            color: #666;
        }
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #007bff;
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .navigation-body {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_dashboard.php?page=users">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">🧭 不迷路导航</h1>
        </div>

        <!-- 主要功能区 -->
        <div class="navigation-card">
            <div class="navigation-header">
                📋 主要功能
            </div>
            <div class="navigation-body">
                <div class="row">
                    <div class="col-md-6">
                        <a href="index.php" class="nav-link-item">
                            <div class="link-title">📦 排产计划管理</div>
                            <div class="link-desc">当前主页 - 创建计划、出库操作</div>
                        </a>
                        <a href="daily_report.php" class="nav-link-item">
                            <div class="link-title">📊 出库日报表</div>
                            <div class="link-desc">按班次查看出库统计</div>
                        </a>
                        <a href="report.php" class="nav-link-item">
                            <div class="link-title">📈 一键报表</div>
                            <div class="link-desc">详细出库报表，支持复制</div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="js.php" class="nav-link-item">
                            <div class="link-title">🧮 尾数计算</div>
                            <div class="link-desc">计划调整量计算器</div>
                        </a>
                        <a href="repeat_check.php" class="nav-link-item">
                            <div class="link-title">🔍 重复检测</div>
                            <div class="link-desc">检查重复出库记录</div>
                        </a>
                        <?php if ($is_admin): ?>
                        <a href="admin_dashboard.php?page=users" class="nav-link-item">
                            <div class="link-title">👥 用户管理</div>
                            <div class="link-desc">管理系统用户账户</div>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- 历史版本区 -->
        <div class="navigation-card">
            <div class="navigation-header">
                🕒 历史版本
            </div>
            <div class="navigation-body">
                <a href="zuoindex.php" class="nav-link-item">
                    <div class="link-title">📦 出库昨天</div>
                    <div class="link-desc">昨天出库功能版本</div>
                </a>
            </div>
        </div>

        <!-- 工具区 -->
        <div class="navigation-card">
            <div class="navigation-header">
                🔧 系统工具
            </div>
            <div class="navigation-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php if ($is_admin || $is_storage): ?>
                        <a href="backup.php" class="nav-link-item">
                            <div class="link-title">💾 备份管理</div>
                            <div class="link-desc">数据备份和恢复</div>
                        </a>
                        <?php endif; ?>
                        <a href="change_password.php" class="nav-link-item">
                            <div class="link-title">🔑 修改密码</div>
                            <div class="link-desc">更改登录密码</div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="logout.php" class="nav-link-item">
                            <div class="link-title">🚪 退出登录</div>
                            <div class="link-desc">安全退出系统</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- 返回按钮 -->
        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-primary btn-lg">
                🏠 返回主页
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>