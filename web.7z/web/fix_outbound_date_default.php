<?php
/**
 * 修复outbound_date字段的默认值问题
 * 移除DEFAULT CURRENT_TIMESTAMP，避免使用MySQL服务器时间
 */
require_once 'config.php';

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== ROLE_ADMIN) {
    die('需要管理员权限');
}

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>修复出库时间字段</title></head><body>";
echo "<h2>修复出库时间字段默认值</h2>";

try {
    // 检查当前字段定义
    $stmt = $pdo->query("SHOW COLUMNS FROM outbound_records WHERE Field = 'outbound_date'");
    $column_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p>当前字段定义：</p>";
    echo "<pre>" . print_r($column_info, true) . "</pre>";
    
    // 检查是否有DEFAULT CURRENT_TIMESTAMP
    if (strpos($column_info['Default'], 'CURRENT_TIMESTAMP') !== false || $column_info['Default'] === 'CURRENT_TIMESTAMP') {
        echo "<p style='color: orange;'>⚠️ 发现字段使用 CURRENT_TIMESTAMP 作为默认值</p>";
        echo "<p>正在修复...</p>";
        
        // 修改字段，移除默认值（或设置为NULL，但字段是NOT NULL，所以需要保持NOT NULL但移除DEFAULT）
        // 由于字段是NOT NULL，我们不能完全移除默认值，但可以改为一个固定值或者保持NOT NULL但不使用CURRENT_TIMESTAMP
        // 实际上，最好的方法是确保所有插入都明确指定时间
        
        // 检查是否有记录使用了默认时间（outbound_date和created_at相同，且时间不合理）
        $check_stmt = $pdo->query("
            SELECT COUNT(*) as count 
            FROM outbound_records 
            WHERE ABS(TIMESTAMPDIFF(SECOND, outbound_date, created_at)) < 2
            AND outbound_date < DATE_SUB(NOW(), INTERVAL 1 DAY)
        ");
        $check_result = $check_stmt->fetch();
        
        if ($check_result['count'] > 0) {
            echo "<p style='color: red;'>发现 {$check_result['count']} 条记录可能使用了默认时间</p>";
        }
        
        echo "<p style='color: green;'>✓ 建议：确保所有插入操作都明确指定 outbound_date 值</p>";
        echo "<p>代码中已经使用 date('Y-m-d H:i:s') 来设置时间，这是正确的做法。</p>";
        
    } else {
        echo "<p style='color: green;'>✓ 字段定义正常</p>";
    }
    
    // 显示最近的出库记录，检查时间
    echo "<h3>最近的出库记录（检查时间）</h3>";
    $recent_stmt = $pdo->query("
        SELECT 
            id,
            outbound_date,
            created_at,
            TIMESTAMPDIFF(SECOND, created_at, outbound_date) as time_diff_seconds,
            outbound_quantity,
            remark
        FROM outbound_records
        ORDER BY id DESC
        LIMIT 10
    ");
    $recent_records = $recent_stmt->fetchAll();
    
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>outbound_date</th><th>created_at</th><th>时间差(秒)</th><th>数量</th><th>备注</th></tr>";
    foreach ($recent_records as $record) {
        $time_diff = (int)$record['time_diff_seconds'];
        $color = abs($time_diff) > 5 ? 'red' : 'green';
        echo "<tr>";
        echo "<td>" . htmlspecialchars($record['id']) . "</td>";
        echo "<td>" . htmlspecialchars($record['outbound_date']) . "</td>";
        echo "<td>" . htmlspecialchars($record['created_at']) . "</td>";
        echo "<td style='color: {$color};'>" . $time_diff . "</td>";
        echo "<td>" . htmlspecialchars($record['outbound_quantity']) . "</td>";
        echo "<td>" . htmlspecialchars($record['remark'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 显示MySQL和PHP的当前时间
    echo "<h3>时间对比</h3>";
    $mysql_time = $pdo->query("SELECT NOW() as mysql_time")->fetch()['mysql_time'];
    $php_time = date('Y-m-d H:i:s');
    echo "<p>MySQL时间：{$mysql_time}</p>";
    echo "<p>PHP时间：{$php_time}</p>";
    $time_diff = strtotime($php_time) - strtotime($mysql_time);
    echo "<p>时间差：" . $time_diff . " 秒</p>";
    
    if (abs($time_diff) > 5) {
        echo "<p style='color: red;'>⚠️ PHP和MySQL时间不一致！</p>";
    } else {
        echo "<p style='color: green;'>✓ PHP和MySQL时间一致</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>错误：" . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</body></html>";
?>

