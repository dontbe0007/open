<?php
/**
 * 获取网站设置的辅助函数
 * 可在前台页面中使用
 */

require_once 'config.php';

/**
 * 获取网站设置值
 * @param string $key 设置键名
 * @param string $default 默认值
 * @return string 设置值
 */
function get_site_setting($key, $default = '') {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetchColumn();
        return $result !== false ? $result : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

/**
 * 获取所有网站设置
 * @return array 所有设置的关联数组
 */
function get_all_site_settings() {
    global $pdo;
    
    $settings = [];
    try {
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    } catch (PDOException $e) {
        // 忽略错误，返回空数组
    }
    
    return $settings;
}



