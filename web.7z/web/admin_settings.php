<?php
// 网站设置管理页面
// 注意：此文件被admin_dashboard.php包含，变量$pdo, $user_id, $username已定义
// 但需要确保operation_logs_helper.php已加载
if (!function_exists('log_operation')) {
    require_once 'operation_logs_helper.php';
}

$settings_success = '';
$settings_error = '';

// 检查表是否存在，如果不存在则创建
$settings_table_exists = false;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'site_settings'");
    $settings_table_exists = $check_table->rowCount() > 0;
} catch (PDOException $e) {
    $settings_table_exists = false;
}

// 如果表不存在，尝试创建
if (!$settings_table_exists) {
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `site_settings` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
                `setting_value` text COLLATE utf8mb4_unicode_ci,
                `setting_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'text, image, textarea',
                `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `setting_key` (`setting_key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        
        // 插入默认设置
        $default_settings = [
            ['site_name', '仓库管理系统', 'text', '网站名称'],
            ['site_keywords', '仓库管理,出库管理,入库管理,库存管理', 'text', '网站关键字'],
            ['site_description', '专业的仓库管理系统', 'text', '网站描述'],
            ['site_logo', '', 'image', '网站Logo（头部）'],
            ['footer_logo', '', 'image', '底部Logo'],
            ['footer_text', '© 2025 仓库管理系统 版权所有', 'text', '底部版权文字'],
            ['head_seo', '', 'textarea', '头部SEO代码（如统计代码、广告代码等）'],
            ['footer_seo', '', 'textarea', '底部SEO代码'],
            ['contact_phone', '', 'text', '联系电话'],
            ['contact_email', '', 'text', '联系邮箱'],
            ['contact_address', '', 'text', '联系地址'],
        ];
        
        foreach ($default_settings as $setting) {
            $stmt = $pdo->prepare("
                INSERT INTO site_settings (setting_key, setting_value, setting_type, description) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute($setting);
        }
        
        $settings_table_exists = true;
        $settings_success = '网站设置表已自动创建！';
    } catch (PDOException $e) {
        $settings_error = "创建表失败：" . $e->getMessage();
    }
}

// 处理设置保存
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_settings'])) {
    if (!$settings_table_exists) {
        $settings_error = "网站设置表不存在，无法保存设置。";
    } else {
        try {
            $pdo->beginTransaction();
        
        // 处理文件上传（Logo）
        $upload_dir = 'uploads/settings/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // 处理头部Logo上传
        if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['site_logo'];
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (in_array($file_ext, $allowed_exts)) {
                $new_filename = 'logo_' . time() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                    // 删除旧logo
                    $old_logo = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'site_logo'")->fetchColumn();
                    if ($old_logo && file_exists($old_logo)) {
                        @unlink($old_logo);
                    }
                    
                    $_POST['site_logo'] = $upload_path;
                }
            }
        } else {
            // 如果没有上传新文件，保持原值
            $old_logo = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'site_logo'")->fetchColumn();
            $_POST['site_logo'] = $old_logo ?: '';
        }
        
        // 处理底部Logo上传
        if (isset($_FILES['footer_logo']) && $_FILES['footer_logo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['footer_logo'];
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (in_array($file_ext, $allowed_exts)) {
                $new_filename = 'footer_logo_' . time() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                    // 删除旧logo
                    $old_logo = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'footer_logo'")->fetchColumn();
                    if ($old_logo && file_exists($old_logo)) {
                        @unlink($old_logo);
                    }
                    
                    $_POST['footer_logo'] = $upload_path;
                }
            }
        } else {
            // 如果没有上传新文件，保持原值
            $old_logo = $pdo->query("SELECT setting_value FROM site_settings WHERE setting_key = 'footer_logo'")->fetchColumn();
            $_POST['footer_logo'] = $old_logo ?: '';
        }
        
        // 保存所有设置
        $settings_to_save = [
            'site_name', 'site_keywords', 'site_description', 'site_logo', 'footer_logo',
            'footer_text', 'head_seo', 'footer_seo', 'contact_phone', 'contact_email', 'contact_address'
        ];
        
        foreach ($settings_to_save as $key) {
            $value = $_POST[$key] ?? '';
            
            $stmt = $pdo->prepare("
                INSERT INTO site_settings (setting_key, setting_value) 
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE setting_value = ?
            ");
            $stmt->execute([$key, $value, $value]);
        }
        
        $pdo->commit();
        
        // 记录操作日志
        $operation_logs_exists = false;
        try {
            $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
            $operation_logs_exists = $check_table->rowCount() > 0;
        } catch (PDOException $e) {}
        
        if ($operation_logs_exists) {
            log_operation($pdo, $user_id, $username, 'update_user', 'system', null, null,
                "更新网站设置", null, null);
        }
        
            $settings_success = '网站设置保存成功！';
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $settings_error = '保存失败：' . $e->getMessage();
        }
    }
}

// 获取所有设置
$settings = [];
if ($settings_table_exists) {
    try {
        $stmt = $pdo->query("SELECT setting_key, setting_value, setting_type, description FROM site_settings");
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $row) {
            $settings[$row['setting_key']] = [
                'value' => $row['setting_value'],
                'type' => $row['setting_type'],
                'description' => $row['description']
            ];
        }
    } catch (PDOException $e) {
        $settings_error = "获取设置失败：" . $e->getMessage();
    }
}

// 设置默认值
$defaults = [
    'site_name' => ['value' => '', 'type' => 'text', 'description' => '网站名称'],
    'site_keywords' => ['value' => '', 'type' => 'text', 'description' => '网站关键字'],
    'site_description' => ['value' => '', 'type' => 'text', 'description' => '网站描述'],
    'site_logo' => ['value' => '', 'type' => 'image', 'description' => '网站Logo（头部）'],
    'footer_logo' => ['value' => '', 'type' => 'image', 'description' => '底部Logo'],
    'footer_text' => ['value' => '', 'type' => 'text', 'description' => '底部版权文字'],
    'head_seo' => ['value' => '', 'type' => 'textarea', 'description' => '头部SEO代码'],
    'footer_seo' => ['value' => '', 'type' => 'textarea', 'description' => '底部SEO代码'],
    'contact_phone' => ['value' => '', 'type' => 'text', 'description' => '联系电话'],
    'contact_email' => ['value' => '', 'type' => 'text', 'description' => '联系邮箱'],
    'contact_address' => ['value' => '', 'type' => 'text', 'description' => '联系地址'],
];

foreach ($defaults as $key => $default) {
    if (!isset($settings[$key])) {
        $settings[$key] = $default;
    } else {
        $settings[$key]['description'] = $default['description'];
    }
}
?>

<div class="content-header">
    <h2><i class="bi bi-gear"></i> 网站设置</h2>
</div>

<div class="content-body">
    <?php if (!empty($settings_success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($settings_success); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($settings_error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($settings_error); ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="save_settings" value="1">
        
        <!-- 基本信息 -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-info-circle"></i> 基本信息</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label">网站名称</label>
                        <input type="text" name="site_name" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_name']['value']); ?>" 
                               placeholder="请输入网站名称">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['site_name']['description']); ?></small>
                    </div>
                    
                    <div class="col-md-12">
                        <label class="form-label">网站关键字</label>
                        <input type="text" name="site_keywords" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_keywords']['value']); ?>" 
                               placeholder="关键字1,关键字2,关键字3">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['site_keywords']['description']); ?></small>
                    </div>
                    
                    <div class="col-md-12">
                        <label class="form-label">网站描述</label>
                        <textarea name="site_description" class="form-control" rows="3" 
                                  placeholder="请输入网站描述"><?php echo htmlspecialchars($settings['site_description']['value']); ?></textarea>
                        <small class="text-muted"><?php echo htmlspecialchars($settings['site_description']['description']); ?></small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Logo设置 -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-image"></i> Logo设置</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">网站Logo（头部）</label>
                        <?php if (!empty($settings['site_logo']['value']) && file_exists($settings['site_logo']['value'])): ?>
                            <div class="mb-2">
                                <img src="<?php echo htmlspecialchars($settings['site_logo']['value']); ?>" 
                                     alt="当前Logo" style="max-height: 100px; border: 1px solid #ddd; padding: 5px; border-radius: 5px;">
                            </div>
                        <?php endif; ?>
                        <input type="file" name="site_logo" class="form-control" accept="image/*">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['site_logo']['description']); ?>（支持 jpg, png, gif, webp）</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">底部Logo</label>
                        <?php if (!empty($settings['footer_logo']['value']) && file_exists($settings['footer_logo']['value'])): ?>
                            <div class="mb-2">
                                <img src="<?php echo htmlspecialchars($settings['footer_logo']['value']); ?>" 
                                     alt="当前底部Logo" style="max-height: 100px; border: 1px solid #ddd; padding: 5px; border-radius: 5px;">
                            </div>
                        <?php endif; ?>
                        <input type="file" name="footer_logo" class="form-control" accept="image/*">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['footer_logo']['description']); ?>（支持 jpg, png, gif, webp）</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SEO设置 -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-code-square"></i> SEO设置</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label">头部SEO代码</label>
                        <textarea name="head_seo" class="form-control" rows="5" 
                                  placeholder="可在此处添加统计代码、广告代码等（将插入到 &lt;/head&gt; 标签之前）"><?php echo htmlspecialchars($settings['head_seo']['value']); ?></textarea>
                        <small class="text-muted"><?php echo htmlspecialchars($settings['head_seo']['description']); ?>（如：Google Analytics、百度统计等）</small>
                    </div>
                    
                    <div class="col-md-12">
                        <label class="form-label">底部SEO代码</label>
                        <textarea name="footer_seo" class="form-control" rows="5" 
                                  placeholder="可在此处添加统计代码、广告代码等（将插入到 &lt;/body&gt; 标签之前）"><?php echo htmlspecialchars($settings['footer_seo']['value']); ?></textarea>
                        <small class="text-muted"><?php echo htmlspecialchars($settings['footer_seo']['description']); ?></small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 底部信息 -->
        <div class="card mb-4">
            <div class="card-header bg-secondary text-white">
                <h5 class="mb-0"><i class="bi bi-file-text"></i> 底部信息</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label">底部版权文字</label>
                        <input type="text" name="footer_text" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['footer_text']['value']); ?>" 
                               placeholder="如：© 2025 仓库管理系统 版权所有">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['footer_text']['description']); ?></small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 联系信息 -->
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-telephone"></i> 联系信息</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">联系电话</label>
                        <input type="text" name="contact_phone" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['contact_phone']['value']); ?>" 
                               placeholder="请输入联系电话">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['contact_phone']['description']); ?></small>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">联系邮箱</label>
                        <input type="email" name="contact_email" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['contact_email']['value']); ?>" 
                               placeholder="请输入联系邮箱">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['contact_email']['description']); ?></small>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">联系地址</label>
                        <input type="text" name="contact_address" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['contact_address']['value']); ?>" 
                               placeholder="请输入联系地址">
                        <small class="text-muted"><?php echo htmlspecialchars($settings['contact_address']['description']); ?></small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 提交按钮 -->
        <div class="text-center">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-save"></i> 保存设置
            </button>
            <a href="admin_dashboard.php?page=dashboard" class="btn btn-secondary btn-lg">
                <i class="bi bi-arrow-left"></i> 返回
            </a>
        </div>
    </form>
</div>

