<?php
/**
 * 后台管理仪表板
 * 提供系统概览和快捷管理入口
 * Dedecms风格布局
 */

session_start();
require_once 'config.php';
require_once 'safe_require.php';

// 检查是否已登录且是管理员
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== ROLE_ADMIN) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// 处理备份管理
$backup_success = '';
$backup_error = '';
if (isset($_POST['backup'])) {
    try {
        // 创建备份目录
        $backup_dir = 'backups';
        if (!file_exists($backup_dir)) {
            mkdir($backup_dir, 0777, true);
        }

        // 生成备份文件名
        $backup_file = $backup_dir . '/backup_' . date('Y-m-d_H-i-s') . '.sql';
        
        // 获取所有表名
        $tables = array();
        $result = $pdo->query("SHOW TABLES");
        while ($row = $result->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }

        // 开始备份
        $output = '';
        foreach ($tables as $table) {
            // 获取表结构
            $result = $pdo->query("SHOW CREATE TABLE $table");
            $row = $result->fetch(PDO::FETCH_NUM);
            $output .= "\n\n" . $row[1] . ";\n\n";

            // 获取表数据
            $result = $pdo->query("SELECT * FROM $table");
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $row = array_map(function($value) use ($pdo) {
                    if ($value === null) {
                        return 'NULL';
                    }
                    return $pdo->quote($value);
                }, $row);

                $output .= "INSERT INTO $table VALUES (" . implode(',', $row) . ");\n";
            }
        }

        // 保存备份文件
        file_put_contents($backup_file, $output);
        
        // 记录操作日志
        $operation_logs_exists = false;
        try {
            $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
            $operation_logs_exists = $check_table->rowCount() > 0;
        } catch (PDOException $e) {}
        
        if ($operation_logs_exists) {
            log_operation($pdo, $user_id, $username, 'backup', 'system', null, null,
                "创建数据库备份：{$backup_file}", null, null);
        }
        
        $backup_success = '数据库备份成功！文件：' . basename($backup_file);
    } catch(PDOException $e) {
        $backup_error = '备份失败：' . $e->getMessage();
    }
}

// 处理恢复备份
if (isset($_POST['restore'])) {
    try {
        if (isset($_FILES['backup_file'])) {
            $file = $_FILES['backup_file'];
            if ($file['error'] === UPLOAD_ERR_OK) {
                $temp_file = $file['tmp_name'];
                $sql = file_get_contents($temp_file);
            } else {
                throw new Exception('文件上传失败');
            }
        } else if (isset($_POST['backup_file'])) {
            $backup_file = 'backups/' . $_POST['backup_file'];
            if (!file_exists($backup_file)) {
                throw new Exception('备份文件不存在');
            }
            $sql = file_get_contents($backup_file);
        } else {
            throw new Exception('未指定备份文件');
        }
        
        $pdo->beginTransaction();
        $pdo->exec($sql);
        $pdo->commit();
        
        $operation_logs_exists = false;
        try {
            $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
            $operation_logs_exists = $check_table->rowCount() > 0;
        } catch (PDOException $e) {}
        
        if ($operation_logs_exists) {
            log_operation($pdo, $user_id, $username, 'restore', 'system', null, null,
                "恢复数据库备份", null, null);
        }
        
        $backup_success = '数据库恢复成功！';
    } catch(Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $backup_error = '恢复失败：' . $e->getMessage();
    }
}

// 获取备份文件列表
$backup_files = array();
$backup_dir = 'backups';
if (file_exists($backup_dir)) {
    $files = glob($backup_dir . '/*.sql');
    foreach ($files as $file) {
        $backup_files[] = array(
            'name' => basename($file),
            'size' => filesize($file),
            'date' => date('Y-m-d H:i:s', filemtime($file))
        );
    }
    usort($backup_files, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
}

// 处理用户管理
$user_success = '';
$user_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_action'])) {
    if ($_POST['user_action'] == 'add') {
        $new_username = $_POST['username'] ?? '';
        $new_password = $_POST['password'] ?? '';
        $new_role = $_POST['role'] ?? 'user';

        if (!empty($new_username) && !empty($new_password)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
                $stmt->execute([$new_username, password_hash($new_password, PASSWORD_DEFAULT), $new_role]);
                
                $new_user_id = $pdo->lastInsertId();
                
                $operation_logs_exists = false;
                try {
                    $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
                    $operation_logs_exists = $check_table->rowCount() > 0;
                } catch (PDOException $e) {}
                
                if ($operation_logs_exists) {
                    log_operation($pdo, $user_id, $username, 'create_user', 'user', $new_user_id, 'user',
                        "创建用户：{$new_username}（角色：{$new_role}）", null, ['username' => $new_username, 'role' => $new_role]);
                }
                
                $user_success = "用户 {$new_username} 创建成功！";
            } catch(PDOException $e) {
                $user_error = "添加用户失败：" . $e->getMessage();
            }
        }
    } elseif ($_POST['user_action'] == 'delete' && isset($_POST['user_id'])) {
        try {
            $get_user_stmt = $pdo->prepare("SELECT username, role FROM users WHERE id = ?");
            $get_user_stmt->execute([$_POST['user_id']]);
            $deleted_user = $get_user_stmt->fetch();
            
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND id != ?");
            $stmt->execute([$_POST['user_id'], $user_id]);
            
            if ($stmt->rowCount() > 0 && $deleted_user) {
                $operation_logs_exists = false;
                try {
                    $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
                    $operation_logs_exists = $check_table->rowCount() > 0;
                } catch (PDOException $e) {}
                
                if ($operation_logs_exists) {
                    log_operation($pdo, $user_id, $username, 'delete_user', 'user', $_POST['user_id'], 'user',
                        "删除用户：{$deleted_user['username']}（角色：{$deleted_user['role']}）",
                        ['username' => $deleted_user['username'], 'role' => $deleted_user['role']], null);
                }
                
                $user_success = "用户 {$deleted_user['username']} 删除成功！";
            }
        } catch(PDOException $e) {
            $user_error = "删除用户失败：" . $e->getMessage();
        }
    }
}

// 获取所有用户
$all_users = [];
try {
    $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
    $all_users = $stmt->fetchAll();
} catch(PDOException $e) {
    $user_error = "获取用户列表失败：" . $e->getMessage();
}

// 处理删除指定时间计划
$delete_success = '';
$delete_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_plans_by_date'])) {
    try {
        $start_date = $_POST['start_date'] ?? '';
        $end_date = $_POST['end_date'] ?? '';
        
        if (empty($start_date) || empty($end_date)) {
            throw new Exception('请选择开始和结束日期');
        }
        
        if ($start_date > $end_date) {
            throw new Exception('开始日期不能大于结束日期');
        }
        
        $count_stmt = $pdo->prepare("
            SELECT COUNT(*) as count 
            FROM production_plans 
            WHERE DATE(plan_date) BETWEEN ? AND ? AND deleted_at IS NULL
        ");
        $count_stmt->execute([$start_date, $end_date]);
        $plan_count = $count_stmt->fetch()['count'];
        
        if ($plan_count == 0) {
            throw new Exception('指定日期范围内没有可删除的计划');
        }
        
        $stmt = $pdo->prepare("
            UPDATE production_plans 
            SET deleted_at = NOW() 
            WHERE DATE(plan_date) BETWEEN ? AND ? AND deleted_at IS NULL
        ");
        $stmt->execute([$start_date, $end_date]);
        
        $deleted_count = $stmt->rowCount();
        
        $operation_logs_exists = false;
        try {
            $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
            $operation_logs_exists = $check_table->rowCount() > 0;
        } catch (PDOException $e) {}
        
        if ($operation_logs_exists) {
            log_operation($pdo, $user_id, $username, 'delete_plan', 'plan', null, 'plan',
                "批量删除计划：日期范围 {$start_date} 至 {$end_date}，共删除 {$deleted_count} 条计划",
                ['start_date' => $start_date, 'end_date' => $end_date, 'count' => $deleted_count], null);
        }
        
        $delete_success = "成功删除 {$deleted_count} 条计划，已移至回收站！";
    } catch (Exception $e) {
        $delete_error = '删除失败：' . $e->getMessage();
    }
}

// 获取当前页面
$current_page = $_GET['page'] ?? 'dashboard';

// 初始化变量
$user_count = 0;
$active_users = 0;
$plan_count = 0;
$today_plans = 0;
$today_outbound = ['count' => 0, 'total' => 0];
$today_inbound = ['count' => 0, 'total' => 0];
$inventory_count = ['count' => 0, 'total' => 0];
$today_logs = 0;
$recent_logs = [];
$recent_users = [];
$error = '';

// 检查 operation_logs 表是否存在
$operation_logs_exists = false;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
    $operation_logs_exists = $check_table->rowCount() > 0;
} catch (PDOException $e) {}

// 获取统计数据
try {
    $user_count = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
    
    if ($operation_logs_exists) {
        try {
            $active_users = $pdo->query("SELECT COUNT(DISTINCT user_id) as count FROM operation_logs WHERE DATE(created_at) = CURDATE()")->fetch()['count'];
        } catch (PDOException $e) {
            $active_users = 0;
        }
    }
    
    $plan_count = $pdo->query("SELECT COUNT(*) as count FROM production_plans WHERE deleted_at IS NULL")->fetch()['count'];
    $today_plans = $pdo->query("SELECT COUNT(*) as count FROM production_plans WHERE DATE(created_at) = CURDATE() AND deleted_at IS NULL")->fetch()['count'];
    
    $outbound_result = $pdo->query("SELECT COUNT(*) as count, COALESCE(SUM(outbound_quantity), 0) as total FROM outbound_records WHERE DATE(outbound_date) = CURDATE()")->fetch();
    $today_outbound = ['count' => $outbound_result['count'] ?? 0, 'total' => $outbound_result['total'] ?? 0];
    
    $inbound_result = $pdo->query("SELECT COUNT(*) as count, COALESCE(SUM(inbound_quantity), 0) as total FROM inbound_records WHERE DATE(inbound_date) = CURDATE()")->fetch();
    $today_inbound = ['count' => $inbound_result['count'] ?? 0, 'total' => $inbound_result['total'] ?? 0];
    
    $inventory_result = $pdo->query("SELECT COUNT(*) as count, COALESCE(SUM(quantity), 0) as total FROM inventory WHERE deleted_at IS NULL")->fetch();
    $inventory_count = ['count' => $inventory_result['count'] ?? 0, 'total' => $inventory_result['total'] ?? 0];
    
    if ($operation_logs_exists) {
        try {
            $today_logs = $pdo->query("SELECT COUNT(*) as count FROM operation_logs WHERE DATE(created_at) = CURDATE()")->fetch()['count'];
            $recent_logs = $pdo->query("SELECT * FROM operation_logs ORDER BY created_at DESC LIMIT 10")->fetchAll();
        } catch (PDOException $e) {
            $today_logs = 0;
            $recent_logs = [];
        }
    }
    
    $recent_users = $pdo->query("SELECT username, last_login FROM users WHERE last_login IS NOT NULL ORDER BY last_login DESC LIMIT 5")->fetchAll();
    
} catch (PDOException $e) {
    $error = "获取统计数据失败：" . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: #f5f5f5;
            font-family: "Microsoft YaHei", Arial, sans-serif;
        }
        
        /* 顶部导航栏 */
        .top-navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 60px;
        }
        
        .top-navbar .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 18px;
            padding: 15px 20px;
        }
        
        .top-navbar .user-info {
            padding: 15px 20px;
            color: white;
        }
        
        .top-navbar .user-info a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
        }
        
        /* 左侧菜单 */
        .sidebar {
            position: fixed;
            left: 0;
            top: 60px;
            width: 220px;
            height: calc(100vh - 60px);
            background: #2c3e50;
            overflow-y: auto;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .menu-group {
            margin: 0;
        }
        
        .menu-group-title {
            padding: 12px 20px;
            color: #95a5a6;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            background: #34495e;
            border-bottom: 1px solid #3d5266;
        }
        
        .menu-item {
            border-bottom: 1px solid #34495e;
        }
        
        .menu-item a {
            display: block;
            padding: 12px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .menu-item a:hover {
            background: #34495e;
            border-left-color: #3498db;
            color: white;
        }
        
        .menu-item.active a {
            background: #3498db;
            border-left-color: #2980b9;
            color: white;
        }
        
        .menu-item a i {
            width: 20px;
            margin-right: 10px;
        }
        
        /* 主内容区 */
        .main-content {
            margin-left: 220px;
            margin-top: 60px;
            padding: 20px;
            min-height: calc(100vh - 60px);
        }
        
        .content-header {
            background: white;
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .content-header h2 {
            margin: 0;
            font-size: 20px;
            color: #2c3e50;
        }
        
        .content-body {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        /* 统计卡片 */
        .stat-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border-left: 4px solid;
            transition: transform 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        
        .stat-card.primary { border-left-color: #3498db; }
        .stat-card.success { border-left-color: #2ecc71; }
        .stat-card.info { border-left-color: #1abc9c; }
        .stat-card.warning { border-left-color: #f39c12; }
        .stat-card.danger { border-left-color: #e74c3c; }
        .stat-card.secondary { border-left-color: #95a5a6; }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .stat-label {
            color: #7f8c8d;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        
        /* 表格样式 */
        .table {
            font-size: 14px;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        
        /* 响应式 */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- 顶部导航栏 -->
    <nav class="top-navbar">
        <div class="d-flex justify-content-between align-items-center">
            <div class="navbar-brand">
                <i class="bi bi-speedometer2"></i> 仓库管理系统 - 后台管理
            </div>
            <div class="user-info">
                <span>欢迎，<?php echo htmlspecialchars($username); ?></span>
                <a href="index.php"><i class="bi bi-house"></i> 返回前台</a>
                <a href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a>
            </div>
        </div>
    </nav>

    <!-- 左侧菜单 -->
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li class="menu-group">
                <div class="menu-group-title">系统概览</div>
                <div class="menu-item <?php echo $current_page == 'dashboard' ? 'active' : ''; ?>">
                    <a href="?page=dashboard">
                        <i class="bi bi-speedometer2"></i> 仪表盘
                    </a>
                </div>
            </li>
            
            <li class="menu-group">
                <div class="menu-group-title">内容管理</div>
                <div class="menu-item <?php echo $current_page == 'plans' ? 'active' : ''; ?>">
                    <a href="index.php">
                        <i class="bi bi-clipboard-check"></i> 生产计划
                    </a>
                </div>
                <div class="menu-item <?php echo $current_page == 'inventory' ? 'active' : ''; ?>">
                    <a href="inventory.php">
                        <i class="bi bi-boxes"></i> 库存管理
                    </a>
                </div>
                <div class="menu-item <?php echo $current_page == 'delete_plans' ? 'active' : ''; ?>">
                    <a href="?page=delete_plans">
                        <i class="bi bi-trash"></i> 批量删除计划
                    </a>
                </div>
            </li>
            
            <li class="menu-group">
                <div class="menu-group-title">用户管理</div>
                <div class="menu-item <?php echo $current_page == 'users' ? 'active' : ''; ?>">
                    <a href="?page=users">
                        <i class="bi bi-people"></i> 用户列表
                    </a>
                </div>
            </li>
            
            <li class="menu-group">
                <div class="menu-group-title">系统维护</div>
                <div class="menu-item <?php echo $current_page == 'settings' ? 'active' : ''; ?>">
                    <a href="?page=settings">
                        <i class="bi bi-gear"></i> 网站设置
                    </a>
                </div>
                <div class="menu-item <?php echo $current_page == 'templates' ? 'active' : ''; ?>">
                    <a href="?page=templates">
                        <i class="bi bi-palette"></i> 模板管理
                    </a>
                </div>
                <div class="menu-item <?php echo $current_page == 'backup' ? 'active' : ''; ?>">
                    <a href="?page=backup">
                        <i class="bi bi-database"></i> 数据备份
                    </a>
                </div>
                <div class="menu-item <?php echo $current_page == 'logs' ? 'active' : ''; ?>">
                    <a href="operation_logs.php">
                        <i class="bi bi-journal-text"></i> 操作日志
                    </a>
                </div>
            </li>
            
            <li class="menu-group">
                <div class="menu-group-title">报表统计</div>
                <div class="menu-item">
                    <a href="daily_report.php">
                        <i class="bi bi-graph-up"></i> 出库日报表
                    </a>
                </div>
                <div class="menu-item">
                    <a href="inbound_report.php">
                        <i class="bi bi-graph-down"></i> 入库日报表
                    </a>
                </div>
                <div class="menu-item">
                    <a href="report.php">
                        <i class="bi bi-file-earmark-text"></i> 一键报表
                    </a>
                </div>
            </li>
        </ul>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger">
                <strong>错误：</strong><?php echo htmlspecialchars($error); ?>
                <?php if (!$operation_logs_exists): ?>
                    <br><br>
                    <strong>提示：</strong>操作日志表不存在，请先创建操作日志表。
                    <br>
                    <a href="create_operation_logs_table.php" class="btn btn-primary btn-sm mt-2">创建操作日志表</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!$operation_logs_exists && empty($error)): ?>
            <div class="alert alert-warning">
                <strong>提示：</strong>操作日志表尚未创建，部分功能可能无法使用。
                <br>
                <a href="create_operation_logs_table.php" class="btn btn-primary btn-sm mt-2">立即创建操作日志表</a>
            </div>
        <?php endif; ?>

        <?php
        // 根据页面参数显示不同内容
        if ($current_page == 'settings' || isset($_POST['save_settings'])) {
            include 'admin_settings.php';
        } elseif ($current_page == 'templates' || isset($_POST['switch_template'])) {
            include 'admin_templates.php';
        } elseif ($current_page == 'users' || isset($_POST['user_action'])) {
            include 'admin_users.php';
        } elseif ($current_page == 'backup' || isset($_POST['backup']) || isset($_POST['restore'])) {
            include 'admin_backup.php';
        } elseif ($current_page == 'delete_plans' || isset($_POST['delete_plans_by_date'])) {
            include 'admin_delete_plans.php';
        } else {
            include 'admin_dashboard_content.php';
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
