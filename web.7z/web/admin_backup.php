<?php
// 备份管理页面
?>

<div class="content-header">
    <h2><i class="bi bi-database"></i> 数据备份管理</h2>
</div>

<div class="content-body">
    <?php if (!empty($backup_success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($backup_success); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($backup_error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($backup_error); ?></div>
    <?php endif; ?>
    
    <!-- 备份和恢复 -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-download"></i> 创建备份</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">创建当前数据库的完整备份文件</p>
                    <form method="POST">
                        <button type="submit" name="backup" class="btn btn-success w-100">
                            <i class="bi bi-download"></i> 立即创建备份
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0"><i class="bi bi-upload"></i> 恢复备份</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">从文件恢复数据库（将覆盖当前数据）</p>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-2">
                            <input type="file" name="backup_file" class="form-control" accept=".sql" required>
                        </div>
                        <button type="submit" name="restore" class="btn btn-warning w-100" 
                                onclick="return confirm('⚠️ 警告：确定要恢复此备份吗？\n\n这将覆盖当前数据库的所有数据，且无法撤销！');">
                            <i class="bi bi-arrow-counterclockwise"></i> 恢复数据库
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 备份文件列表 -->
    <div class="card">
        <div class="card-header bg-light">
            <h5 class="mb-0"><i class="bi bi-folder"></i> 备份文件列表</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>文件名</th>
                            <th>大小</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($backup_files)): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">暂无备份文件</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($backup_files as $file): ?>
                                <tr>
                                    <td><i class="bi bi-file-earmark-zip"></i> <?php echo htmlspecialchars($file['name']); ?></td>
                                    <td><?php echo number_format($file['size'] / 1024, 2) . ' KB'; ?></td>
                                    <td><?php echo $file['date']; ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo $backup_dir . '/' . $file['name']; ?>" 
                                               class="btn btn-sm btn-info" download>
                                                <i class="bi bi-download"></i> 下载
                                            </a>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="backup_file" value="<?php echo htmlspecialchars($file['name']); ?>">
                                                <button type="submit" name="restore" class="btn btn-sm btn-warning" 
                                                        onclick="return confirm('⚠️ 警告：确定要恢复此备份吗？\n\n这将覆盖当前数据库的所有数据！');">
                                                    <i class="bi bi-arrow-counterclockwise"></i> 恢复
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



