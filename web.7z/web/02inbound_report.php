<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 检查并添加 deleted_at 字段（如果不存在）
try {
    $check = $pdo->query("SHOW COLUMNS FROM inbound_records LIKE 'deleted_at'");
    if ($check->rowCount() == 0) {
        // 字段不存在，添加它
        $pdo->exec("
            ALTER TABLE inbound_records 
            ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL 
            AFTER inbound_date
        ");
        // 添加索引
        try {
            $pdo->exec("CREATE INDEX idx_inbound_records_deleted_at ON inbound_records(deleted_at)");
        } catch (PDOException $e) {
            // 索引可能已存在，忽略错误
        }
    }
} catch (PDOException $e) {
    // 忽略检查错误，继续执行
}

// 获取日期和班次参数
$selected_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$shift = isset($_GET['shift']) ? $_GET['shift'] : 'day'; // day: 白班, night: 夜班

// 根据班次设置时间条件和班次名称
if ($shift === 'day') {
    // 白班：07:30 - 19:30
    $time_where = "((DATE(i.inbound_date) = ? AND TIME(i.inbound_date) >= '07:30:00' AND TIME(i.inbound_date) <= '19:30:00'))";
    $params_base = [$selected_date];
    $shift_name = '白班 (07:30-19:30)';
} else {
    // 夜班：19:30 - 次日07:30
    $time_where = "((DATE(i.inbound_date) = ? AND TIME(i.inbound_date) > '19:30:00') OR (DATE(i.inbound_date) = DATE_ADD(?, INTERVAL 1 DAY) AND TIME(i.inbound_date) <= '07:30:00'))";
    $params_base = [$selected_date, $selected_date];
    $shift_name = '夜班 (19:30-次日07:30)';
}

// 获取所有产品编码的入库记录
try {
    // 根据用户角色获取数据（排除已删除的入库记录）
    if ($is_admin || $is_storage) {
        // 管理员和仓管可以看到所有数据
        $stmt = $pdo->prepare("
            SELECT 
                i.product_code,
                i.inbound_quantity,
                i.location,
                i.remark,
                i.inbound_date,
                i.id as inbound_id,
                u.username as operator_name
            FROM inbound_records i
            LEFT JOIN users u ON i.user_id = u.id
            WHERE ($time_where) AND (i.deleted_at IS NULL)
            ORDER BY i.product_code, i.inbound_date DESC
        ");
        $stmt->execute($params_base);
    } else {
        // 普通用户只能看到自己的数据
        $stmt = $pdo->prepare("
            SELECT 
                i.product_code,
                i.inbound_quantity,
                i.location,
                i.remark,
                i.inbound_date,
                i.id as inbound_id,
                u.username as operator_name
            FROM inbound_records i
            LEFT JOIN users u ON i.user_id = u.id
            WHERE i.user_id = ? AND ($time_where) AND (i.deleted_at IS NULL)
            ORDER BY i.product_code, i.inbound_date DESC
        ");
        $params = array_merge([$user_id], $params_base);
        $stmt->execute($params);
    }
    $records = $stmt->fetchAll();
    
    // 按产品编码分组
    $grouped_records = [];
    $location_stats = []; // 库位统计：按产品编码 -> 库位 -> [每次入库数量数组]
    
    foreach ($records as $record) {
        $product_code = $record['product_code'];
        $quantity = $record['inbound_quantity'];
        $location = $record['location'];
        $remark = $record['remark'] ?? '';
        
        if (!isset($grouped_records[$product_code])) {
            $grouped_records[$product_code] = [];
        }
        $grouped_records[$product_code][] = $record;
        
        // 统计库位信息：保存每次入库的数量
        if (!isset($location_stats[$product_code][$location])) {
            $location_stats[$product_code][$location] = [];
        }
        $location_stats[$product_code][$location][] = $quantity;
    }
    
    // 计算每个产品编码的总入库数量
    $product_totals = [];
    foreach ($grouped_records as $product_code => $product_records) {
        $product_totals[$product_code] = array_sum(array_column($product_records, 'inbound_quantity'));
    }
    
} catch (PDOException $e) {
    $error = '获取入库记录失败：' . $e->getMessage();
    $grouped_records = [];
    $location_stats = [];
    $product_totals = [];
}

// 复制库位统计到剪贴板
function copyLocationStats($product_code, $location_stats) {
    if (!isset($location_stats[$product_code])) {
        return '';
    }
    
    $output = [];
    foreach ($location_stats[$product_code] as $location => $quantities) {
        $output[] = $location . ': ' . implode(' ', $quantities);
    }
    return implode("\n", $output);
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>入库日报表 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .form-control, .btn {
            border-radius: 5px;
        }
        .product-section {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .product-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e9ecef;
        }
        .product-code-title {
            font-size: 20px;
            font-weight: 600;
            color: #333;
        }
        .product-total {
            font-size: 18px;
            font-weight: 600;
            color: #007bff;
        }
        .records-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 12px;
        }
        @media (min-width: 900px) {
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
        .record-item {
            display: flex;
            flex-direction: column;
            padding: 12px;
            background-color: #f8f9fa;
            border-radius: 5px;
            border-left: 3px solid #28a745;
        }
        .record-quantity {
            font-weight: 600;
            color: #333;
            font-size: 16px;
            margin-bottom: 4px;
        }
        .record-location {
            color: #28a745;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 4px;
        }
        .record-remark {
            color: #666;
            font-size: 14px;
            word-break: break-word;
        }
        .record-operator {
            color: #999;
            font-size: 12px;
            margin-top: 4px;
        }
        .location-summary {
            margin-top: 20px;
            padding: 15px;
            background-color: #d4edda;
            border: 2px solid #28a745;
            border-radius: 8px;
        }
        .location-summary-header {
            font-size: 16px;
            font-weight: 600;
            color: #155724;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #28a745;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .location-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
        }
        .location-stat-item {
            background-color: white;
            padding: 10px;
            border-radius: 6px;
            border-left: 4px solid #28a745;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .location-name {
            font-weight: 600;
            color: #333;
            font-size: 14px;
            margin-bottom: 8px;
        }
        .location-quantities {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            align-items: center;
        }
        .quantity-badge {
            display: inline-block;
            background-color: #d4edda;
            color: #155724;
            font-weight: 600;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 4px;
            border: 1px solid #c3e6cb;
            white-space: nowrap;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .nav-buttons {
            display: flex;
            gap: 10px;
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        @media (max-width: 1200px) {
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            }
            .location-stats-grid {
                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            }
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .d-flex.justify-content-between {
                flex-direction: column;
                gap: 15px;
            }
            .nav-buttons {
                flex-direction: row;
                flex-wrap: wrap;
                width: 100%;
                justify-content: flex-start;
            }
            .nav-buttons .btn {
                flex: 1;
                min-width: 120px;
                margin-bottom: 5px;
            }
            .product-section {
                padding: 15px;
            }
            .product-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            .location-summary {
                padding: 12px;
                margin-top: 15px;
            }
            .location-summary-header {
                font-size: 14px;
            }
            .location-stats-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            .location-stat-item {
                padding: 8px;
            }
            .location-name {
                font-size: 13px;
            }
            .location-quantities {
                gap: 5px;
            }
            .quantity-badge {
                font-size: 13px;
                padding: 3px 8px;
            }
        }
        @media (max-width: 480px) {
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }
            .location-stats-grid {
                grid-template-columns: 1fr;
            }
            .location-stat-item {
                padding: 10px;
            }
            .location-quantities {
                gap: 4px;
            }
            .quantity-badge {
                font-size: 12px;
                padding: 3px 6px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="report.php">一键报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="js.php">尾数计算</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="repeat_check.php">重复检测</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">入库日报表</h1>
            <div class="nav-buttons">
                <a href="inbound.php" class="btn btn-primary">产品入库</a>
                <a href="inventory.php" class="btn btn-outline-primary">库存管理</a>
            </div>
        </div>

        <!-- 筛选表单 -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">选择日期</label>
                        <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($selected_date); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">选择班次</label>
                        <select name="shift" class="form-select">
                            <option value="day" <?php echo $shift === 'day' ? 'selected' : ''; ?>>白班 (07:30-19:30)</option>
                            <option value="night" <?php echo $shift === 'night' ? 'selected' : ''; ?>>夜班 (19:30-次日07:30)</option>
                        </select>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">查询</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (empty($grouped_records)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">📦</div>
                <p>暂无入库记录</p>
            </div>
        <?php else: ?>
            <?php foreach ($grouped_records as $product_code => $product_records): ?>
                <div class="product-section">
                    <div class="product-header">
                        <div class="product-code-title">产品编码：<?php echo htmlspecialchars($product_code); ?></div>
                        <div class="product-total">总入库数量：<?php echo number_format($product_totals[$product_code]); ?></div>
                    </div>

                    <div class="records-list">
                        <?php foreach ($product_records as $record): ?>
                            <div class="record-item">
                                <div class="record-quantity"><?php echo number_format($record['inbound_quantity']); ?></div>
                                <div class="record-location">库位：<?php echo htmlspecialchars($record['location']); ?></div>
                                <?php if (!empty($record['remark'])): ?>
                                    <div class="record-remark"><?php echo htmlspecialchars($record['remark']); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($record['operator_name'])): ?>
                                    <div class="record-operator">操作人：<?php echo htmlspecialchars($record['operator_name']); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- 库位统计汇总 -->
                    <?php if (isset($location_stats[$product_code]) && !empty($location_stats[$product_code])): ?>
                        <div class="location-summary">
                            <div class="location-summary-header">
                                <strong>📊 库位统计汇总</strong>
                                <button class="btn btn-sm btn-outline-secondary" onclick="copyLocationStats('<?php echo htmlspecialchars($product_code); ?>')">复制统计</button>
                            </div>
                            <div class="location-stats-grid">
                                <?php foreach ($location_stats[$product_code] as $location => $quantities): ?>
                                    <div class="location-stat-item">
                                        <div class="location-name">库位：<?php echo htmlspecialchars($location); ?></div>
                                        <div class="location-quantities">
                                            <?php foreach ($quantities as $qty): ?>
                                                <span class="quantity-badge"><?php echo number_format($qty); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 复制库位统计到剪贴板
        function copyLocationStats(productCode) {
            const locationStats = <?php echo json_encode($location_stats); ?>;
            
            if (!locationStats[productCode]) {
                alert('该产品编码没有库位统计');
                return;
            }
            
            let output = [];
            for (const [location, quantities] of Object.entries(locationStats[productCode])) {
                output.push(location + ': ' + quantities.join(' '));
            }
            
            const text = output.join('\n');
            
            // 复制到剪贴板
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function() {
                    alert('库位统计已复制到剪贴板！');
                }).catch(function(err) {
                    console.error('复制失败:', err);
                    fallbackCopy(text);
                });
            } else {
                fallbackCopy(text);
            }
        }
        
        function fallbackCopy(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                alert('库位统计已复制到剪贴板！');
            } catch (err) {
                alert('复制失败，请手动复制');
            }
            document.body.removeChild(textarea);
        }
    </script>
</body>
</html>

