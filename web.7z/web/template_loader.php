<?php
/**
 * 模板加载器
 * 根据设置加载不同的模板
 */

if (!function_exists('get_site_setting')) {
    require_once 'get_site_setting.php';
}

/**
 * 获取当前使用的模板
 * @return string 模板名称
 */
function get_current_template() {
    $template = get_site_setting('site_template', 'default');
    // 验证模板是否存在
    $template_dir = __DIR__ . '/templates/' . $template;
    if (!is_dir($template_dir)) {
        return 'default';
    }
    return $template;
}

/**
 * 加载模板头部
 */
function load_template_header() {
    $template = get_current_template();
    $header_file = __DIR__ . '/templates/' . $template . '/header.php';
    if (file_exists($header_file)) {
        include $header_file;
    } else {
        // 如果模板文件不存在，使用默认模板
        include __DIR__ . '/templates/default/header.php';
    }
}

/**
 * 加载模板底部
 */
function load_template_footer() {
    $template = get_current_template();
    $footer_file = __DIR__ . '/templates/' . $template . '/footer.php';
    if (file_exists($footer_file)) {
        include $footer_file;
    } else {
        // 如果模板文件不存在，使用默认模板
        include __DIR__ . '/templates/default/footer.php';
    }
}

/**
 * 获取可用模板列表
 * @return array 模板列表
 */
function get_available_templates() {
    $templates = [];
    $templates_dir = __DIR__ . '/templates';
    
    if (is_dir($templates_dir)) {
        $dirs = scandir($templates_dir);
        foreach ($dirs as $dir) {
            if ($dir != '.' && $dir != '..' && is_dir($templates_dir . '/' . $dir)) {
                $info_file = $templates_dir . '/' . $dir . '/info.php';
                if (file_exists($info_file)) {
                    $info = include $info_file;
                    $templates[$dir] = $info;
                } else {
                    // 如果没有info文件，使用默认信息
                    $templates[$dir] = [
                        'name' => ucfirst($dir),
                        'description' => $dir . ' template',
                        'version' => '1.0',
                        'author' => 'System'
                    ];
                }
            }
        }
    }
    
    return $templates;
}


