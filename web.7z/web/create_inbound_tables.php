<?php
/**
 * 创建入库功能所需的数据库表
 * 运行此文件一次即可创建所需的表结构
 */

require_once 'config.php';

try {
    $pdo->beginTransaction();
    
    // 创建入库记录表
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `inbound_records` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `inbound_quantity` int(11) NOT NULL,
            `location` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `remark` text COLLATE utf8mb4_unicode_ci,
            `user_id` int(11) NOT NULL,
            `inbound_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `product_code` (`product_code`),
            KEY `location` (`location`),
            KEY `user_id` (`user_id`),
            KEY `inbound_date` (`inbound_date`),
            CONSTRAINT `inbound_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    // 创建库存表
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `inventory` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `location` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `quantity` int(11) NOT NULL DEFAULT 0,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `product_location` (`product_code`, `location`),
            KEY `product_code` (`product_code`),
            KEY `location` (`location`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    $pdo->commit();
    echo "数据库表创建成功！<br>";
    echo "<a href='index.php'>返回主页</a>";
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    die("创建表失败: " . $e->getMessage());
}
?>

