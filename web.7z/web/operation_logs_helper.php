<?php
/**
 * 操作日志辅助函数
 * 提供统一的日志记录接口
 */

/**
 * 记录操作日志
 * 
 * @param PDO $pdo 数据库连接
 * @param int $user_id 用户ID
 * @param string $username 用户名
 * @param string $action_type 操作类型
 * @param string $module 模块名称
 * @param int|null $target_id 目标记录ID
 * @param string|null $target_type 目标类型
 * @param string|null $description 操作描述
 * @param array|null $old_data 操作前数据
 * @param array|null $new_data 操作后数据
 * @return bool 是否成功
 */
function log_operation($pdo, $user_id, $username, $action_type, $module, $target_id = null, $target_type = null, $description = null, $old_data = null, $new_data = null) {
    try {
        // 获取IP地址
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        
        // 获取用户代理
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        // 转换数据为JSON
        $old_data_json = $old_data ? json_encode($old_data, JSON_UNESCAPED_UNICODE) : null;
        $new_data_json = $new_data ? json_encode($new_data, JSON_UNESCAPED_UNICODE) : null;
        
        $stmt = $pdo->prepare("
            INSERT INTO operation_logs 
            (user_id, username, action_type, module, target_id, target_type, description, old_data, new_data, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $user_id,
            $username,
            $action_type,
            $module,
            $target_id,
            $target_type,
            $description,
            $old_data_json,
            $new_data_json,
            $ip_address,
            $user_agent
        ]);
        
        return true;
    } catch (PDOException $e) {
        // 记录日志失败不应该影响主业务，只记录错误
        error_log("操作日志记录失败: " . $e->getMessage());
        return false;
    }
}

/**
 * 获取操作类型的中文描述
 */
function get_action_type_name($action_type) {
    $types = [
        'create_plan' => '创建计划',
        'update_plan' => '修改计划',
        'delete_plan' => '删除计划',
        'restore_plan' => '恢复计划',
        'outbound' => '出库',
        'update_outbound' => '修改出库',
        'delete_outbound' => '删除出库',
        'inbound' => '入库',
        'update_inbound' => '修改入库',
        'delete_inbound' => '删除入库',
        'create_inventory' => '创建库存',
        'update_inventory' => '修改库存',
        'delete_inventory' => '删除库存',
        'restore_inventory' => '恢复库存',
        'create_user' => '创建用户',
        'update_user' => '修改用户',
        'delete_user' => '删除用户',
        'change_password' => '修改密码',
        'login' => '登录',
        'logout' => '登出',
        'backup' => '备份数据',
        'restore' => '恢复数据',
        'export' => '导出数据',
        'import' => '导入数据',
    ];
    
    return $types[$action_type] ?? $action_type;
}

/**
 * 获取模块的中文描述
 */
function get_module_name($module) {
    $modules = [
        'plan' => '生产计划',
        'outbound' => '出库管理',
        'inbound' => '入库管理',
        'inventory' => '库存管理',
        'user' => '用户管理',
        'system' => '系统管理',
        'report' => '报表',
    ];
    
    return $modules[$module] ?? $module;
}



