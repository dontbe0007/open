

CREATE TABLE `inbound_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inbound_quantity` int(11) NOT NULL,
  `location` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) NOT NULL,
  `inbound_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_code` (`product_code`),
  KEY `location` (`location`),
  KEY `user_id` (`user_id`),
  KEY `inbound_date` (`inbound_date`),
  KEY `idx_inbound_records_deleted_at` (`deleted_at`),
  CONSTRAINT `inbound_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO inbound_records VALUES ('1','1302130126','330','08-06','','4','2025-12-21 10:07:24','2025-12-21 21:20:09');
INSERT INTO inbound_records VALUES ('2','1302130126','330','08-06','','4','2025-12-21 10:07:41','2025-12-21 21:20:07');
INSERT INTO inbound_records VALUES ('4','1302130126','330','08-06','020','4','2025-12-21 20:55:00','2025-12-21 21:20:05');
INSERT INTO inbound_records VALUES ('5','1302130126','10','08-01','148','4','2025-12-21 20:55:15',NULL);
INSERT INTO inbound_records VALUES ('6','1302130126','330','08-06','','4','2025-12-21 21:13:44','2025-12-21 21:20:10');
INSERT INTO inbound_records VALUES ('7','1302130125','200','0-1','','1','2025-12-21 21:20:32','2025-12-21 21:20:37');
INSERT INTO inbound_records VALUES ('8','1302130146','672','10-10','002','4','2025-12-21 21:21:13',NULL);
INSERT INTO inbound_records VALUES ('9','1302130126','330','08-06','001','4','2025-12-21 21:27:48','2025-12-21 21:45:23');
INSERT INTO inbound_records VALUES ('10','1302130126','330','08-06','020','4','2025-12-21 21:32:27','2025-12-21 21:45:21');
INSERT INTO inbound_records VALUES ('11','1302130126','100','08-06','','4','2025-12-21 21:59:28','2025-12-21 21:59:49');
INSERT INTO inbound_records VALUES ('12','1302130146','672','08-06','001','4','2025-12-21 22:00:13',NULL);
INSERT INTO inbound_records VALUES ('13','1302130187','100','08-06','020','4','2025-12-21 22:03:12',NULL);
INSERT INTO inbound_records VALUES ('14','100','200','08-06','020','4','2025-12-21 22:07:28',NULL);


CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_location` (`product_code`,`location`),
  KEY `product_code` (`product_code`),
  KEY `location` (`location`),
  KEY `idx_inventory_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO inventory VALUES ('11','1302130126','08-06','100',NULL,'2025-12-21 21:59:28','2025-12-21 21:59:58','2025-12-21 21:59:58');
INSERT INTO inventory VALUES ('12','1302130146','08-06','672',NULL,'2025-12-21 22:00:13','2025-12-21 22:03:00','2025-12-21 22:03:00');
INSERT INTO inventory VALUES ('13','1302130187','08-06','100',NULL,'2025-12-21 22:03:12','2025-12-21 22:07:07','2025-12-21 22:07:07');
INSERT INTO inventory VALUES ('14','100','08-06','200','020','2025-12-21 22:07:28','2025-12-21 22:07:37','2025-12-21 22:07:37');


CREATE TABLE `operation_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型：create_plan, update_plan, delete_plan, outbound, inbound, update_inventory, delete_inventory, create_user, delete_user, backup, restore等',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模块：plan, outbound, inbound, inventory, user, system等',
  `target_id` int(11) DEFAULT NULL COMMENT '目标记录ID',
  `target_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标类型：plan, outbound_record, inbound_record, inventory, user等',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '操作描述',
  `old_data` text COLLATE utf8mb4_unicode_ci COMMENT '操作前数据（JSON格式）',
  `new_data` text COLLATE utf8mb4_unicode_ci COMMENT '操作后数据（JSON格式）',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COLLATE utf8mb4_unicode_ci COMMENT '用户代理',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_type` (`action_type`),
  KEY `module` (`module`),
  KEY `target_id` (`target_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `operation_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO operation_logs VALUES ('1','1','admin','logout','system',NULL,NULL,'用户登出：admin',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 11:02:21');
INSERT INTO operation_logs VALUES ('2','1','admin','login','system',NULL,NULL,'用户登录：admin（角色：admin）',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 11:02:22');
INSERT INTO operation_logs VALUES ('3','1','admin','update_user','system',NULL,NULL,'更新网站设置',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 11:22:55');
INSERT INTO operation_logs VALUES ('4','1','admin','login','system',NULL,NULL,'用户登录：admin（角色：admin）',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:36:55');
INSERT INTO operation_logs VALUES ('5','1','admin','logout','system',NULL,NULL,'用户登出：admin',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:41:54');
INSERT INTO operation_logs VALUES ('6','1','admin','login','system',NULL,NULL,'用户登录：admin（角色：admin）',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:41:55');
INSERT INTO operation_logs VALUES ('7','1','admin','update_user','system',NULL,NULL,'更新网站设置',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:42:05');
INSERT INTO operation_logs VALUES ('8','1','admin','update_user','system',NULL,NULL,'更新网站设置',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:44:46');
INSERT INTO operation_logs VALUES ('9','4','zhangdong','login','system',NULL,NULL,'用户登录：zhangdong（角色：user）',NULL,NULL,'192.168.1.78','Mozilla/5.0 (Linux; Android 16; RMX5071 Build/UKQ1.231108.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.135 Mobile Safari/537.36','2025-12-24 18:45:34');
INSERT INTO operation_logs VALUES ('10','1','admin','create_plan','plan','1','plan','创建生产计划：12月24日，产品编码：1302130126，计划数量：5000',NULL,'{\"product_code\":\"1302130126\",\"planned_quantity\":\"5000\",\"plan_name\":\"12月24日\"}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:47:09');
INSERT INTO operation_logs VALUES ('11','1','admin','logout','system',NULL,NULL,'用户登出：admin',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:50:18');
INSERT INTO operation_logs VALUES ('12','4','zhangdong','login','system',NULL,NULL,'用户登录：zhangdong（角色：user）',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:50:21');
INSERT INTO operation_logs VALUES ('13','4','zhangdong','logout','system',NULL,NULL,'用户登出：zhangdong',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:57:05');
INSERT INTO operation_logs VALUES ('14','1','admin','login','system',NULL,NULL,'用户登录：admin（角色：admin）',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-24 18:57:08');


CREATE TABLE `outbound_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `outbound_quantity` int(11) NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `photo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outbound_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `plan_id` (`plan_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `outbound_records_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `production_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `outbound_records_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `production_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `planned_quantity` int(11) NOT NULL,
  `plan_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `night_shift_quantity` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_deleted_at` (`deleted_at`),
  CONSTRAINT `production_plans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO production_plans VALUES ('1','1','12月24日','1302130126','5000','2025-12-24','2025-12-24 18:47:09',NULL,'0');


CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `setting_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'text, image, textarea',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO site_settings VALUES ('1','site_name','仓库管理系统','text','网站名称','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('2','site_keywords','仓库管理,出库管理,入库管理,库存管理','text','网站关键字','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('3','site_description','专业的仓库管理系统','text','网站描述','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('4','site_logo','','image','网站Logo（头部）','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('5','footer_logo','','image','底部Logo','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('6','footer_text','© 2025 全部功能用Cursor 开发完成','text','底部版权文字','2025-12-24 11:22:55');
INSERT INTO site_settings VALUES ('7','head_seo','','textarea','头部SEO代码（如统计代码、广告代码等）','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('8','footer_seo','','textarea','底部SEO代码','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('9','contact_phone','','text','联系电话','2025-12-24 11:21:48');
INSERT INTO site_settings VALUES ('10','contact_email','452820004@qq.com','text','联系邮箱','2025-12-24 18:44:46');
INSERT INTO site_settings VALUES ('11','contact_address','','text','联系地址','2025-12-24 11:21:48');


CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users VALUES ('1','admin','$2y$10$FwZ3kRX6RwHqA2/132T/n.JTTruiRmHMtwrdP8B05ThvqEAPxkLxW','admin','2025-12-24 18:57:08','2025-03-29 22:21:38');
INSERT INTO users VALUES ('4','zhangdong','$2y$10$/v6wsbIhLcmQaDfzq/mFNuZ/4FfCovtwolKg8EV7JxG8lS4fUx3fC','user','2025-12-24 18:50:21','2025-03-29 22:23:10');
