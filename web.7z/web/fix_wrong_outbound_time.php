<?php
/**
 * 修复出库时间不正确的记录
 * 检查并修复时间异常的记录
 */
require_once 'config.php';

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== ROLE_ADMIN) {
    die('需要管理员权限');
}

$fixed_count = 0;
$checked_count = 0;
$errors = [];

// 获取参数
$check_date = $_GET['date'] ?? date('Y-m-d');
$auto_fix = isset($_GET['fix']) && $_GET['fix'] == '1';

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>修复出库时间</title></head><body>";
echo "<h2>出库时间检查和修复工具</h2>";
echo "<p>检查日期：{$check_date}</p>";

try {
    // 检查该日期的所有出库记录
    $stmt = $pdo->prepare("
        SELECT 
            o.id,
            o.outbound_date,
            o.created_at,
            o.outbound_quantity,
            o.remark,
            p.product_code,
            u.username,
            TIMESTAMPDIFF(SECOND, o.created_at, o.outbound_date) as time_diff_seconds
        FROM outbound_records o
        INNER JOIN production_plans p ON o.plan_id = p.id
        LEFT JOIN users u ON o.user_id = u.id
        WHERE DATE(o.outbound_date) = ?
        ORDER BY o.outbound_date ASC
    ");
    $stmt->execute([$check_date]);
    $records = $stmt->fetchAll();
    
    $checked_count = count($records);
    echo "<p>共检查 {$checked_count} 条记录</p>";
    
    // 找出时间异常的记录
    $problem_records = [];
    foreach ($records as $record) {
        $time_diff = (int)$record['time_diff_seconds'];
        // 如果outbound_date比created_at早超过5分钟，或者晚超过1分钟，可能是问题记录
        if ($time_diff < -300 || $time_diff > 60) {
            $problem_records[] = $record;
        }
    }
    
    if (empty($problem_records)) {
        echo "<p style='color: green;'>✓ 未发现时间异常记录</p>";
    } else {
        echo "<p style='color: red;'>⚠️ 发现 " . count($problem_records) . " 条时间异常记录</p>";
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; margin: 20px 0;'>";
        echo "<tr><th>ID</th><th>outbound_date</th><th>created_at</th><th>时间差</th><th>数量</th><th>备注</th><th>产品编码</th><th>操作人</th>";
        if ($auto_fix) {
            echo "<th>操作</th>";
        }
        echo "</tr>";
        
        foreach ($problem_records as $record) {
            $time_diff = (int)$record['time_diff_seconds'];
            $time_diff_str = $time_diff > 0 ? "+{$time_diff}秒" : "{$time_diff}秒";
            
            echo "<tr>";
            echo "<td>" . htmlspecialchars($record['id']) . "</td>";
            echo "<td>" . htmlspecialchars($record['outbound_date']) . "</td>";
            echo "<td>" . htmlspecialchars($record['created_at']) . "</td>";
            echo "<td style='color: " . ($time_diff < -300 ? 'red' : 'orange') . ";'>" . $time_diff_str . "</td>";
            echo "<td>" . htmlspecialchars($record['outbound_quantity']) . "</td>";
            echo "<td>" . htmlspecialchars($record['remark'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($record['product_code'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($record['username'] ?? '') . "</td>";
            
            if ($auto_fix) {
                // 如果outbound_date比created_at早很多，使用created_at作为出库时间
                if ($time_diff < -300) {
                    try {
                        $fix_stmt = $pdo->prepare("UPDATE outbound_records SET outbound_date = created_at WHERE id = ?");
                        $fix_stmt->execute([$record['id']]);
                        echo "<td style='color: green;'>已修复（使用created_at）</td>";
                        $fixed_count++;
                    } catch (Exception $e) {
                        echo "<td style='color: red;'>修复失败：" . htmlspecialchars($e->getMessage()) . "</td>";
                        $errors[] = "ID {$record['id']}: " . $e->getMessage();
                    }
                } else {
                    echo "<td>-</td>";
                }
            }
            
            echo "</tr>";
        }
        echo "</table>";
    }
    
    if ($auto_fix && $fixed_count > 0) {
        echo "<p style='color: green;'>✓ 已修复 {$fixed_count} 条记录</p>";
    }
    
    if (!empty($errors)) {
        echo "<h3>错误信息：</h3><ul>";
        foreach ($errors as $error) {
            echo "<li>" . htmlspecialchars($error) . "</li>";
        }
        echo "</ul>";
    }
    
    // 操作按钮
    if (!$auto_fix && !empty($problem_records)) {
        echo "<p><a href='?date={$check_date}&fix=1' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>自动修复异常记录</a></p>";
    }
    
    echo "<p><a href='?date=" . date('Y-m-d', strtotime($check_date . ' -1 day')) . "'>前一天</a> | ";
    echo "<a href='?date=" . date('Y-m-d') . "'>今天</a> | ";
    echo "<a href='?date=" . date('Y-m-d', strtotime($check_date . ' +1 day')) . "'>后一天</a></p>";
    
    echo "<form method='GET' style='margin: 20px 0;'>";
    echo "<input type='date' name='date' value='{$check_date}'> ";
    echo "<button type='submit'>查询</button>";
    echo "</form>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>错误：" . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</body></html>";
?>

