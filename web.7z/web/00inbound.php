<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

$error = '';
$success = '';

// 处理添加入库记录
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_inbound'])) {
    $product_code = trim($_POST['product_code']);
    $inbound_quantity = (int)$_POST['inbound_quantity'];
    $location = trim($_POST['location']);
    $remark = trim($_POST['remark'] ?? '');
    
    if (empty($product_code) || $inbound_quantity <= 0 || empty($location)) {
        $error = '产品编码、入库数量和库位都必须填写，且入库数量必须大于0';
    } else {
        try {
            $pdo->beginTransaction();
            
            // 添加入库记录
            $stmt = $pdo->prepare("
                INSERT INTO inbound_records (product_code, inbound_quantity, location, remark, user_id) 
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$product_code, $inbound_quantity, $location, $remark, $user_id]);
            
            // 更新或插入库存
            $stmt = $pdo->prepare("
                INSERT INTO inventory (product_code, location, quantity) 
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE quantity = quantity + ?
            ");
            $stmt->execute([$product_code, $location, $inbound_quantity, $inbound_quantity]);
            
            $pdo->commit();
            $success = '入库成功！';
            
            // 清空表单（通过重定向）
            header('Location: inbound.php?success=1');
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = '入库失败：' . $e->getMessage();
        }
    }
}

// 处理修改入库记录
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_inbound'])) {
    $inbound_id = (int)$_POST['inbound_id'];
    $old_quantity = (int)$_POST['old_quantity'];
    $old_location = trim($_POST['old_location']);
    $old_product_code = trim($_POST['old_product_code']);
    
    $new_quantity = (int)$_POST['inbound_quantity'];
    $new_location = trim($_POST['location']);
    $remark = trim($_POST['remark'] ?? '');
    
    if ($new_quantity <= 0 || empty($new_location)) {
        $error = '入库数量和库位必须填写，且入库数量必须大于0';
    } else {
        try {
            $pdo->beginTransaction();
            
            // 检查权限
            if (!$is_admin && !$is_storage) {
                $stmt = $pdo->prepare("SELECT user_id FROM inbound_records WHERE id = ?");
                $stmt->execute([$inbound_id]);
                $record = $stmt->fetch();
                if (!$record || $record['user_id'] != $user_id) {
                    throw new Exception('无权限修改此记录');
                }
            }
            
            // 更新入库记录
            $stmt = $pdo->prepare("
                UPDATE inbound_records 
                SET inbound_quantity = ?, location = ?, remark = ? 
                WHERE id = ?
            ");
            $stmt->execute([$new_quantity, $new_location, $remark, $inbound_id]);
            
            // 更新库存：先减去旧的数量和位置
            if ($old_location == $new_location) {
                // 同一库位，只需调整数量差
                $quantity_diff = $new_quantity - $old_quantity;
                $stmt = $pdo->prepare("
                    UPDATE inventory 
                    SET quantity = quantity + ? 
                    WHERE product_code = ? AND location = ?
                ");
                $stmt->execute([$quantity_diff, $old_product_code, $old_location]);
            } else {
                // 不同库位，需要从旧库位减去，新库位加上
                // 从旧库位减去旧数量
                $stmt = $pdo->prepare("
                    UPDATE inventory 
                    SET quantity = quantity - ? 
                    WHERE product_code = ? AND location = ?
                ");
                $stmt->execute([$old_quantity, $old_product_code, $old_location]);
                
                // 如果旧库位库存为0或负数，删除该记录
                $stmt = $pdo->prepare("
                    DELETE FROM inventory 
                    WHERE product_code = ? AND location = ? AND quantity <= 0
                ");
                $stmt->execute([$old_product_code, $old_location]);
                
                // 在新库位加上新数量
                $stmt = $pdo->prepare("
                    INSERT INTO inventory (product_code, location, quantity) 
                    VALUES (?, ?, ?)
                    ON DUPLICATE KEY UPDATE quantity = quantity + ?
                ");
                $stmt->execute([$old_product_code, $new_location, $new_quantity, $new_quantity]);
            }
            
            $pdo->commit();
            $success = '修改成功！';
            header('Location: inbound.php?success=1');
            exit;
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = '修改失败：' . $e->getMessage();
        }
    }
}

// 获取成功消息
if (isset($_GET['success'])) {
    $success = '操作成功！';
}

// 获取日期查询参数
$query_date = isset($_GET['query_date']) ? $_GET['query_date'] : '';

// 获取入库记录
try {
    $params = [];
    $where_conditions = [];
    
    // 如果选择了日期，按日期筛选
    if (!empty($query_date)) {
        $where_conditions[] = "DATE(i.inbound_date) = ?";
        $params[] = $query_date;
    }
    
    // 根据用户角色构建查询
    if ($is_admin || $is_storage) {
        $base_query = "
            SELECT i.*, u.username as operator_name
            FROM inbound_records i
            LEFT JOIN users u ON i.user_id = u.id
        ";
        if (!empty($where_conditions)) {
            $base_query .= " WHERE " . implode(' AND ', $where_conditions);
        }
        $base_query .= " ORDER BY i.inbound_date DESC";
        if (empty($query_date)) {
            $base_query .= " LIMIT 50";
        }
        $stmt = $pdo->prepare($base_query);
        $stmt->execute($params);
    } else {
        $where_conditions[] = "i.user_id = ?";
        $params[] = $user_id;
        $base_query = "
            SELECT i.*, u.username as operator_name
            FROM inbound_records i
            LEFT JOIN users u ON i.user_id = u.id
            WHERE " . implode(' AND ', $where_conditions) . "
            ORDER BY i.inbound_date DESC
        ";
        if (empty($query_date)) {
            $base_query .= " LIMIT 50";
        }
        $stmt = $pdo->prepare($base_query);
        $stmt->execute($params);
    }
    $recent_records = $stmt->fetchAll();
    
    // 获取今日入库统计
    $today_stats_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as today_count,
            SUM(inbound_quantity) as today_total,
            COUNT(DISTINCT product_code) as today_products
        FROM inbound_records
        WHERE DATE(inbound_date) = CURDATE()
    ");
    $today_stats_stmt->execute();
    $today_stats = $today_stats_stmt->fetch();
    
    // 获取本月入库统计
    $month_stats_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as month_count,
            SUM(inbound_quantity) as month_total,
            COUNT(DISTINCT product_code) as month_products
        FROM inbound_records
        WHERE YEAR(inbound_date) = YEAR(CURDATE()) 
        AND MONTH(inbound_date) = MONTH(CURDATE())
    ");
    $month_stats_stmt->execute();
    $month_stats = $month_stats_stmt->fetch();
    
} catch (PDOException $e) {
    $error = '获取记录失败：' . $e->getMessage();
    $recent_records = [];
    $today_stats = ['today_count' => 0, 'today_total' => 0, 'today_products' => 0];
    $month_stats = ['month_count' => 0, 'month_total' => 0, 'month_products' => 0];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>产品入库 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .form-control, .btn {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
        .table {
            background-color: white;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .btn-edit {
            padding: 2px 8px;
            font-size: 12px;
        }
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .stats-card.blue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .stats-card.green {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        }
        .stats-card.orange {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        .stats-card.purple {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        .stats-icon {
            font-size: 48px;
            opacity: 0.8;
            margin-bottom: 10px;
        }
        .stats-value {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .stats-label {
            font-size: 14px;
            opacity: 0.9;
        }
        .inbound-form-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 25px;
            margin-bottom: 20px;
        }
        .form-section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #007bff;
        }
        .quick-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .quick-action-btn {
            padding: 12px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .quick-action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .table-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        .table-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 20px;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        @media (max-width: 768px) {
            .stats-card {
                padding: 15px;
            }
            .stats-value {
                font-size: 24px;
            }
            .quick-actions {
                flex-direction: column;
            }
            .quick-action-btn {
                width: 100%;
            }
        }
        .table td, .table th {
            white-space: nowrap;
            min-width: 60px;
        }
        .table td:first-child,
        .table th:first-child {
            min-width: 100px;
            max-width: 150px;
            white-space: normal;
            word-break: break-word;
            overflow-wrap: break-word;
        }
        .table td:nth-child(2),
        .table th:nth-child(2) {
            min-width: 60px;
            max-width: 80px;
        }
        .table td:nth-child(3),
        .table th:nth-child(3) {
            min-width: 60px;
            max-width: 80px;
        }
        .table td:nth-child(4),
        .table th:nth-child(4) {
            min-width: 80px;
            max-width: 120px;
            white-space: normal;
            word-break: break-word;
            overflow-wrap: break-word;
        }
        .table td:nth-child(5),
        .table th:nth-child(5) {
            min-width: 60px;
            max-width: 80px;
            white-space: normal;
            word-break: break-word;
        }
        .table td:nth-child(6),
        .table th:nth-child(6) {
            min-width: 120px;
            max-width: 140px;
        }
        .table td:last-child,
        .table th:last-child {
            min-width: 60px;
            max-width: 70px;
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .table {
                font-size: 12px;
            }
            .table td, .table th {
                padding: 8px 4px;
                font-size: 12px;
            }
            .table td:first-child,
            .table th:first-child {
                min-width: 80px;
                max-width: 100px;
            }
            .table td:nth-child(2),
            .table th:nth-child(2),
            .table td:nth-child(3),
            .table th:nth-child(3) {
                min-width: 50px;
                max-width: 70px;
            }
            .table td:nth-child(4),
            .table th:nth-child(4) {
                min-width: 60px;
                max-width: 100px;
            }
            .table td:nth-child(5),
            .table th:nth-child(5) {
                min-width: 50px;
                max-width: 70px;
            }
            .table td:nth-child(6),
            .table th:nth-child(6) {
                min-width: 100px;
                max-width: 120px;
                font-size: 11px;
            }
            .table td:last-child,
            .table th:last-child {
                min-width: 50px;
                max-width: 60px;
            }
            .btn-edit {
                padding: 2px 6px;
                font-size: 11px;
            }
        }
        @media (max-width: 480px) {
            .table {
                font-size: 11px;
            }
            .table td, .table th {
                padding: 6px 3px;
                font-size: 11px;
            }
            .table td:first-child,
            .table th:first-child {
                min-width: 70px;
                max-width: 90px;
            }
            .table td:nth-child(2),
            .table th:nth-child(2),
            .table td:nth-child(3),
            .table th:nth-child(3) {
                min-width: 45px;
                max-width: 60px;
            }
            .table td:nth-child(4),
            .table th:nth-child(4) {
                min-width: 50px;
                max-width: 80px;
            }
            .table td:nth-child(5),
            .table th:nth-child(5) {
                min-width: 45px;
                max-width: 60px;
            }
            .table td:nth-child(6),
            .table th:nth-child(6) {
                min-width: 90px;
                max-width: 110px;
                font-size: 10px;
            }
            .table td:last-child,
            .table th:last-child {
                min-width: 45px;
                max-width: 55px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="h3 mb-4">产品入库</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- 入库表单 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">添加入库记录</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">产品编码 <span class="text-danger">*</span></label>
                            <input type="text" name="product_code" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">入库数量 <span class="text-danger">*</span></label>
                            <input type="number" name="inbound_quantity" class="form-control" min="1" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">库位 <span class="text-danger">*</span></label>
                            <input type="text" name="location" class="form-control" placeholder="例如：8-11" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">备注</label>
                            <input type="text" name="remark" class="form-control">
                        </div>
                    </div>
                    <button type="submit" name="add_inbound" class="btn btn-primary">提交入库</button>
                </form>
            </div>
        </div>

        <!-- 最近入库记录 -->
        <div class="table-card">
            <div class="table-header">
                <span>📋 入库记录</span>
                <form method="GET" class="d-flex gap-2" style="margin: 0;">
                    <input type="date" name="query_date" class="form-control form-control-sm" 
                           value="<?php echo htmlspecialchars($query_date); ?>" 
                           style="max-width: 150px; background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white;">
                    <button type="submit" class="btn btn-sm btn-light">查询</button>
                    <?php if (!empty($query_date)): ?>
                        <a href="inbound.php" class="btn btn-sm btn-light">清除</a>
                    <?php endif; ?>
                </form>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if (empty($recent_records)): ?>
                    <p class="text-muted">暂无入库记录</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>编码</th>
                                    <th>数量</th>
                                    <th>库位</th>
                                    <th>备注</th>
                                    <th>操作人</th>
                                    <th>时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_records as $record): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($record['product_code']); ?></td>
                                        <td><?php echo number_format($record['inbound_quantity']); ?></td>
                                        <td><?php echo htmlspecialchars($record['location']); ?></td>
                                        <td><?php echo htmlspecialchars($record['remark'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($record['operator_name'] ?? ''); ?></td>
                                        <td><?php echo date('m-d H:i', strtotime($record['inbound_date'])); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-primary btn-edit" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editModal"
                                                    data-id="<?php echo $record['id']; ?>"
                                                    data-product-code="<?php echo htmlspecialchars($record['product_code']); ?>"
                                                    data-quantity="<?php echo $record['inbound_quantity']; ?>"
                                                    data-location="<?php echo htmlspecialchars($record['location']); ?>"
                                                    data-remark="<?php echo htmlspecialchars($record['remark'] ?? ''); ?>">
                                                修改
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 修改模态框 -->
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">修改入库记录</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="inbound_id" id="edit_inbound_id">
                        <input type="hidden" name="old_quantity" id="edit_old_quantity">
                        <input type="hidden" name="old_location" id="edit_old_location">
                        <input type="hidden" name="old_product_code" id="edit_old_product_code">
                        
                        <div class="mb-3">
                            <label class="form-label">产品编码</label>
                            <input type="text" id="edit_product_code" class="form-control" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">入库数量 <span class="text-danger">*</span></label>
                            <input type="number" name="inbound_quantity" id="edit_quantity" class="form-control" min="1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">库位 <span class="text-danger">*</span></label>
                            <input type="text" name="location" id="edit_location" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">备注</label>
                            <input type="text" name="remark" id="edit_remark" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" name="edit_inbound" class="btn btn-primary">保存修改</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 编辑模态框数据填充
        const editModal = document.getElementById('editModal');
        if (editModal) {
            editModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                document.getElementById('edit_inbound_id').value = button.getAttribute('data-id');
                document.getElementById('edit_old_quantity').value = button.getAttribute('data-quantity');
                document.getElementById('edit_old_location').value = button.getAttribute('data-location');
                document.getElementById('edit_old_product_code').value = button.getAttribute('data-product-code');
                document.getElementById('edit_product_code').value = button.getAttribute('data-product-code');
                document.getElementById('edit_quantity').value = button.getAttribute('data-quantity');
                document.getElementById('edit_location').value = button.getAttribute('data-location');
                document.getElementById('edit_remark').value = button.getAttribute('data-remark');
            });
        }
    </script>
</body>
</html>

