<?php
// 仪表盘主页内容
?>

<div class="content-header">
    <h2><i class="bi bi-speedometer2"></i> 系统概览</h2>
</div>

<div class="content-body">
    <!-- 统计卡片 -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="stat-card primary">
                <div class="stat-number"><?php echo number_format($user_count); ?></div>
                <div class="stat-label">总用户数</div>
                <small class="text-muted">今日活跃: <?php echo $active_users; ?></small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card success">
                <div class="stat-number"><?php echo number_format($plan_count); ?></div>
                <div class="stat-label">生产计划</div>
                <small class="text-muted">今日新增: <?php echo $today_plans; ?></small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card info">
                <div class="stat-number"><?php echo number_format($today_outbound['total']); ?></div>
                <div class="stat-label">今日出库</div>
                <small class="text-muted">记录数: <?php echo $today_outbound['count']; ?></small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card warning">
                <div class="stat-number"><?php echo number_format($today_inbound['total']); ?></div>
                <div class="stat-label">今日入库</div>
                <small class="text-muted">记录数: <?php echo $today_inbound['count']; ?></small>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="stat-card secondary">
                <div class="stat-number"><?php echo number_format($inventory_count['count']); ?></div>
                <div class="stat-label">库存记录</div>
                <small class="text-muted">总量: <?php echo number_format($inventory_count['total']); ?></small>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card danger">
                <div class="stat-number"><?php echo number_format($today_logs); ?></div>
                <div class="stat-label">今日操作日志</div>
                <small class="text-muted">系统活动</small>
            </div>
        </div>
    </div>

    <!-- 最近操作日志 -->
    <div class="row">
        <div class="col-md-8">
            <h5 class="mb-3"><i class="bi bi-clock-history"></i> 最近操作日志</h5>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>时间</th>
                            <th>用户</th>
                            <th>操作</th>
                            <th>描述</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_logs)): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">暂无操作日志</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recent_logs as $log): ?>
                                <tr>
                                    <td><?php echo date('H:i:s', strtotime($log['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($log['username']); ?></td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo htmlspecialchars($log['action_type']); ?></span>
                                    </td>
                                    <td class="text-truncate" style="max-width: 200px;">
                                        <?php echo htmlspecialchars($log['description'] ?? '无'); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <a href="operation_logs.php" class="btn btn-sm btn-outline-primary">查看全部日志</a>
            </div>
        </div>
        
        <div class="col-md-4">
            <h5 class="mb-3"><i class="bi bi-person-check"></i> 最近登录用户</h5>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>用户名</th>
                            <th>最后登录</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_users)): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted">暂无登录记录</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recent_users as $user): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo $user['last_login'] ? date('m-d H:i', strtotime($user['last_login'])) : '从未登录'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



