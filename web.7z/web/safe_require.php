<?php
/**
 * 安全加载辅助文件
 * 如果文件不存在，提供默认函数，避免报错
 */

// 加载操作日志辅助函数（如果文件存在）
if (file_exists('operation_logs_helper.php')) {
    require_once 'operation_logs_helper.php';
} else {
    // 如果文件不存在，定义一个空的日志函数，避免报错
    if (!function_exists('log_operation')) {
        function log_operation($pdo, $user_id, $username, $action_type, $module, $target_id = null, $target_type = null, $description = null, $old_data = null, $new_data = null) {
            // 空函数，不执行任何操作
            return false;
        }
    }
}

// 加载网站设置辅助函数（如果文件存在）
if (file_exists('get_site_setting.php')) {
    require_once 'get_site_setting.php';
} else {
    // 如果文件不存在，定义一个默认函数
    if (!function_exists('get_site_setting')) {
        function get_site_setting($key, $default = '') {
            // 尝试从数据库获取（如果数据库连接可用）
            global $pdo;
            if (isset($pdo)) {
                try {
                    $stmt = $pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1");
                    $stmt->execute([$key]);
                    $result = $stmt->fetch();
                    if ($result) {
                        return $result['setting_value'];
                    }
                } catch (Exception $e) {
                    // 忽略错误
                }
            }
            return $default;
        }
    }
}
?>

