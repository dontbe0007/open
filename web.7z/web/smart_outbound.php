<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 获取计划ID
$plan_id = isset($_GET['plan_id']) ? (int)$_GET['plan_id'] : 0;
if (!$plan_id) {
    header('Location: index.php');
    exit;
}

// 获取计划信息
try {
    if ($is_admin) {
        $stmt = $pdo->prepare("
            SELECT p.*, 
                   COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id
            WHERE p.id = ?
            GROUP BY p.id
        ");
        $stmt->execute([$plan_id]);
    } else {
        $stmt = $pdo->prepare("
            SELECT p.*, 
                   COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id
            WHERE p.id = ? AND p.user_id = ?
            GROUP BY p.id
        ");
        $stmt->execute([$plan_id, $user_id]);
    }
    $plan = $stmt->fetch();
    
    if (!$plan) {
        header('Location: index.php');
        exit;
    }
} catch (Exception $e) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

// 处理出库请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['outbound_quantity'])) {
    $outbound_quantity = (int)$_POST['outbound_quantity'];
    $remark = trim($_POST['remark']);
    
    if (empty($remark)) {
        $remark = '识别码';
    }
    
    try {
        // 开始事务
        $pdo->beginTransaction();
        
        // 检查出库数量
        if ($outbound_quantity <= 0) {
            throw new Exception('出库数量必须大于0');
        }
        
        // 检查是否超过计划数量
        if ($outbound_quantity > ($plan['planned_quantity'] - $plan['total_outbound'])) {
            throw new Exception('出库数量不能超过计划剩余数量');
        }

        // 处理照片上传
        $photo_path = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/outbound_photos/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (!in_array($file_extension, $allowed_extensions)) {
                throw new Exception('只允许上传 JPG, JPEG, PNG 或 GIF 格式的图片');
            }
            
            $new_filename = uniqid() . '.' . $file_extension;
            $target_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)) {
                $photo_path = $target_path;
            } else {
                throw new Exception('照片上传失败');
            }
        }
        
        // 添加出库记录
        $check_photo_field = $pdo->query("SHOW COLUMNS FROM outbound_records LIKE 'photo_path'");
        if ($check_photo_field->rowCount() == 0) {
            $pdo->exec("ALTER TABLE outbound_records ADD COLUMN photo_path VARCHAR(255) DEFAULT NULL AFTER remark");
        }
        
        // 使用 PHP 时间确保时区正确，并验证时间合理性
        $current_time = date('Y-m-d H:i:s');
        // 验证时间：不能是未来时间，也不能是太早的时间
        $time_timestamp = strtotime($current_time);
        $now_timestamp = time();
        if ($time_timestamp > $now_timestamp + 60) {
            // 如果时间比当前时间晚超过1分钟，使用当前时间
            $current_time = date('Y-m-d H:i:s');
        }
        
        $stmt = $pdo->prepare(
            "INSERT INTO outbound_records (plan_id, user_id, outbound_quantity, remark, photo_path, outbound_date)
            VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([$plan_id, $user_id, $outbound_quantity, $remark, $photo_path, $current_time]);
        
        // 提交事务
        $pdo->commit();
        
        $success = '出库成功！';
        
        // 重新获取计划信息
        if ($is_admin) {
            $stmt = $pdo->prepare("
                SELECT p.*, 
                       COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
                FROM production_plans p
                LEFT JOIN outbound_records o ON p.id = o.plan_id
                WHERE p.id = ?
                GROUP BY p.id
            ");
            $stmt->execute([$plan_id]);
        } else {
            $stmt = $pdo->prepare("
                SELECT p.*, 
                       COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
                FROM production_plans p
                LEFT JOIN outbound_records o ON p.id = o.plan_id
                WHERE p.id = ? AND p.user_id = ?
                GROUP BY p.id
            ");
            $stmt->execute([$plan_id, $user_id]);
        }
        $plan = $stmt->fetch();
        
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = '出库失败：' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智能出库 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card { 
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .camera-container {
            position: relative;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            background: #000;
            border-radius: 10px;
            overflow: hidden;
        }
        #video {
            width: 100%;
            height: auto;
            display: block;
        }
        #canvas {
            display: none;
        }
        .capture-btn {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #007bff;
            border: 3px solid white;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }
        .ocr-result {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin: 15px 0;
            font-family: monospace;
            font-size: 12px;
            max-height: 200px;
            overflow-y: auto;
        }
        .status-info {
            text-align: center;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            font-weight: 500;
            border: 1px solid transparent;
            transition: all 0.3s ease;
        }
        .status-processing {
            background-color: #fff3cd;
            color: #856404;
            border-color: #ffeaa7;
            animation: pulse 1.5s infinite;
        }
        .status-success {
            background-color: #d1edff;
            color: #0c5460;
            border-color: #74b9ff;
        }
        .status-error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #fd79a8;
        }
        .status-warning {
            background-color: #ffeaa7;
            color: #2d3436;
            border-color: #fdcb6e;
        }
        .match-result {
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            font-weight: bold;
            border: 2px solid transparent;
            white-space: pre-line;
            transition: all 0.3s ease;
        }
        .match-success {
            background-color: #d4edda;
            color: #155724;
            border-color: #00b894;
        }
        .match-error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #e17055;
        }
        .capture-btn {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #007bff;
            border: 3px solid white;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
        .capture-btn:hover {
            background: #0056b3;
            transform: translateX(-50%) scale(1.1);
        }
        .capture-btn:active {
            transform: translateX(-50%) scale(0.95);
        }
        .photo-preview {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 10;
            backdrop-filter: blur(5px);
        }
        
        .photo-preview img {
            max-width: 90%;
            max-height: 65%;
            border-radius: 8px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.5);
            transition: transform 0.3s ease;
            cursor: pointer;
        }
        
        .photo-preview img:hover {
            transform: scale(1.02);
        }
        
        .preview-info {
            position: absolute;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            color: white;
            text-align: center;
            font-size: 14px;
            background: rgba(0, 0, 0, 0.7);
            padding: 8px 16px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }
        
        .preview-controls {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .preview-controls .btn {
            min-width: 110px;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
        
        .preview-controls .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.4);
        }
        
        .image-quality-indicator {
            position: absolute;
            top: 60px;
            right: 15px;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 12px;
            backdrop-filter: blur(10px);
        }
        
        .quality-excellent { border-left: 4px solid #00b894; }
        .quality-good { border-left: 4px solid #fdcb6e; }
        .quality-poor { border-left: 4px solid #e17055; }
        
        .capture-success {
            animation: captureFlash 0.3s ease-out;
        }
        
        @keyframes captureFlash {
            0% { background-color: rgba(255,255,255,0.8); }
            100% { background-color: transparent; }
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }
        .btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .btn-group .btn {
            flex: 1;
            min-width: 120px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">📷 智能出库</h1>
            <a href="index.php" class="btn btn-secondary">返回主页</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- 计划信息 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">📋 计划信息</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>计划名称：</strong><?php echo htmlspecialchars($plan['plan_name']); ?></p>
                        <p><strong>产品编码：</strong><span id="currentProductCode" class="text-primary fw-bold"><?php echo htmlspecialchars($plan['product_code']); ?></span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>计划数量：</strong><?php echo $plan['planned_quantity']; ?></p>
                        <p><strong>剩余数量：</strong><span class="text-success fw-bold"><?php echo $plan['planned_quantity'] - $plan['total_outbound']; ?></span></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- 智能识别区域 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">📷 智能识别</h5>
            </div>
            <div class="card-body text-center">
                <div class="camera-container">
                    <video id="video" autoplay playsinline muted></video>
                    <canvas id="canvas" style="display: none;"></canvas>
                    <div id="photoPreview" class="photo-preview" style="display: none;">
                        <div class="preview-info">
                            <div>📷 拍照预览</div>
                            <small id="previewTips">点击图片可查看原始大小</small>
                        </div>
                        <div id="imageQualityIndicator" class="image-quality-indicator" style="display: none;">
                            <span id="qualityText">图片质量检测中...</span>
                        </div>
                        <img id="previewImage" src="" alt="拍照预览" title="点击查看原始大小">
                        <div class="preview-controls">
                            <button id="retakeBtn" class="btn btn-warning">🔄 重新拍照</button>
                            <button id="confirmPhotoBtn" class="btn btn-success">✅ 确认识别</button>
                            <button id="zoomBtn" class="btn btn-info" style="display: none;">🔍 查看原图</button>
                        </div>
                    </div>
                    <button id="captureBtn" class="capture-btn">📷</button>
                </div>
                
                <div class="btn-group mt-3">
                    <button id="startCamera" class="btn btn-primary">📷 启动相机</button>
                    <input type="file" id="fileInput" accept="image/*" style="display: none;">
                    <button id="uploadBtn" class="btn btn-info">📁 选择图片</button>
                </div>
                
                <div class="text-center mt-2">
                    <small class="text-muted">
                        💡 提示：空格键拍照，ESC键关闭相机/取消预览，Enter键确认照片
                    </small>
                </div>
                
                <!-- OCR配置面板 -->
                <div class="mt-3">
                    <button class="btn btn-outline-secondary btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#ocrConfig">
                        ⚙️ OCR设置
                    </button>
                    <div class="collapse mt-2" id="ocrConfig">
                        <div class="card card-body">
                            <h6>识别模式</h6>
                            <div class="btn-group-sm" role="group">
                                <input type="radio" class="btn-check" name="ocrPreset" id="highAccuracy" value="highAccuracy" checked>
                                <label class="btn btn-outline-primary" for="highAccuracy">高精度</label>
                                
                                <input type="radio" class="btn-check" name="ocrPreset" id="fastMode" value="fastMode">
                                <label class="btn btn-outline-primary" for="fastMode">快速</label>
                                
                                <input type="radio" class="btn-check" name="ocrPreset" id="numberOptimized" value="numberOptimized">
                                <label class="btn btn-outline-primary" for="numberOptimized">数字优化</label>
                            </div>
                            <small class="text-muted mt-2">
                                高精度：适合清晰图片 | 快速：适合模糊图片 | 数字优化：专门识别产品编码
                            </small>
                            
                            <hr class="my-3">
                            
                            <h6>图像预处理</h6>
                            <div class="row g-2">
                                <div class="col-6">
                                    <label class="form-label form-label-sm">亮度</label>
                                    <input type="range" class="form-range" id="brightnessSlider" min="0.5" max="2" step="0.1" value="1.2">
                                    <small class="text-muted">当前: <span id="brightnessValue">1.2</span></small>
                                </div>
                                <div class="col-6">
                                    <label class="form-label form-label-sm">对比度</label>
                                    <input type="range" class="form-range" id="contrastSlider" min="0.5" max="2.5" step="0.1" value="1.3">
                                    <small class="text-muted">当前: <span id="contrastValue">1.3</span></small>
                                </div>
                                <div class="col-6">
                                    <label class="form-label form-label-sm">锐化</label>
                                    <input type="range" class="form-range" id="sharpnessSlider" min="0.5" max="2" step="0.1" value="1.1">
                                    <small class="text-muted">当前: <span id="sharpnessValue">1.1</span></small>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-switch mt-4">
                                        <input class="form-check-input" type="checkbox" id="denoiseSwitch" checked>
                                        <label class="form-check-label" for="denoiseSwitch">智能降噪</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row g-2 mt-2">
                                <div class="col-6">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="autoEnhanceSwitch" checked>
                                        <label class="form-check-label" for="autoEnhanceSwitch">自动增强</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="adaptiveContrastSwitch" checked>
                                        <label class="form-check-label" for="adaptiveContrastSwitch">自适应对比度</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="edgeEnhancementSwitch">
                                        <label class="form-check-label" for="edgeEnhancementSwitch">边缘增强</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="autoRotateSwitch" checked>
                                        <label class="form-check-label" for="autoRotateSwitch">自动旋转</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-info btn-sm" id="resetProcessing">重置默认</button>
                                <button type="button" class="btn btn-outline-success btn-sm" id="previewProcessing">预览效果</button>
                            </div>
                            
                            <hr class="my-3">
                            
                            <h6>验证统计</h6>
                            <div id="validationStats" class="small text-muted">
                                <div>总验证次数: <span id="totalValidations">0</span></div>
                                <div>成功率: <span id="successRate">0</span>%</div>
                                <div>平均置信度: <span id="averageConfidence">0</span>%</div>
                            </div>
                            
                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-secondary btn-sm" id="clearValidationHistory">清除历史</button>
                                <button type="button" class="btn btn-outline-info btn-sm" id="showValidationDetails">查看详情</button>
                            </div>
                            
                            <hr class="my-3">
                            
                            <h6>OCR性能统计</h6>
                            <div id="ocrPerformanceStats" class="small text-muted">
                                <div>总识别次数: <span id="totalRecognitions">0</span></div>
                                <div>识别成功率: <span id="ocrSuccessRate">0</span>%</div>
                                <div>平均置信度: <span id="ocrAverageConfidence">0</span>%</div>
                                <div>平均处理时间: <span id="averageProcessingTime">0</span>ms</div>
                                <div class="mt-1">
                                    <small>最佳预设: <span id="bestPreset">-</span></small>
                                </div>
                            </div>
                            
                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-secondary btn-sm" id="resetOcrStats">重置统计</button>
                                <button type="button" class="btn btn-outline-info btn-sm" id="showOcrDetails">性能详情</button>
                            </div>
                            
                            <hr class="my-3">
                            
                            <h6>表单控制</h6>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="enableQuantityFill" checked>
                                <label class="form-check-label" for="enableQuantityFill">自动填充数量</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="enableRemarkFill" checked>
                                <label class="form-check-label" for="enableRemarkFill">自动填充备注</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="showFillAnimation" checked>
                                <label class="form-check-label" for="showFillAnimation">填充动画</label>
                            </div>
                            
                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-warning btn-sm" id="resetForm">重置表单</button>
                                <button type="button" class="btn btn-outline-info btn-sm" id="showFillHistory">填充历史</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="statusInfo" class="status-info" style="display: none;"></div>
                <div id="matchResult" class="match-result" style="display: none;"></div>
                <div id="ocrResult" class="ocr-result" style="display: none;"></div>
            </div>
        </div>

        <!-- 出库表单 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">📦 出库信息</h5>
            </div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">出库数量</label>
                        <input type="number" id="outboundQuantity" name="outbound_quantity" class="form-control" 
                               required min="1" max="<?php echo $plan['planned_quantity'] - $plan['total_outbound']; ?>"
                               placeholder="识别后自动填写">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">备注（识别码）</label>
                        <input type="text" id="remarkInput" name="remark" class="form-control" 
                               placeholder="WOXPJ后3位数字" value="<?php echo htmlspecialchars(substr($plan['product_code'], -3)); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">上传照片（可选）</label>
                        <input type="file" name="photo" class="form-control" accept="image/*">
                        <small class="text-muted">可选：保存出库照片记录</small>
                    </div>
                    <button type="submit" class="btn btn-success w-100 btn-lg">✅ 确认出库</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tesseract.js@4/dist/tesseract.min.js"></script>
    <script>
        // 相机控制组件类
        class CameraController {
            constructor(videoElement) {
                this.video = videoElement;
                this.canvas = document.createElement('canvas');
                this.ctx = this.canvas.getContext('2d');
                this.stream = null;
                this.isActive = false;
                this.constraints = {
                    video: {
                        facingMode: 'environment',
                        width: { ideal: 1280 },
                        height: { ideal: 720 }
                    }
                };
            }

            isSupported() {
                return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
            }

            async startCamera() {
                if (!this.isSupported()) {
                    throw new Error('您的浏览器不支持相机功能');
                }

                if (this.isActive) {
                    return;
                }

                try {
                    this.stream = await navigator.mediaDevices.getUserMedia(this.constraints);
                    this.video.srcObject = this.stream;
                    this.isActive = true;
                    
                    return new Promise((resolve) => {
                        this.video.onloadedmetadata = () => {
                            resolve();
                        };
                    });
                } catch (error) {
                    this.handleCameraError(error);
                    throw error;
                }
            }

            stopCamera() {
                if (this.stream) {
                    this.stream.getTracks().forEach(track => track.stop());
                    this.video.srcObject = null;
                    this.stream = null;
                    this.isActive = false;
                }
            }

            async capturePhoto() {
                if (!this.isActive || !this.video.videoWidth) {
                    throw new Error('相机未启动或视频未加载');
                }

                this.canvas.width = this.video.videoWidth;
                this.canvas.height = this.video.videoHeight;
                this.ctx.drawImage(this.video, 0, 0);

                return new Promise((resolve) => {
                    this.canvas.toBlob((blob) => {
                        resolve(blob);
                    }, 'image/jpeg', 0.9);
                });
            }

            handleCameraError(error) {
                let message = '相机访问失败';
                
                switch (error.name) {
                    case 'NotAllowedError':
                        message = '相机权限被拒绝，请在浏览器设置中允许相机访问';
                        break;
                    case 'NotFoundError':
                        message = '未找到可用的相机设备';
                        break;
                    case 'NotSupportedError':
                        message = '您的浏览器不支持相机功能';
                        break;
                    case 'NotReadableError':
                        message = '相机被其他应用占用，请关闭其他应用后重试';
                        break;
                    default:
                        message = `相机错误: ${error.message}`;
                }
                
                console.error('Camera error:', error);
                return message;
            }
        }

        // 初始化组件
        const video = document.getElementById('video');
        const cameraController = new CameraController(video);
        const currentProductCode = document.getElementById('currentProductCode').textContent.trim();

        // 相机控制按钮事件
        document.getElementById('startCamera').addEventListener('click', async function() {
            const button = this;
            
            if (cameraController.isActive) {
                cameraController.stopCamera();
                button.textContent = '📷 启动相机';
                button.className = 'btn btn-primary';
                showStatus('相机已关闭', 'success');
            } else {
                button.disabled = true;
                showStatus('正在启动相机...', 'processing');
                
                try {
                    await cameraController.startCamera();
                    button.textContent = '❌ 关闭相机';
                    button.className = 'btn btn-danger';
                    showStatus('相机启动成功，可以开始拍照识别', 'success');
                } catch (error) {
                    const errorMessage = cameraController.handleCameraError(error);
                    showStatus(errorMessage, 'error');
                    
                    if (error.name === 'NotAllowedError' || error.name === 'NotFoundError') {
                        showStatus('您可以使用"选择图片"功能上传照片进行识别', 'warning');
                    }
                } finally {
                    button.disabled = false;
                }
            }
        });
        // 拍照按钮事件
        document.getElementById('captureBtn').addEventListener('click', async function() {
            if (!cameraController.isActive) {
                showStatus('请先启动相机', 'error');
                return;
            }
            
            try {
                showStatus('正在拍照...', 'processing');
                
                // 添加拍照闪光效果
                const cameraContainer = document.querySelector('.camera-container');
                cameraContainer.classList.add('capture-success');
                setTimeout(() => cameraContainer.classList.remove('capture-success'), 300);
                
                // 播放拍照音效（如果支持）
                try {
                    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
                    audio.volume = 0.3;
                    audio.play().catch(() => {}); // 忽略音频播放错误
                } catch (e) {}
                
                const blob = await cameraController.capturePhoto();
                
                // 显示预览
                showPhotoPreview(blob);
                showStatus('拍照成功！请确认照片或重新拍照', 'success');
                
            } catch (error) {
                showStatus('拍照失败：' + error.message, 'error');
            }
        });
        
        // 选择图片按钮事件
        document.getElementById('uploadBtn').addEventListener('click', function() {
            document.getElementById('fileInput').click();
        });
        
        // 文件选择事件
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(file.type)) {
                    showStatus('请选择有效的图片文件 (JPG, PNG, GIF)', 'error');
                    return;
                }
                
                if (file.size > 10 * 1024 * 1024) {
                    showStatus('图片文件过大，请选择小于10MB的图片', 'error');
                    return;
                }
                
                showStatus('正在处理图片...', 'processing');
                ocrEngine.recognizeText(file);
            }
        });

        // 降级和替代方案处理器
        class FallbackHandler {
            constructor() {
                this.fallbackState = {
                    cameraUnavailable: false,
                    ocrFailed: false,
                    networkOffline: false,
                    retryCount: 0,
                    maxRetries: 3
                };
                
                this.initNetworkMonitoring();
            }
            
            // 初始化网络监控
            initNetworkMonitoring() {
                // 监听网络状态变化
                window.addEventListener('online', () => {
                    this.fallbackState.networkOffline = false;
                    this.handleNetworkRestore();
                });
                
                window.addEventListener('offline', () => {
                    this.fallbackState.networkOffline = true;
                    this.handleNetworkOffline();
                });
                
                // 初始网络状态检查
                this.fallbackState.networkOffline = !navigator.onLine;
            }
            
            // 处理相机不可用的降级方案
            handleCameraFallback(error) {
                this.fallbackState.cameraUnavailable = true;
                
                console.log('相机降级处理:', error.name);
                
                // 隐藏相机相关按钮
                const startCameraBtn = document.getElementById('startCamera');
                const captureBtn = document.getElementById('captureBtn');
                
                if (startCameraBtn) {
                    startCameraBtn.style.display = 'none';
                }
                if (captureBtn) {
                    captureBtn.style.display = 'none';
                }
                
                // 突出显示图片上传选项
                this.highlightUploadOption();
                
                // 显示降级提示
                const fallbackMessage = this.getCameraFallbackMessage(error.name);
                showStatus(fallbackMessage, 'warning');
                
                // 添加降级状态指示
                this.showFallbackIndicator('camera', '相机不可用，已切换到图片上传模式');
            }
            
            // 获取相机降级提示信息
            getCameraFallbackMessage(errorName) {
                const messages = {
                    'NotAllowedError': '相机权限被拒绝，请使用"选择图片"功能上传照片进行识别',
                    'NotFoundError': '未检测到相机设备，请使用"选择图片"功能上传照片进行识别',
                    'NotSupportedError': '浏览器不支持相机功能，请使用"选择图片"功能上传照片进行识别',
                    'NotReadableError': '相机被其他应用占用，请使用"选择图片"功能上传照片进行识别'
                };
                
                return messages[errorName] || '相机暂时不可用，请使用"选择图片"功能上传照片进行识别';
            }
            
            // 突出显示上传选项
            highlightUploadOption() {
                const uploadBtn = document.getElementById('uploadBtn');
                if (uploadBtn) {
                    uploadBtn.classList.remove('btn-info');
                    uploadBtn.classList.add('btn-primary');
                    uploadBtn.innerHTML = '📁 选择图片 (推荐)';
                    
                    // 添加脉冲动画效果
                    uploadBtn.style.animation = 'pulse 2s infinite';
                    
                    // 3秒后移除动画
                    setTimeout(() => {
                        uploadBtn.style.animation = '';
                    }, 6000);
                }
            }
            
            // 处理OCR失败的降级方案
            handleOCRFallback(error, context = {}) {
                this.fallbackState.ocrFailed = true;
                this.fallbackState.retryCount++;
                
                console.log('OCR降级处理:', error.message, '重试次数:', this.fallbackState.retryCount);
                
                // 如果还有重试机会
                if (this.fallbackState.retryCount < this.fallbackState.maxRetries) {
                    const retryDelay = this.fallbackState.retryCount * 1000; // 递增延时
                    
                    showStatus(`OCR识别失败，${retryDelay/1000}秒后自动重试 (${this.fallbackState.retryCount}/${this.fallbackState.maxRetries})`, 'warning');
                    
                    setTimeout(() => {
                        if (context.retryFunction) {
                            context.retryFunction();
                        }
                    }, retryDelay);
                    
                    return false; // 表示正在重试
                }
                
                // 重试次数用完，提供手动输入选项
                this.showManualInputOption();
                this.showFallbackIndicator('ocr', 'OCR识别失败，已切换到手动输入模式');
                
                return true; // 表示已降级
            }
            
            // 显示手动输入选项
            showManualInputOption() {
                // 聚焦到出库数量输入框
                const quantityInput = document.querySelector('input[name="outbound_quantity"]');
                if (quantityInput) {
                    quantityInput.focus();
                    quantityInput.style.borderColor = '#007bff';
                    quantityInput.style.boxShadow = '0 0 0 0.2rem rgba(0,123,255,.25)';
                }
                
                // 显示手动输入提示
                const manualInputTip = document.createElement('div');
                manualInputTip.id = 'manualInputTip';
                manualInputTip.className = 'alert alert-info mt-2';
                manualInputTip.innerHTML = `
                    <strong>💡 手动输入提示：</strong><br>
                    • 请手动输入出库数量<br>
                    • 可在备注中添加相关信息<br>
                    • 如需重新尝试OCR识别，请重新选择图片
                `;
                
                // 插入到表单区域
                const formContainer = document.querySelector('.container form');
                if (formContainer && !document.getElementById('manualInputTip')) {
                    const firstFormGroup = formContainer.querySelector('.mb-3');
                    if (firstFormGroup) {
                        firstFormGroup.parentNode.insertBefore(manualInputTip, firstFormGroup);
                    }
                }
                
                // 5秒后自动移除提示
                setTimeout(() => {
                    const tip = document.getElementById('manualInputTip');
                    if (tip) {
                        tip.remove();
                    }
                    if (quantityInput) {
                        quantityInput.style.borderColor = '';
                        quantityInput.style.boxShadow = '';
                    }
                }, 10000);
            }
            
            // 处理网络离线状态
            handleNetworkOffline() {
                console.log('网络离线，启用离线模式');
                
                this.showFallbackIndicator('network', '网络连接中断，已启用离线模式');
                
                // 显示离线提示
                showStatus('网络连接中断，当前处于离线模式。数据将在网络恢复后同步。', 'warning');
                
                // 启用离线数据存储
                this.enableOfflineStorage();
            }
            
            // 处理网络恢复
            handleNetworkRestore() {
                console.log('网络已恢复');
                
                this.hideFallbackIndicator('network');
                showStatus('网络连接已恢复', 'success');
                
                // 同步离线数据
                this.syncOfflineData();
            }
            
            // 启用离线存储
            enableOfflineStorage() {
                // 检查localStorage支持
                if (!this.isLocalStorageAvailable()) {
                    showStatus('浏览器不支持离线存储功能', 'error');
                    return;
                }
                
                // 保存当前表单状态
                this.saveFormStateToLocal();
                
                // 修改表单提交行为
                this.modifyFormForOffline();
            }
            
            // 检查localStorage可用性
            isLocalStorageAvailable() {
                try {
                    const test = '__localStorage_test__';
                    localStorage.setItem(test, test);
                    localStorage.removeItem(test);
                    return true;
                } catch (e) {
                    return false;
                }
            }
            
            // 保存表单状态到本地
            saveFormStateToLocal() {
                const formData = {
                    timestamp: Date.now(),
                    data: {}
                };
                
                // 收集表单数据
                const form = document.querySelector('form');
                if (form) {
                    const formElements = form.querySelectorAll('input, select, textarea');
                    formElements.forEach(element => {
                        if (element.name) {
                            formData.data[element.name] = element.value;
                        }
                    });
                }
                
                // 保存到localStorage
                const offlineData = JSON.parse(localStorage.getItem('offlineOutboundData') || '[]');
                offlineData.push(formData);
                localStorage.setItem('offlineOutboundData', JSON.stringify(offlineData));
            }
            
            // 修改表单为离线模式
            modifyFormForOffline() {
                const form = document.querySelector('form');
                if (!form) return;
                
                // 添加离线提交处理
                const originalAction = form.action;
                form.addEventListener('submit', (e) => {
                    if (this.fallbackState.networkOffline) {
                        e.preventDefault();
                        this.handleOfflineSubmit(form);
                    }
                });
            }
            
            // 处理离线提交
            handleOfflineSubmit(form) {
                const formData = new FormData(form);
                const offlineEntry = {
                    timestamp: Date.now(),
                    action: form.action,
                    method: form.method || 'POST',
                    data: {}
                };
                
                // 转换FormData为普通对象
                for (let [key, value] of formData.entries()) {
                    offlineEntry.data[key] = value;
                }
                
                // 保存到离线队列
                const offlineQueue = JSON.parse(localStorage.getItem('offlineSubmissionQueue') || '[]');
                offlineQueue.push(offlineEntry);
                localStorage.setItem('offlineSubmissionQueue', JSON.stringify(offlineQueue));
                
                showStatus('数据已保存到离线队列，网络恢复后将自动提交', 'info');
                
                // 显示离线提交成功反馈
                this.showOfflineSubmitFeedback();
            }
            
            // 显示离线提交反馈
            showOfflineSubmitFeedback() {
                const feedback = document.createElement('div');
                feedback.className = 'alert alert-success mt-3';
                feedback.innerHTML = `
                    <strong>✅ 离线保存成功</strong><br>
                    您的数据已保存到本地，网络恢复后将自动同步到服务器。<br>
                    <small class="text-muted">保存时间: ${new Date().toLocaleString()}</small>
                `;
                
                const container = document.querySelector('.container');
                if (container) {
                    container.insertBefore(feedback, container.firstChild);
                    
                    // 3秒后自动移除
                    setTimeout(() => {
                        feedback.remove();
                    }, 5000);
                }
            }
            
            // 同步离线数据
            async syncOfflineData() {
                const offlineQueue = JSON.parse(localStorage.getItem('offlineSubmissionQueue') || '[]');
                
                if (offlineQueue.length === 0) {
                    return;
                }
                
                showStatus(`正在同步 ${offlineQueue.length} 条离线数据...`, 'processing');
                
                let successCount = 0;
                let failCount = 0;
                
                for (let i = 0; i < offlineQueue.length; i++) {
                    const entry = offlineQueue[i];
                    
                    try {
                        const formData = new FormData();
                        Object.entries(entry.data).forEach(([key, value]) => {
                            formData.append(key, value);
                        });
                        
                        const response = await fetch(entry.action, {
                            method: entry.method,
                            body: formData
                        });
                        
                        if (response.ok) {
                            successCount++;
                        } else {
                            failCount++;
                        }
                    } catch (error) {
                        console.error('同步离线数据失败:', error);
                        failCount++;
                    }
                }
                
                // 清除已同步的数据
                if (successCount > 0) {
                    localStorage.removeItem('offlineSubmissionQueue');
                }
                
                // 显示同步结果
                if (failCount === 0) {
                    showStatus(`离线数据同步完成，成功同步 ${successCount} 条记录`, 'success');
                } else {
                    showStatus(`部分数据同步失败，成功: ${successCount}，失败: ${failCount}`, 'warning');
                }
            }
            
            // 显示降级状态指示器
            showFallbackIndicator(type, message) {
                const indicator = document.createElement('div');
                indicator.id = `fallback-indicator-${type}`;
                indicator.className = 'alert alert-warning alert-dismissible fade show mt-2';
                indicator.innerHTML = `
                    <strong>⚠️ 降级模式:</strong> ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                
                // 插入到页面顶部
                const container = document.querySelector('.container');
                if (container && !document.getElementById(`fallback-indicator-${type}`)) {
                    container.insertBefore(indicator, container.firstChild);
                }
            }
            
            // 隐藏降级状态指示器
            hideFallbackIndicator(type) {
                const indicator = document.getElementById(`fallback-indicator-${type}`);
                if (indicator) {
                    indicator.remove();
                }
            }
            
            // 重置降级状态
            resetFallbackState() {
                this.fallbackState = {
                    cameraUnavailable: false,
                    ocrFailed: false,
                    networkOffline: !navigator.onLine,
                    retryCount: 0,
                    maxRetries: 3
                };
                
                // 移除所有降级指示器
                ['camera', 'ocr', 'network'].forEach(type => {
                    this.hideFallbackIndicator(type);
                });
                
                // 恢复按钮状态
                this.restoreButtonStates();
            }
            
            // 恢复按钮状态
            restoreButtonStates() {
                const startCameraBtn = document.getElementById('startCamera');
                const uploadBtn = document.getElementById('uploadBtn');
                
                if (startCameraBtn && !this.fallbackState.cameraUnavailable) {
                    startCameraBtn.style.display = '';
                }
                
                if (uploadBtn) {
                    uploadBtn.classList.remove('btn-primary');
                    uploadBtn.classList.add('btn-info');
                    uploadBtn.innerHTML = '📁 选择图片';
                    uploadBtn.style.animation = '';
                }
            }
            
            // 获取降级状态报告
            getFallbackStatus() {
                return {
                    cameraUnavailable: this.fallbackState.cameraUnavailable,
                    ocrFailed: this.fallbackState.ocrFailed,
                    networkOffline: this.fallbackState.networkOffline,
                    retryCount: this.fallbackState.retryCount,
                    hasOfflineData: this.hasOfflineData()
                };
            }
            
            // 检查是否有离线数据
            hasOfflineData() {
                const offlineQueue = JSON.parse(localStorage.getItem('offlineSubmissionQueue') || '[]');
                return offlineQueue.length > 0;
            }
        }

        // 错误处理框架
        class ErrorHandler {
            constructor() {
                this.errorLog = [];
                this.maxLogSize = 100;
                this.retryAttempts = new Map();
                this.maxRetries = 3;
                this.retryDelay = 1000;
                
                this.errorTypes = {
                    CAMERA_ERROR: 'camera',
                    OCR_ERROR: 'ocr',
                    NETWORK_ERROR: 'network',
                    VALIDATION_ERROR: 'validation',
                    FORM_ERROR: 'form',
                    IMAGE_PROCESSING_ERROR: 'image_processing',
                    PERMISSION_ERROR: 'permission',
                    UNKNOWN_ERROR: 'unknown'
                };
                
                this.errorSeverity = {
                    LOW: 'low',
                    MEDIUM: 'medium',
                    HIGH: 'high',
                    CRITICAL: 'critical'
                };
                
                this.recoveryStrategies = {
                    RETRY: 'retry',
                    FALLBACK: 'fallback',
                    USER_ACTION: 'user_action',
                    IGNORE: 'ignore',
                    RELOAD: 'reload'
                };
                
                this.init();
            }

            init() {
                this.setupGlobalErrorHandling();
                this.setupUnhandledRejectionHandling();
                this.createErrorReportingUI();
            }

            handleError(error, context = {}) {
                const errorInfo = this.analyzeError(error, context);
                this.logError(errorInfo);
                
                const recovery = this.determineRecoveryStrategy(errorInfo);
                return this.executeRecovery(errorInfo, recovery);
            }

            analyzeError(error, context) {
                const errorInfo = {
                    id: Date.now(),
                    timestamp: new Date(),
                    message: error.message || error.toString(),
                    stack: error.stack,
                    type: this.classifyError(error),
                    severity: this.determineSeverity(error),
                    context: context,
                    userAgent: navigator.userAgent,
                    url: window.location.href,
                    retryCount: this.getRetryCount(context.operation || 'unknown')
                };

                if (error.name) errorInfo.name = error.name;
                if (error.code) errorInfo.code = error.code;
                
                return errorInfo;
            }

            classifyError(error) {
                const message = error.message?.toLowerCase() || '';
                const name = error.name?.toLowerCase() || '';

                if (name.includes('notallowed') || message.includes('permission')) {
                    return this.errorTypes.PERMISSION_ERROR;
                }
                if (name.includes('notfound') || message.includes('camera') || message.includes('media')) {
                    return this.errorTypes.CAMERA_ERROR;
                }
                if (message.includes('tesseract') || message.includes('ocr') || message.includes('recognize')) {
                    return this.errorTypes.OCR_ERROR;
                }
                if (message.includes('network') || message.includes('fetch') || name.includes('networkerror')) {
                    return this.errorTypes.NETWORK_ERROR;
                }
                if (message.includes('image') || message.includes('canvas') || message.includes('blob')) {
                    return this.errorTypes.IMAGE_PROCESSING_ERROR;
                }
                if (message.includes('validation') || message.includes('invalid')) {
                    return this.errorTypes.VALIDATION_ERROR;
                }
                if (message.includes('form') || message.includes('input')) {
                    return this.errorTypes.FORM_ERROR;
                }

                return this.errorTypes.UNKNOWN_ERROR;
            }

            determineSeverity(error) {
                const type = this.classifyError(error);
                
                switch (type) {
                    case this.errorTypes.PERMISSION_ERROR:
                    case this.errorTypes.CAMERA_ERROR:
                        return this.errorSeverity.HIGH;
                    case this.errorTypes.OCR_ERROR:
                    case this.errorTypes.IMAGE_PROCESSING_ERROR:
                        return this.errorSeverity.MEDIUM;
                    case this.errorTypes.VALIDATION_ERROR:
                    case this.errorTypes.FORM_ERROR:
                        return this.errorSeverity.LOW;
                    case this.errorTypes.NETWORK_ERROR:
                        return this.errorSeverity.MEDIUM;
                    default:
                        return this.errorSeverity.MEDIUM;
                }
            }

            determineRecoveryStrategy(errorInfo) {
                const { type, severity, retryCount } = errorInfo;

                switch (type) {
                    case this.errorTypes.CAMERA_ERROR:
                        return {
                            strategy: this.recoveryStrategies.FALLBACK,
                            action: 'showImageUpload',
                            message: '相机不可用，请使用图片上传功能'
                        };
                    case this.errorTypes.PERMISSION_ERROR:
                        return {
                            strategy: this.recoveryStrategies.USER_ACTION,
                            action: 'requestPermission',
                            message: '需要相机权限，请在浏览器设置中允许访问'
                        };
                    case this.errorTypes.OCR_ERROR:
                        if (retryCount < this.maxRetries) {
                            return {
                                strategy: this.recoveryStrategies.RETRY,
                                action: 'retryOCR',
                                delay: this.retryDelay * (retryCount + 1),
                                message: `OCR识别失败，正在重试 (${retryCount + 1}/${this.maxRetries})`
                            };
                        } else {
                            return {
                                strategy: this.recoveryStrategies.FALLBACK,
                                action: 'manualInput',
                                message: 'OCR识别多次失败，请手动输入信息'
                            };
                        }
                    default:
                        return {
                            strategy: this.recoveryStrategies.IGNORE,
                            action: 'logOnly',
                            message: '发生错误，已记录日志'
                        };
                }
            }

            async executeRecovery(errorInfo, recovery) {
                const { strategy, action, delay, message } = recovery;
                this.showUserFriendlyError(errorInfo, message);

                switch (strategy) {
                    case this.recoveryStrategies.RETRY:
                        return this.executeRetry(errorInfo, action, delay);
                    case this.recoveryStrategies.FALLBACK:
                        return this.executeFallback(errorInfo, action);
                    case this.recoveryStrategies.USER_ACTION:
                        return this.requestUserAction(errorInfo, action);
                    default:
                        return { success: false, handled: true };
                }
            }

            async executeRetry(errorInfo, action, delay = 1000) {
                const operation = errorInfo.context.operation || 'unknown';
                this.incrementRetryCount(operation);

                await new Promise(resolve => setTimeout(resolve, delay));

                try {
                    switch (action) {
                        case 'retryOCR':
                            if (errorInfo.context.retryFunction) {
                                return await errorInfo.context.retryFunction();
                            }
                            break;
                    }
                    
                    return { success: false, handled: true };
                } catch (retryError) {
                    return this.handleError(retryError, {
                        ...errorInfo.context,
                        isRetry: true
                    });
                }
            }

            executeFallback(errorInfo, action) {
                switch (action) {
                    case 'showImageUpload':
                        this.showImageUploadOption();
                        break;
                    case 'manualInput':
                        this.showManualInputOption();
                        break;
                }
                
                return { success: true, handled: true, fallback: true };
            }

            requestUserAction(errorInfo, action) {
                switch (action) {
                    case 'requestPermission':
                        this.showPermissionGuide();
                        break;
                }
                
                return { success: false, handled: true, userActionRequired: true };
            }

            showUserFriendlyError(errorInfo, message) {
                const { severity } = errorInfo;
                
                let statusType = 'error';
                if (severity === this.errorSeverity.LOW) {
                    statusType = 'warning';
                }

                showStatus(message, statusType);
            }

            showImageUploadOption() {
                const cameraBtn = document.getElementById('startCamera');
                const captureBtn = document.getElementById('captureBtn');
                
                if (cameraBtn) cameraBtn.style.display = 'none';
                if (captureBtn) captureBtn.style.display = 'none';
                
                showStatus('相机不可用，请使用"选择图片"功能上传照片', 'warning');
            }

            showManualInputOption() {
                showStatus('OCR识别失败，请手动输入产品信息', 'warning');
                
                const firstInput = document.getElementById('outboundQuantity');
                if (firstInput) {
                    firstInput.focus();
                }
            }

            showPermissionGuide() {
                const guide = `
请按以下步骤允许相机权限：
1. 点击地址栏左侧的锁图标
2. 选择"允许"相机权限
3. 刷新页面重试

或者您可以使用"选择图片"功能上传照片。
                `.trim();

                showStatus(guide, 'info');
            }

            getRetryCount(operation) {
                return this.retryAttempts.get(operation) || 0;
            }

            incrementRetryCount(operation) {
                const current = this.getRetryCount(operation);
                this.retryAttempts.set(operation, current + 1);
            }

            logError(errorInfo) {
                this.errorLog.unshift(errorInfo);
                
                if (this.errorLog.length > this.maxLogSize) {
                    this.errorLog = this.errorLog.slice(0, this.maxLogSize);
                }

                console.error('Error logged:', errorInfo);
                this.updateErrorReportingUI();
            }

            setupGlobalErrorHandling() {
                window.addEventListener('error', (event) => {
                    this.handleError(event.error, {
                        operation: 'global',
                        source: event.filename,
                        line: event.lineno,
                        column: event.colno
                    });
                });
            }

            setupUnhandledRejectionHandling() {
                window.addEventListener('unhandledrejection', (event) => {
                    this.handleError(event.reason, {
                        operation: 'promise_rejection',
                        promise: event.promise
                    });
                });
            }

            createErrorReportingUI() {
                const errorReportBtn = document.createElement('button');
                errorReportBtn.id = 'errorReportBtn';
                errorReportBtn.className = 'btn btn-sm btn-outline-danger';
                errorReportBtn.innerHTML = '⚠️ 错误报告';
                errorReportBtn.style.cssText = `
                    position: fixed;
                    top: 10px;
                    right: 10px;
                    z-index: 1500;
                    display: none;
                `;
                
                errorReportBtn.addEventListener('click', () => {
                    this.showErrorReport();
                });
                
                document.body.appendChild(errorReportBtn);
            }

            updateErrorReportingUI() {
                const errorReportBtn = document.getElementById('errorReportBtn');
                if (errorReportBtn) {
                    errorReportBtn.style.display = this.errorLog.length > 0 ? 'block' : 'none';
                    errorReportBtn.innerHTML = `⚠️ 错误报告 (${this.errorLog.length})`;
                }
            }

            showErrorReport() {
                const recentErrors = this.errorLog.slice(0, 10);
                let reportContent = '最近错误报告：\n\n';
                
                recentErrors.forEach((error, index) => {
                    reportContent += `${index + 1}. ${error.timestamp.toLocaleTimeString()}\n`;
                    reportContent += `   类型: ${error.type}\n`;
                    reportContent += `   消息: ${error.message}\n`;
                    reportContent += `   严重程度: ${error.severity}\n\n`;
                });

                const reportWindow = window.open('', '_blank', 'width=600,height=500');
                reportWindow.document.write(`
                    <html>
                        <head><title>错误报告</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${reportContent}
                        </body>
                    </html>
                `);
            }

            getErrorStats() {
                const stats = {
                    totalErrors: this.errorLog.length,
                    errorsByType: {},
                    errorsBySeverity: {},
                    recentErrors: this.errorLog.slice(0, 5)
                };

                this.errorLog.forEach(error => {
                    stats.errorsByType[error.type] = (stats.errorsByType[error.type] || 0) + 1;
                    stats.errorsBySeverity[error.severity] = (stats.errorsBySeverity[error.severity] || 0) + 1;
                });

                return stats;
            }

            clearErrorLog() {
                this.errorLog = [];
                this.retryAttempts.clear();
                this.updateErrorReportingUI();
                showStatus('错误日志已清除', 'success', true);
            }
        }

        // 用户交互管理器
        class InteractionManager {
            constructor() {
                this.fillOperations = [];
                this.maxOperations = 10;
                this.highlightedElements = new Set();
                this.shortcuts = {
                    undo: 'ctrl+z',
                    redo: 'ctrl+y',
                    clear: 'ctrl+shift+c',
                    refill: 'ctrl+r'
                };
                
                this.init();
            }

            init() {
                this.setupKeyboardShortcuts();
                this.createInteractionUI();
                this.setupTooltips();
            }

            recordFillOperation(operation) {
                const fillOp = {
                    id: Date.now(),
                    timestamp: new Date(),
                    type: 'fill',
                    field: operation.field,
                    element: operation.element,
                    oldValue: operation.oldValue,
                    newValue: operation.newValue,
                    source: operation.source,
                    confidence: operation.confidence,
                    canUndo: true
                };

                this.fillOperations.push(fillOp);
                
                if (this.fillOperations.length > this.maxOperations) {
                    this.fillOperations.shift();
                }

                this.updateInteractionUI();
                return fillOp.id;
            }

            highlightFillResult(element, options = {}) {
                const defaultOptions = {
                    duration: 3000,
                    showBadge: true,
                    showTooltip: true,
                    animationType: 'pulse'
                };
                
                const config = { ...defaultOptions, ...options };
                
                element.classList.add('fill-highlighted');
                this.highlightedElements.add(element);

                if (config.showBadge) {
                    this.addFillBadge(element, config);
                }

                if (config.showTooltip) {
                    this.addFillTooltip(element, config);
                }

                this.addFillAnimation(element, config.animationType);

                setTimeout(() => {
                    this.removeHighlight(element);
                }, config.duration);
            }

            addFillBadge(element, config) {
                const existingBadge = element.parentNode.querySelector('.fill-badge');
                if (existingBadge) {
                    existingBadge.remove();
                }

                const badge = document.createElement('span');
                badge.className = 'fill-badge';
                badge.innerHTML = '✨ 自动填充';
                badge.style.cssText = `
                    position: absolute;
                    top: -8px;
                    right: -8px;
                    background: #28a745;
                    color: white;
                    font-size: 10px;
                    padding: 2px 6px;
                    border-radius: 10px;
                    z-index: 1000;
                    animation: badgeFadeIn 0.3s ease-out;
                `;

                if (getComputedStyle(element.parentNode).position === 'static') {
                    element.parentNode.style.position = 'relative';
                }

                element.parentNode.appendChild(badge);

                setTimeout(() => {
                    if (badge.parentNode) {
                        badge.style.animation = 'badgeFadeOut 0.3s ease-out';
                        setTimeout(() => badge.remove(), 300);
                    }
                }, 2500);
            }

            addFillTooltip(element, config) {
                const tooltip = document.createElement('div');
                tooltip.className = 'fill-tooltip';
                tooltip.innerHTML = `
                    <div class="tooltip-content">
                        <strong>自动填充</strong><br>
                        来源: ${config.source || '未知'}<br>
                        置信度: ${config.confidence || 0}%<br>
                        <small>按 Ctrl+Z 撤销</small>
                    </div>
                `;
                
                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0,0,0,0.8);
                    color: white;
                    padding: 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    z-index: 1001;
                    pointer-events: none;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                `;

                document.body.appendChild(tooltip);

                const rect = element.getBoundingClientRect();
                tooltip.style.left = rect.left + 'px';
                tooltip.style.top = (rect.bottom + 5) + 'px';
                
                setTimeout(() => tooltip.style.opacity = '1', 100);

                setTimeout(() => {
                    tooltip.style.opacity = '0';
                    setTimeout(() => tooltip.remove(), 300);
                }, 2000);
            }

            addFillAnimation(element, animationType) {
                element.classList.add(`fill-animation-${animationType}`);
                
                setTimeout(() => {
                    element.classList.remove(`fill-animation-${animationType}`);
                }, 1000);
            }

            removeHighlight(element) {
                element.classList.remove('fill-highlighted');
                this.highlightedElements.delete(element);
                
                const badge = element.parentNode.querySelector('.fill-badge');
                if (badge) badge.remove();
            }

            clearAllFills() {
                const confirmation = confirm('确定要清除所有自动填充的内容吗？');
                if (!confirmation) return;

                let clearedCount = 0;
                this.fillOperations.forEach(op => {
                    if (op.canUndo && op.element && op.element.value === op.newValue) {
                        op.element.value = op.oldValue;
                        op.element.classList.remove('is-valid', 'is-invalid');
                        this.removeHighlight(op.element);
                        clearedCount++;
                    }
                });

                this.fillOperations = [];
                this.updateInteractionUI();

                showStatus(`已清除 ${clearedCount} 个自动填充字段`, 'success', true);
            }

            refillLastResults() {
                if (this.fillOperations.length === 0) {
                    showStatus('没有可重新填充的内容', 'warning');
                    return;
                }

                const lastOperations = this.fillOperations.slice(-2);
                let refilledCount = 0;

                lastOperations.forEach(op => {
                    if (op.element) {
                        op.element.value = op.newValue;
                        this.highlightFillResult(op.element, {
                            source: op.source + ' (重填)',
                            confidence: op.confidence
                        });
                        refilledCount++;
                    }
                });

                showStatus(`已重新填充 ${refilledCount} 个字段`, 'success', true);
            }

            undoLastFill() {
                const lastFillOp = [...this.fillOperations].reverse().find(op => op.canUndo);
                
                if (!lastFillOp) {
                    showStatus('没有可撤销的填充操作', 'warning');
                    return;
                }

                if (lastFillOp.element && lastFillOp.element.value === lastFillOp.newValue) {
                    lastFillOp.element.value = lastFillOp.oldValue;
                    lastFillOp.element.classList.remove('is-valid', 'is-invalid');
                    this.removeHighlight(lastFillOp.element);
                    lastFillOp.canUndo = false;
                    
                    showStatus(`已撤销 ${lastFillOp.field} 字段的填充`, 'success', true);
                } else {
                    showStatus('该字段已被手动修改，无法撤销', 'warning');
                }

                this.updateInteractionUI();
            }

            setupKeyboardShortcuts() {
                document.addEventListener('keydown', (e) => {
                    if (e.ctrlKey && e.key === 'z' && !e.shiftKey) {
                        e.preventDefault();
                        this.undoLastFill();
                    }
                    
                    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
                        e.preventDefault();
                        this.clearAllFills();
                    }
                    
                    if (e.ctrlKey && e.key === 'r') {
                        e.preventDefault();
                        this.refillLastResults();
                    }
                });
            }

            createInteractionUI() {
                const floatingActions = document.createElement('div');
                floatingActions.id = 'floatingActions';
                floatingActions.className = 'floating-actions';
                floatingActions.innerHTML = `
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="undoFill" title="撤销填充 (Ctrl+Z)">
                        ↶ 撤销
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-warning" id="clearAllFills" title="清除所有 (Ctrl+Shift+C)">
                        🗑️ 清除
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-info" id="refillLast" title="重新填充 (Ctrl+R)">
                        🔄 重填
                    </button>
                `;

                floatingActions.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    display: flex;
                    gap: 5px;
                    z-index: 1000;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                `;

                document.body.appendChild(floatingActions);

                document.getElementById('undoFill').addEventListener('click', () => this.undoLastFill());
                document.getElementById('clearAllFills').addEventListener('click', () => this.clearAllFills());
                document.getElementById('refillLast').addEventListener('click', () => this.refillLastResults());

                this.updateInteractionUI();
            }

            updateInteractionUI() {
                const floatingActions = document.getElementById('floatingActions');
                if (!floatingActions) return;

                const hasOperations = this.fillOperations.length > 0;
                const hasUndoableOperations = this.fillOperations.some(op => op.canUndo);

                floatingActions.style.opacity = hasOperations ? '1' : '0';
                
                const undoBtn = document.getElementById('undoFill');
                const clearBtn = document.getElementById('clearAllFills');
                const refillBtn = document.getElementById('refillLast');

                if (undoBtn) undoBtn.disabled = !hasUndoableOperations;
                if (clearBtn) clearBtn.disabled = !hasOperations;
                if (refillBtn) refillBtn.disabled = !hasOperations;
            }

            setupTooltips() {
                const formFields = document.querySelectorAll('#outboundQuantity, #remarkInput');
                
                formFields.forEach(field => {
                    field.addEventListener('focus', () => {
                        if (!field.dataset.tooltipAdded) {
                            field.title = '支持自动填充 | 右键查看选项 | Ctrl+Z撤销';
                            field.dataset.tooltipAdded = 'true';
                        }
                    });

                    field.addEventListener('contextmenu', (e) => {
                        e.preventDefault();
                        this.showContextMenu(e, field);
                    });
                });
            }

            showContextMenu(event, field) {
                const existingMenu = document.querySelector('.context-menu');
                if (existingMenu) existingMenu.remove();

                const menu = document.createElement('div');
                menu.className = 'context-menu';
                menu.innerHTML = `
                    <div class="context-menu-item" data-action="clear">清除内容</div>
                    <div class="context-menu-item" data-action="undo">撤销填充</div>
                    <div class="context-menu-item" data-action="refill">重新填充</div>
                    <hr class="context-menu-divider">
                    <div class="context-menu-item" data-action="copy">复制内容</div>
                `;

                menu.style.cssText = `
                    position: fixed;
                    left: ${event.clientX}px;
                    top: ${event.clientY}px;
                    background: white;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    z-index: 1002;
                    min-width: 120px;
                `;

                document.body.appendChild(menu);

                menu.addEventListener('click', (e) => {
                    const action = e.target.dataset.action;
                    this.handleContextMenuAction(action, field);
                    menu.remove();
                });

                setTimeout(() => {
                    document.addEventListener('click', () => menu.remove(), { once: true });
                }, 100);
            }

            handleContextMenuAction(action, field) {
                switch (action) {
                    case 'clear':
                        field.value = '';
                        field.classList.remove('is-valid', 'is-invalid');
                        this.removeHighlight(field);
                        showStatus('字段已清除', 'success', true);
                        break;
                    case 'undo':
                        this.undoLastFill();
                        break;
                    case 'refill':
                        this.refillLastResults();
                        break;
                    case 'copy':
                        navigator.clipboard.writeText(field.value).then(() => {
                            showStatus('内容已复制到剪贴板', 'success', true);
                        });
                        break;
                }
            }

            getInteractionStats() {
                return {
                    totalOperations: this.fillOperations.length,
                    undoableOperations: this.fillOperations.filter(op => op.canUndo).length,
                    highlightedElements: this.highlightedElements.size,
                    recentOperations: this.fillOperations.slice(-5)
                };
            }

            initStyles() {
                const style = document.createElement('style');
                style.textContent = `
                    .fill-highlighted {
                        background-color: #e8f5e8 !important;
                        border-color: #28a745 !important;
                        box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25) !important;
                    }
                    
                    .fill-animation-pulse {
                        animation: fillPulse 0.6s ease-in-out;
                    }
                    
                    @keyframes fillPulse {
                        0% { transform: scale(1); }
                        50% { transform: scale(1.05); }
                        100% { transform: scale(1); }
                    }
                    
                    @keyframes badgeFadeIn {
                        from { opacity: 0; transform: scale(0.8); }
                        to { opacity: 1; transform: scale(1); }
                    }
                    
                    @keyframes badgeFadeOut {
                        from { opacity: 1; transform: scale(1); }
                        to { opacity: 0; transform: scale(0.8); }
                    }
                    
                    .floating-actions {
                        backdrop-filter: blur(10px);
                        background: rgba(255, 255, 255, 0.9);
                        padding: 8px;
                        border-radius: 8px;
                        border: 1px solid rgba(0, 0, 0, 0.1);
                    }
                    
                    .context-menu {
                        font-size: 14px;
                    }
                    
                    .context-menu-item {
                        padding: 8px 12px;
                        cursor: pointer;
                        transition: background-color 0.2s;
                    }
                    
                    .context-menu-item:hover {
                        background-color: #f8f9fa;
                    }
                    
                    .context-menu-divider {
                        margin: 4px 0;
                        border: none;
                        border-top: 1px solid #eee;
                    }
                `;
                document.head.appendChild(style);
            }
        }

        // 智能表单控制器
        class FormController {
            constructor() {
                this.formElements = {
                    quantity: document.getElementById('outboundQuantity'),
                    remark: document.getElementById('remarkInput'),
                    photo: document.querySelector('input[name="photo"]')
                };
                
                this.fillHistory = [];
                this.maxHistorySize = 20;
                this.validationRules = {
                    quantity: {
                        min: 1,
                        max: null,
                        required: true,
                        type: 'number'
                    },
                    remark: {
                        minLength: 1,
                        maxLength: 50,
                        required: false,
                        type: 'text'
                    }
                };
                
                this.autoFillSettings = {
                    enableQuantityFill: true,
                    enableRemarkFill: true,
                    showFillAnimation: true,
                    confirmBeforeFill: false,
                    highlightFilledFields: true
                };
                
                this.init();
            }

            init() {
                if (this.formElements.quantity) {
                    this.validationRules.quantity.max = parseInt(this.formElements.quantity.max) || 999999;
                }
                
                this.addRealTimeValidation();
                this.addFillHistorySupport();
                this.initStyles();
            }

            fillQuantity(value, source = '', confidence = 0) {
                if (!this.autoFillSettings.enableQuantityFill) {
                    return { success: false, reason: '数量自动填充已禁用' };
                }

                const validation = this.validateQuantity(value);
                if (!validation.isValid) {
                    return { success: false, reason: validation.message };
                }

                const fillData = {
                    field: 'quantity',
                    oldValue: this.formElements.quantity.value,
                    newValue: validation.adjustedValue,
                    source: source,
                    confidence: confidence,
                    timestamp: new Date(),
                    wasAdjusted: validation.wasAdjusted
                };

                this.performFill(fillData);
                
                return {
                    success: true,
                    value: validation.adjustedValue,
                    wasAdjusted: validation.wasAdjusted,
                    message: validation.message
                };
            }

            fillRemark(value, source = '', confidence = 0) {
                if (!this.autoFillSettings.enableRemarkFill) {
                    return { success: false, reason: '备注自动填充已禁用' };
                }

                const validation = this.validateRemark(value);
                if (!validation.isValid) {
                    return { success: false, reason: validation.message };
                }

                const fillData = {
                    field: 'remark',
                    oldValue: this.formElements.remark.value,
                    newValue: validation.value,
                    source: source,
                    confidence: confidence,
                    timestamp: new Date(),
                    wasAdjusted: false
                };

                this.performFill(fillData);
                
                return {
                    success: true,
                    value: validation.value,
                    message: validation.message
                };
            }

            performFill(fillData) {
                const element = this.formElements[fillData.field];
                
                if (this.autoFillSettings.showFillAnimation) {
                    this.animateFill(element, fillData.newValue);
                } else {
                    element.value = fillData.newValue;
                }

                // 使用InteractionManager进行高级交互处理
                if (this.autoFillSettings.highlightFilledFields) {
                    interactionManager.highlightFillResult(element, {
                        source: fillData.source,
                        confidence: fillData.confidence,
                        showBadge: true,
                        showTooltip: true,
                        animationType: 'pulse'
                    });
                }

                // 记录到InteractionManager
                const operationData = {
                    ...fillData,
                    element: element
                };
                interactionManager.recordFillOperation(operationData);

                this.addToFillHistory(fillData);
                element.dispatchEvent(new Event('change', { bubbles: true }));
            }

            animateFill(element, newValue) {
                element.style.transition = 'all 0.3s ease';
                element.style.backgroundColor = '#e3f2fd';
                element.style.transform = 'scale(1.02)';
                
                setTimeout(() => {
                    element.value = newValue;
                    element.style.backgroundColor = '#c8e6c9';
                }, 150);
                
                setTimeout(() => {
                    element.style.backgroundColor = '';
                    element.style.transform = '';
                }, 1000);
            }

            highlightField(element) {
                element.classList.add('auto-filled');
                setTimeout(() => {
                    element.classList.remove('auto-filled');
                }, 3000);
            }

            validateQuantity(value) {
                const result = {
                    isValid: false,
                    value: value,
                    adjustedValue: value,
                    wasAdjusted: false,
                    message: ''
                };

                const numValue = parseInt(value);
                if (isNaN(numValue)) {
                    result.message = '数量必须是有效数字';
                    return result;
                }

                const rules = this.validationRules.quantity;
                if (numValue < rules.min) {
                    result.message = `数量不能小于${rules.min}`;
                    return result;
                }

                if (numValue > rules.max) {
                    result.adjustedValue = rules.max;
                    result.wasAdjusted = true;
                    result.message = `数量超出最大值，已调整为${rules.max}`;
                } else {
                    result.message = `数量验证通过：${numValue}`;
                }

                result.isValid = true;
                result.value = numValue;
                
                return result;
            }

            validateRemark(value) {
                const result = {
                    isValid: false,
                    value: value,
                    message: ''
                };

                if (!value) {
                    result.isValid = true;
                    result.message = '备注为空，使用默认值';
                    return result;
                }

                const rules = this.validationRules.remark;
                
                if (value.length > rules.maxLength) {
                    result.message = `备注长度不能超过${rules.maxLength}个字符`;
                    return result;
                }

                result.isValid = true;
                result.message = `备注验证通过：${value}`;
                
                return result;
            }

            addRealTimeValidation() {
                if (this.formElements.quantity) {
                    this.formElements.quantity.addEventListener('input', (e) => {
                        const validation = this.validateQuantity(e.target.value);
                        this.showFieldValidation(e.target, validation);
                    });
                }

                if (this.formElements.remark) {
                    this.formElements.remark.addEventListener('input', (e) => {
                        const validation = this.validateRemark(e.target.value);
                        this.showFieldValidation(e.target, validation);
                    });
                }
            }

            showFieldValidation(element, validation) {
                element.classList.remove('is-valid', 'is-invalid');
                
                if (validation.isValid) {
                    element.classList.add('is-valid');
                } else {
                    element.classList.add('is-invalid');
                }

                let feedbackElement = element.parentNode.querySelector('.validation-feedback');
                if (!feedbackElement) {
                    feedbackElement = document.createElement('div');
                    feedbackElement.className = 'validation-feedback small';
                    element.parentNode.appendChild(feedbackElement);
                }

                feedbackElement.textContent = validation.message;
                feedbackElement.className = `validation-feedback small ${validation.isValid ? 'text-success' : 'text-danger'}`;
            }

            addFillHistorySupport() {
                document.addEventListener('keydown', (e) => {
                    if (e.ctrlKey && e.key === 'h') {
                        e.preventDefault();
                        this.showFillHistory();
                    }
                });
            }

            showFillHistory() {
                if (this.fillHistory.length === 0) {
                    showStatus('暂无填充历史记录', 'info');
                    return;
                }

                let historyText = '填充历史记录：\n\n';
                this.fillHistory.slice(0, 10).forEach((record, index) => {
                    const time = new Date(record.timestamp).toLocaleTimeString();
                    historyText += `${index + 1}. ${time} - ${record.field}\n`;
                    historyText += `   ${record.oldValue} → ${record.newValue}\n`;
                    historyText += `   来源：${record.source} (${record.confidence}%)\n\n`;
                });

                const historyWindow = window.open('', '_blank', 'width=500,height=400');
                historyWindow.document.write(`
                    <html>
                        <head><title>表单填充历史</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${historyText}
                        </body>
                    </html>
                `);
            }

            addToFillHistory(fillData) {
                this.fillHistory.unshift(fillData);
                
                if (this.fillHistory.length > this.maxHistorySize) {
                    this.fillHistory = this.fillHistory.slice(0, this.maxHistorySize);
                }
            }

            initStyles() {
                const style = document.createElement('style');
                style.textContent = `
                    .auto-filled {
                        background-color: #c8e6c9 !important;
                        border-color: #4caf50 !important;
                        box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25) !important;
                    }
                    
                    .form-control.is-valid {
                        border-color: #28a745;
                    }
                    
                    .form-control.is-invalid {
                        border-color: #dc3545;
                    }
                    
                    .validation-feedback {
                        margin-top: 0.25rem;
                        font-size: 0.875em;
                    }
                `;
                document.head.appendChild(style);
            }

            resetForm() {
                Object.values(this.formElements).forEach(element => {
                    if (element && element.type !== 'file') {
                        element.value = '';
                        element.classList.remove('is-valid', 'is-invalid', 'auto-filled');
                    }
                });
                
                document.querySelectorAll('.validation-feedback').forEach(el => el.remove());
                showStatus('表单已重置', 'success', true);
            }

            getFormData() {
                return {
                    quantity: this.formElements.quantity ? parseInt(this.formElements.quantity.value) : null,
                    remark: this.formElements.remark ? this.formElements.remark.value : '',
                    hasPhoto: this.formElements.photo ? this.formElements.photo.files.length > 0 : false
                };
            }

            validateForm() {
                const data = this.getFormData();
                const errors = [];

                if (this.validationRules.quantity.required && !data.quantity) {
                    errors.push('出库数量不能为空');
                } else if (data.quantity) {
                    const quantityValidation = this.validateQuantity(data.quantity);
                    if (!quantityValidation.isValid) {
                        errors.push(quantityValidation.message);
                    }
                }

                if (data.remark) {
                    const remarkValidation = this.validateRemark(data.remark);
                    if (!remarkValidation.isValid) {
                        errors.push(remarkValidation.message);
                    }
                }

                return {
                    isValid: errors.length === 0,
                    errors: errors,
                    data: data
                };
            }

            updateSettings(newSettings) {
                this.autoFillSettings = { ...this.autoFillSettings, ...newSettings };
            }

            getFillStats() {
                const total = this.fillHistory.length;
                const quantityFills = this.fillHistory.filter(h => h.field === 'quantity').length;
                const remarkFills = this.fillHistory.filter(h => h.field === 'remark').length;
                
                return {
                    totalFills: total,
                    quantityFills: quantityFills,
                    remarkFills: remarkFills,
                    recentFills: this.fillHistory.slice(0, 5)
                };
            }
        }

        // 产品编码验证系统
        class ProductCodeValidator {
            constructor() {
                this.validationHistory = [];
                this.maxHistorySize = 50;
                this.similarityThreshold = 0.8;
                this.validationRules = {
                    exactMatch: { weight: 1.0, description: '完全匹配' },
                    partialMatch: { weight: 0.7, description: '部分匹配' },
                    similarMatch: { weight: 0.5, description: '相似匹配' },
                    noMatch: { weight: 0.0, description: '不匹配' }
                };
            }

            validateProductCode(recognizedCode, expectedCode, confidence = 0, pattern = '') {
                const validation = {
                    recognizedCode: recognizedCode,
                    expectedCode: expectedCode,
                    ocrConfidence: confidence,
                    pattern: pattern,
                    timestamp: new Date(),
                    matchType: null,
                    matchScore: 0,
                    similarity: 0,
                    isValid: false,
                    suggestions: [],
                    visualFeedback: null
                };

                validation.matchType = this.determineMatchType(recognizedCode, expectedCode);
                validation.matchScore = this.calculateMatchScore(recognizedCode, expectedCode);
                validation.similarity = this.calculateSimilarity(recognizedCode, expectedCode);
                validation.isValid = validation.matchType === 'exactMatch';
                validation.suggestions = this.generateSuggestions(recognizedCode, expectedCode);
                validation.visualFeedback = this.createVisualFeedback(validation);

                this.addToHistory(validation);

                return validation;
            }

            determineMatchType(recognized, expected) {
                if (!recognized || !expected) return 'noMatch';
                
                if (recognized === expected) {
                    return 'exactMatch';
                }

                const longestCommonSubstring = this.findLongestCommonSubstring(recognized, expected);
                if (longestCommonSubstring.length >= 6) {
                    return 'partialMatch';
                }

                const similarity = this.calculateSimilarity(recognized, expected);
                if (similarity >= this.similarityThreshold) {
                    return 'similarMatch';
                }

                return 'noMatch';
            }

            calculateMatchScore(recognized, expected) {
                if (!recognized || !expected) return 0;

                const matchType = this.determineMatchType(recognized, expected);
                const baseScore = this.validationRules[matchType].weight;
                const similarity = this.calculateSimilarity(recognized, expected);
                
                return Math.round(baseScore * similarity * 100);
            }

            calculateSimilarity(str1, str2) {
                if (!str1 || !str2) return 0;
                if (str1 === str2) return 1;

                const matrix = [];
                const len1 = str1.length;
                const len2 = str2.length;

                for (let i = 0; i <= len1; i++) {
                    matrix[i] = [i];
                }
                for (let j = 0; j <= len2; j++) {
                    matrix[0][j] = j;
                }

                for (let i = 1; i <= len1; i++) {
                    for (let j = 1; j <= len2; j++) {
                        const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
                        matrix[i][j] = Math.min(
                            matrix[i - 1][j] + 1,
                            matrix[i][j - 1] + 1,
                            matrix[i - 1][j - 1] + cost
                        );
                    }
                }

                const distance = matrix[len1][len2];
                const maxLength = Math.max(len1, len2);
                
                return maxLength === 0 ? 1 : (maxLength - distance) / maxLength;
            }

            findLongestCommonSubstring(str1, str2) {
                if (!str1 || !str2) return '';

                let longest = '';
                for (let i = 0; i < str1.length; i++) {
                    for (let j = i + 1; j <= str1.length; j++) {
                        const substring = str1.slice(i, j);
                        if (str2.includes(substring) && substring.length > longest.length) {
                            longest = substring;
                        }
                    }
                }
                return longest;
            }

            generateSuggestions(recognized, expected) {
                const suggestions = [];

                if (!recognized || !expected) {
                    return [{ type: 'error', message: '无法生成建议：缺少必要信息' }];
                }

                const similarity = this.calculateSimilarity(recognized, expected);
                const commonSubstring = this.findLongestCommonSubstring(recognized, expected);

                if (similarity > 0.8) {
                    suggestions.push({
                        type: 'warning',
                        message: `识别结果与预期非常相似 (${Math.round(similarity * 100)}%)，可能是OCR识别错误`
                    });
                } else if (similarity > 0.5) {
                    suggestions.push({
                        type: 'info',
                        message: `识别结果与预期有一定相似性 (${Math.round(similarity * 100)}%)，建议检查原图`
                    });
                }

                if (commonSubstring.length >= 6) {
                    suggestions.push({
                        type: 'info',
                        message: `发现公共部分："${commonSubstring}"，可能是部分识别正确`
                    });
                }

                const lengthDiff = Math.abs(recognized.length - expected.length);
                if (lengthDiff > 0) {
                    suggestions.push({
                        type: 'warning',
                        message: `长度不匹配：识别到${recognized.length}位，预期${expected.length}位`
                    });
                }

                const differentPositions = this.findDifferentPositions(recognized, expected);
                if (differentPositions.length > 0 && differentPositions.length <= 3) {
                    suggestions.push({
                        type: 'info',
                        message: `差异位置：第${differentPositions.join('、')}位字符不同`
                    });
                }

                return suggestions;
            }

            findDifferentPositions(str1, str2) {
                const positions = [];
                const minLength = Math.min(str1.length, str2.length);
                
                for (let i = 0; i < minLength; i++) {
                    if (str1[i] !== str2[i]) {
                        positions.push(i + 1);
                    }
                }
                
                return positions;
            }

            createVisualFeedback(validation) {
                const feedback = {
                    type: validation.isValid ? 'success' : 'error',
                    icon: validation.isValid ? '✅' : '❌',
                    title: '',
                    message: '',
                    details: [],
                    actionButtons: []
                };

                switch (validation.matchType) {
                    case 'exactMatch':
                        feedback.title = '产品编码匹配成功';
                        feedback.message = `编码：${validation.recognizedCode}`;
                        feedback.details = [
                            `匹配模式：${validation.pattern}`,
                            `OCR置信度：${validation.ocrConfidence}%`,
                            `匹配分数：${validation.matchScore}/100`
                        ];
                        break;

                    case 'partialMatch':
                        feedback.type = 'warning';
                        feedback.icon = '⚠️';
                        feedback.title = '产品编码部分匹配';
                        feedback.message = `识别到：${validation.recognizedCode}\n预期：${validation.expectedCode}`;
                        feedback.details = [
                            `相似度：${Math.round(validation.similarity * 100)}%`,
                            `匹配分数：${validation.matchScore}/100`
                        ];
                        break;

                    case 'similarMatch':
                        feedback.type = 'warning';
                        feedback.icon = '⚠️';
                        feedback.title = '产品编码相似匹配';
                        feedback.message = `识别到：${validation.recognizedCode}\n预期：${validation.expectedCode}`;
                        feedback.details = [
                            `相似度：${Math.round(validation.similarity * 100)}%`,
                            `可能是OCR识别错误`
                        ];
                        break;

                    case 'noMatch':
                        feedback.title = '产品编码不匹配';
                        feedback.message = `识别到：${validation.recognizedCode}\n当前计划：${validation.expectedCode}`;
                        feedback.details = [
                            `相似度：${Math.round(validation.similarity * 100)}%`,
                            `请确认产品是否正确`
                        ];
                        break;
                }

                return feedback;
            }

            addToHistory(validation) {
                this.validationHistory.unshift(validation);
                
                if (this.validationHistory.length > this.maxHistorySize) {
                    this.validationHistory = this.validationHistory.slice(0, this.maxHistorySize);
                }
            }

            getValidationStats() {
                if (this.validationHistory.length === 0) {
                    return { totalValidations: 0, successRate: 0, averageConfidence: 0 };
                }

                const total = this.validationHistory.length;
                const successful = this.validationHistory.filter(v => v.isValid).length;
                const totalConfidence = this.validationHistory.reduce((sum, v) => sum + v.ocrConfidence, 0);

                return {
                    totalValidations: total,
                    successRate: Math.round((successful / total) * 100),
                    averageConfidence: Math.round(totalConfidence / total),
                    recentValidations: this.validationHistory.slice(0, 5)
                };
            }

            clearHistory() {
                this.validationHistory = [];
            }
        }

        // 高级文本解析器
        class TextParser {
            constructor() {
                // 产品编码识别模式（按优先级排序）
                this.productCodePatterns = [
                    { 
                        name: '物料名称标签',
                        pattern: /(?:物料名称|物料编码|产品名称)[：:\s]*(\d{10})/gi,
                        priority: 1,
                        confidence: 0.95
                    },
                    { 
                        name: '产品编码标签',
                        pattern: /(?:产品编码|商品编码|货品编码)[：:\s]*(\d{10})/gi,
                        priority: 2,
                        confidence: 0.9
                    },
                    { 
                        name: '物料标签',
                        pattern: /(?:物料|材料)[：:\s]*(\d{10})/gi,
                        priority: 3,
                        confidence: 0.85
                    },
                    { 
                        name: '编码标签',
                        pattern: /(?:编码|代码|CODE)[：:\s]*(\d{10})/gi,
                        priority: 4,
                        confidence: 0.8
                    },
                    { 
                        name: '条形码模式',
                        pattern: /(?:条形码|条码|BARCODE)[：:\s]*(\d{10})/gi,
                        priority: 5,
                        confidence: 0.75
                    },
                    { 
                        name: '纯数字模式',
                        pattern: /(?:^|\s)(\d{10})(?:\s|$)/g,
                        priority: 6,
                        confidence: 0.6
                    }
                ];

                // 数量识别模式（按准确性排序）
                this.quantityPatterns = [
                    { 
                        name: '数量标签',
                        pattern: /(?:数量|qty|quantity)[：:\s]*(\d+)/gi,
                        priority: 1,
                        confidence: 0.95
                    },
                    { 
                        name: '个数标签',
                        pattern: /(?:个数|件数|总数)[：:\s]*(\d+)/gi,
                        priority: 2,
                        confidence: 0.9
                    },
                    { 
                        name: '单位后缀',
                        pattern: /(\d+)\s*(?:个|件|只|支|条|根|张|片)/g,
                        priority: 3,
                        confidence: 0.85
                    },
                    { 
                        name: '数量描述',
                        pattern: /(?:共|总共|合计)\s*(\d+)/gi,
                        priority: 4,
                        confidence: 0.8
                    },
                    { 
                        name: '英文单位',
                        pattern: /(\d+)\s*(?:pcs|pieces|units|items)/gi,
                        priority: 5,
                        confidence: 0.75
                    }
                ];

                // WOXPJ编码模式
                this.woxpjPatterns = [
                    { 
                        name: 'WOXPJ标准格式',
                        pattern: /WOXPJ[：:\s]*(\d+)/gi,
                        priority: 1,
                        confidence: 0.95
                    },
                    { 
                        name: 'WO编码格式',
                        pattern: /WO[：:\s]*(\d+)/gi,
                        priority: 2,
                        confidence: 0.8
                    },
                    { 
                        name: '工单编码',
                        pattern: /(?:工单|工作单)[：:\s]*(\w+\d+)/gi,
                        priority: 3,
                        confidence: 0.75
                    }
                ];

                // 文本预处理规则
                this.preprocessRules = [
                    { from: /：/g, to: ':' },
                    { from: /\s+/g, to: ' ' },
                    { from: /[０-９]/g, to: (match) => String.fromCharCode(match.charCodeAt(0) - 0xFF10 + 0x30) },
                    { from: /[^\w\s\d：:，。、！？（）【】《》""'']/g, to: ' ' }
                ];
            }

            parseText(text, confidence = 0) {
                console.log('开始高级文本解析:', text);
                
                const cleanText = this.preprocessText(text);
                console.log('预处理后文本:', cleanText);

                const results = {
                    productCode: this.extractProductCode(cleanText),
                    quantity: this.extractQuantity(cleanText),
                    woxpjCode: this.extractWoxpjCode(cleanText),
                    confidence: confidence,
                    rawText: text,
                    cleanText: cleanText
                };

                results.overallConfidence = this.calculateOverallConfidence(results);

                console.log('解析结果:', results);
                return results;
            }

            preprocessText(text) {
                let cleanText = text;
                
                for (const rule of this.preprocessRules) {
                    cleanText = cleanText.replace(rule.from, rule.to);
                }
                
                return cleanText.trim();
            }

            extractProductCode(text) {
                const matches = [];
                
                for (const pattern of this.productCodePatterns) {
                    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
                    let match;
                    
                    while ((match = regex.exec(text)) !== null) {
                        const code = match[1];
                        if (this.validateProductCode(code)) {
                            matches.push({
                                code: code,
                                pattern: pattern.name,
                                priority: pattern.priority,
                                confidence: pattern.confidence,
                                position: match.index
                            });
                        }
                    }
                }

                matches.sort((a, b) => {
                    if (a.priority !== b.priority) return a.priority - b.priority;
                    return b.confidence - a.confidence;
                });

                return matches.length > 0 ? matches[0] : null;
            }

            extractQuantity(text) {
                const matches = [];
                
                for (const pattern of this.quantityPatterns) {
                    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
                    let match;
                    
                    while ((match = regex.exec(text)) !== null) {
                        const quantity = parseInt(match[1]);
                        if (this.validateQuantity(quantity)) {
                            matches.push({
                                quantity: quantity,
                                pattern: pattern.name,
                                priority: pattern.priority,
                                confidence: pattern.confidence,
                                position: match.index
                            });
                        }
                    }
                }

                matches.sort((a, b) => {
                    if (a.priority !== b.priority) return a.priority - b.priority;
                    return b.confidence - a.confidence;
                });

                return matches.length > 0 ? matches[0] : null;
            }

            extractWoxpjCode(text) {
                const matches = [];
                
                for (const pattern of this.woxpjPatterns) {
                    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
                    let match;
                    
                    while ((match = regex.exec(text)) !== null) {
                        const code = match[1];
                        matches.push({
                            code: code,
                            pattern: pattern.name,
                            priority: pattern.priority,
                            confidence: pattern.confidence,
                            position: match.index
                        });
                    }
                }

                matches.sort((a, b) => {
                    if (a.priority !== b.priority) return a.priority - b.priority;
                    return b.confidence - a.confidence;
                });

                if (matches.length > 0) {
                    const bestMatch = matches[0];
                    const lastThreeDigits = bestMatch.code.replace(/\D/g, '').slice(-3);
                    return {
                        ...bestMatch,
                        lastThreeDigits: lastThreeDigits
                    };
                }

                return null;
            }

            validateProductCode(code) {
                return /^\d{10}$/.test(code);
            }

            validateQuantity(quantity) {
                return Number.isInteger(quantity) && quantity > 0 && quantity <= 999999;
            }

            calculateOverallConfidence(results) {
                let totalConfidence = results.confidence || 0;
                let factorCount = 1;

                if (results.productCode) {
                    totalConfidence += results.productCode.confidence * 100;
                    factorCount++;
                }

                if (results.quantity) {
                    totalConfidence += results.quantity.confidence * 100;
                    factorCount++;
                }

                if (results.woxpjCode) {
                    totalConfidence += results.woxpjCode.confidence * 100;
                    factorCount++;
                }

                return Math.round(totalConfidence / factorCount);
            }

            getParsingStats(results) {
                return {
                    foundProductCode: !!results.productCode,
                    foundQuantity: !!results.quantity,
                    foundWoxpjCode: !!results.woxpjCode,
                    overallConfidence: results.overallConfidence,
                    textLength: results.rawText.length,
                    cleanTextLength: results.cleanText.length
                };
            }
        }

        // 增强图像预处理器
        class ImageProcessor {
            constructor() {
                this.canvas = document.createElement('canvas');
                this.ctx = this.canvas.getContext('2d');
                this.tempCanvas = document.createElement('canvas');
                this.tempCtx = this.tempCanvas.getContext('2d');
                
                this.processingOptions = {
                    brightness: 1.2,
                    contrast: 1.3,
                    sharpness: 1.1,
                    denoise: true,
                    autoRotate: true,
                    resize: true,
                    maxWidth: 1920,
                    maxHeight: 1080,
                    autoEnhance: true,
                    edgeEnhancement: false,
                    adaptiveContrast: true
                };
                
                // 图像质量分析缓存
                this.qualityCache = new Map();
            }

            async processImage(imageData, options = {}) {
                const settings = { ...this.processingOptions, ...options };
                
                try {
                    let img;
                    if (imageData instanceof File || imageData instanceof Blob) {
                        img = await this._loadImageFromBlob(imageData);
                    } else {
                        img = imageData;
                    }

                    // 分析图像质量和特征
                    const imageAnalysis = await this._analyzeImage(img);
                    console.log('图像分析结果:', imageAnalysis);
                    
                    // 根据分析结果调整处理参数
                    const optimizedSettings = this._optimizeSettings(settings, imageAnalysis);

                    const { width, height } = this._calculateOptimalSize(img.width, img.height, optimizedSettings);
                    this.canvas.width = width;
                    this.canvas.height = height;

                    this.ctx.clearRect(0, 0, width, height);
                    
                    // 自动旋转检测和校正
                    if (optimizedSettings.autoRotate && imageAnalysis.suggestedRotation !== 0) {
                        this._drawRotatedImage(img, width, height, imageAnalysis.suggestedRotation);
                    } else {
                        this.ctx.drawImage(img, 0, 0, width, height);
                    }
                    
                    // 自适应对比度增强
                    if (optimizedSettings.adaptiveContrast && imageAnalysis.needsContrastEnhancement) {
                        this._applyAdaptiveContrast(imageAnalysis);
                    }

                    // 基础亮度对比度调整
                    if (optimizedSettings.brightness !== 1 || optimizedSettings.contrast !== 1) {
                        this._adjustBrightnessContrast(optimizedSettings.brightness, optimizedSettings.contrast);
                    }
                    
                    // 边缘增强（适用于文字识别）
                    if (optimizedSettings.edgeEnhancement || imageAnalysis.hasTextContent) {
                        this._enhanceEdges(optimizedSettings.sharpness);
                    } else if (optimizedSettings.sharpness > 1) {
                        this._applySharpen(optimizedSettings.sharpness);
                    }

                    // 智能降噪
                    if (optimizedSettings.denoise) {
                        this._applySmartDenoise(imageAnalysis.noiseLevel);
                    }
                    
                    // 最终优化
                    if (optimizedSettings.autoEnhance) {
                        this._applyFinalEnhancement(imageAnalysis);
                    }

                    return new Promise((resolve) => {
                        this.canvas.toBlob((blob) => {
                            resolve(blob);
                        }, 'image/jpeg', 0.95);
                    });

                } catch (error) {
                    console.error('图像处理失败:', error);
                    throw new Error('图像处理失败: ' + error.message);
                }
            }

            _loadImageFromBlob(blob) {
                return new Promise((resolve, reject) => {
                    const img = new Image();
                    const url = URL.createObjectURL(blob);
                    
                    img.onload = () => {
                        URL.revokeObjectURL(url);
                        resolve(img);
                    };
                    
                    img.onerror = () => {
                        URL.revokeObjectURL(url);
                        reject(new Error('图像加载失败'));
                    };
                    
                    img.src = url;
                });
            }

            _calculateOptimalSize(originalWidth, originalHeight, settings) {
                let { width, height } = { width: originalWidth, height: originalHeight };

                if (settings.resize) {
                    const maxWidth = settings.maxWidth;
                    const maxHeight = settings.maxHeight;

                    if (width > maxWidth || height > maxHeight) {
                        const ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = Math.round(width * ratio);
                        height = Math.round(height * ratio);
                    }
                }

                return { width, height };
            }

            _adjustBrightnessContrast(brightness, contrast) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;

                for (let i = 0; i < data.length; i += 4) {
                    for (let j = 0; j < 3; j++) {
                        let value = data[i + j];
                        value = ((value / 255 - 0.5) * contrast + 0.5) * 255;
                        value = value * brightness;
                        data[i + j] = Math.max(0, Math.min(255, value));
                    }
                }

                this.ctx.putImageData(imageData, 0, 0);
            }

            _applySharpen(intensity) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;
                
                const kernel = [
                    0, -1 * intensity, 0,
                    -1 * intensity, 1 + 4 * intensity, -1 * intensity,
                    0, -1 * intensity, 0
                ];

                const newData = new Uint8ClampedArray(data);

                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) {
                            let sum = 0;
                            for (let ky = -1; ky <= 1; ky++) {
                                for (let kx = -1; kx <= 1; kx++) {
                                    const idx = ((y + ky) * width + (x + kx)) * 4 + c;
                                    const kernelIdx = (ky + 1) * 3 + (kx + 1);
                                    sum += data[idx] * kernel[kernelIdx];
                                }
                            }
                            const idx = (y * width + x) * 4 + c;
                            newData[idx] = Math.max(0, Math.min(255, sum));
                        }
                    }
                }

                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }

            _applyDenoise() {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;
                
                const newData = new Uint8ClampedArray(data);

                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) {
                            const neighbors = [];
                            
                            for (let dy = -1; dy <= 1; dy++) {
                                for (let dx = -1; dx <= 1; dx++) {
                                    const idx = ((y + dy) * width + (x + dx)) * 4 + c;
                                    neighbors.push(data[idx]);
                                }
                            }
                            
                            neighbors.sort((a, b) => a - b);
                            const median = neighbors[Math.floor(neighbors.length / 2)];
                            
                            const idx = (y * width + x) * 4 + c;
                            newData[idx] = median;
                        }
                    }
                }

                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }

            // 智能图像分析
            async _analyzeImage(img) {
                // 创建临时画布进行分析
                this.tempCanvas.width = Math.min(img.width, 800);
                this.tempCanvas.height = Math.min(img.height, 600);
                this.tempCtx.drawImage(img, 0, 0, this.tempCanvas.width, this.tempCanvas.height);
                
                const imageData = this.tempCtx.getImageData(0, 0, this.tempCanvas.width, this.tempCanvas.height);
                const data = imageData.data;
                
                // 分析图像特征
                const analysis = {
                    brightness: this._calculateBrightness(data),
                    contrast: this._calculateContrast(data),
                    noiseLevel: this._calculateNoiseLevel(data),
                    hasTextContent: this._detectTextContent(data),
                    suggestedRotation: this._detectRotation(data),
                    needsContrastEnhancement: false,
                    sharpness: this._calculateSharpness(data)
                };
                
                // 基于分析结果的建议
                analysis.needsContrastEnhancement = analysis.contrast < 0.3;
                
                return analysis;
            }
            
            // 根据图像分析优化处理参数
            _optimizeSettings(settings, analysis) {
                const optimized = { ...settings };
                
                // 根据亮度调整
                if (analysis.brightness < 0.3) {
                    optimized.brightness = Math.min(optimized.brightness * 1.3, 2.0);
                } else if (analysis.brightness > 0.8) {
                    optimized.brightness = Math.max(optimized.brightness * 0.9, 0.7);
                }
                
                // 根据对比度调整
                if (analysis.contrast < 0.3) {
                    optimized.contrast = Math.min(optimized.contrast * 1.4, 2.5);
                }
                
                // 根据噪声水平调整降噪强度
                if (analysis.noiseLevel > 0.6) {
                    optimized.denoise = true;
                } else if (analysis.noiseLevel < 0.2) {
                    optimized.denoise = false;
                }
                
                // 根据锐度调整锐化参数
                if (analysis.sharpness < 0.4) {
                    optimized.sharpness = Math.min(optimized.sharpness * 1.3, 2.0);
                }
                
                return optimized;
            }
            
            // 计算图像亮度
            _calculateBrightness(data) {
                let sum = 0;
                for (let i = 0; i < data.length; i += 4) {
                    const brightness = (data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114) / 255;
                    sum += brightness;
                }
                return sum / (data.length / 4);
            }
            
            // 计算图像对比度
            _calculateContrast(data) {
                const brightness = this._calculateBrightness(data);
                let variance = 0;
                
                for (let i = 0; i < data.length; i += 4) {
                    const pixelBrightness = (data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114) / 255;
                    variance += Math.pow(pixelBrightness - brightness, 2);
                }
                
                return Math.sqrt(variance / (data.length / 4));
            }
            
            // 计算噪声水平
            _calculateNoiseLevel(data) {
                let noiseSum = 0;
                const width = this.tempCanvas.width;
                const height = this.tempCanvas.height;
                
                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) {
                            const current = data[(y * width + x) * 4 + c];
                            const neighbors = [
                                data[((y-1) * width + x) * 4 + c],
                                data[((y+1) * width + x) * 4 + c],
                                data[(y * width + (x-1)) * 4 + c],
                                data[(y * width + (x+1)) * 4 + c]
                            ];
                            
                            const avgNeighbor = neighbors.reduce((a, b) => a + b) / neighbors.length;
                            noiseSum += Math.abs(current - avgNeighbor);
                        }
                    }
                }
                
                return Math.min(noiseSum / (width * height * 3 * 255), 1);
            }
            
            // 检测文本内容
            _detectTextContent(data) {
                // 简单的边缘检测来判断是否包含文字
                let edgeCount = 0;
                const width = this.tempCanvas.width;
                const height = this.tempCanvas.height;
                
                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        const idx = (y * width + x) * 4;
                        const current = data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114;
                        
                        const right = data[(y * width + x + 1) * 4] * 0.299 + 
                                     data[(y * width + x + 1) * 4 + 1] * 0.587 + 
                                     data[(y * width + x + 1) * 4 + 2] * 0.114;
                        
                        const bottom = data[((y + 1) * width + x) * 4] * 0.299 + 
                                      data[((y + 1) * width + x) * 4 + 1] * 0.587 + 
                                      data[((y + 1) * width + x) * 4 + 2] * 0.114;
                        
                        if (Math.abs(current - right) > 30 || Math.abs(current - bottom) > 30) {
                            edgeCount++;
                        }
                    }
                }
                
                const edgeRatio = edgeCount / (width * height);
                return edgeRatio > 0.1; // 如果边缘比例超过10%，认为包含文字
            }
            
            // 检测建议的旋转角度
            _detectRotation(data) {
                // 简化的旋转检测，实际应用中可以使用更复杂的算法
                // 这里返回0表示不需要旋转
                return 0;
            }
            
            // 计算图像锐度
            _calculateSharpness(data) {
                let sharpnessSum = 0;
                const width = this.tempCanvas.width;
                const height = this.tempCanvas.height;
                
                // 使用拉普拉斯算子计算锐度
                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        const idx = (y * width + x) * 4;
                        const current = data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114;
                        
                        const laplacian = -4 * current +
                            data[((y-1) * width + x) * 4] * 0.299 + data[((y-1) * width + x) * 4 + 1] * 0.587 + data[((y-1) * width + x) * 4 + 2] * 0.114 +
                            data[((y+1) * width + x) * 4] * 0.299 + data[((y+1) * width + x) * 4 + 1] * 0.587 + data[((y+1) * width + x) * 4 + 2] * 0.114 +
                            data[(y * width + (x-1)) * 4] * 0.299 + data[(y * width + (x-1)) * 4 + 1] * 0.587 + data[(y * width + (x-1)) * 4 + 2] * 0.114 +
                            data[(y * width + (x+1)) * 4] * 0.299 + data[(y * width + (x+1)) * 4 + 1] * 0.587 + data[(y * width + (x+1)) * 4 + 2] * 0.114;
                        
                        sharpnessSum += Math.abs(laplacian);
                    }
                }
                
                return Math.min(sharpnessSum / (width * height * 255), 1);
            }
            
            // 绘制旋转后的图像
            _drawRotatedImage(img, width, height, rotation) {
                this.ctx.save();
                this.ctx.translate(width / 2, height / 2);
                this.ctx.rotate(rotation * Math.PI / 180);
                this.ctx.drawImage(img, -width / 2, -height / 2, width, height);
                this.ctx.restore();
            }
            
            // 自适应对比度增强
            _applyAdaptiveContrast(analysis) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                
                // 计算直方图
                const histogram = new Array(256).fill(0);
                for (let i = 0; i < data.length; i += 4) {
                    const gray = Math.round(data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
                    histogram[gray]++;
                }
                
                // 计算累积分布函数
                const cdf = new Array(256);
                cdf[0] = histogram[0];
                for (let i = 1; i < 256; i++) {
                    cdf[i] = cdf[i - 1] + histogram[i];
                }
                
                // 归一化CDF
                const totalPixels = data.length / 4;
                for (let i = 0; i < 256; i++) {
                    cdf[i] = Math.round((cdf[i] / totalPixels) * 255);
                }
                
                // 应用直方图均衡化
                for (let i = 0; i < data.length; i += 4) {
                    for (let j = 0; j < 3; j++) {
                        data[i + j] = cdf[data[i + j]];
                    }
                }
                
                this.ctx.putImageData(imageData, 0, 0);
            }
            
            // 边缘增强
            _enhanceEdges(intensity) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;
                
                // 边缘检测卷积核
                const edgeKernel = [
                    -1, -1, -1,
                    -1,  8, -1,
                    -1, -1, -1
                ];
                
                const newData = new Uint8ClampedArray(data);
                
                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) {
                            let sum = 0;
                            for (let ky = -1; ky <= 1; ky++) {
                                for (let kx = -1; kx <= 1; kx++) {
                                    const idx = ((y + ky) * width + (x + kx)) * 4 + c;
                                    const kernelIdx = (ky + 1) * 3 + (kx + 1);
                                    sum += data[idx] * edgeKernel[kernelIdx];
                                }
                            }
                            
                            const idx = (y * width + x) * 4 + c;
                            const enhanced = data[idx] + sum * intensity * 0.1;
                            newData[idx] = Math.max(0, Math.min(255, enhanced));
                        }
                    }
                }
                
                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }
            
            // 智能降噪
            _applySmartDenoise(noiseLevel) {
                if (noiseLevel < 0.3) {
                    // 低噪声：使用轻微的高斯模糊
                    this._applyGaussianBlur(0.5);
                } else if (noiseLevel < 0.6) {
                    // 中等噪声：使用中值滤波
                    this._applyDenoise();
                } else {
                    // 高噪声：使用双边滤波
                    this._applyBilateralFilter();
                }
            }
            
            // 高斯模糊
            _applyGaussianBlur(radius) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;
                
                // 简化的高斯模糊实现
                const kernel = [1, 2, 1, 2, 4, 2, 1, 2, 1];
                const kernelSum = 16;
                const newData = new Uint8ClampedArray(data);
                
                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) {
                            let sum = 0;
                            for (let ky = -1; ky <= 1; ky++) {
                                for (let kx = -1; kx <= 1; kx++) {
                                    const idx = ((y + ky) * width + (x + kx)) * 4 + c;
                                    const kernelIdx = (ky + 1) * 3 + (kx + 1);
                                    sum += data[idx] * kernel[kernelIdx];
                                }
                            }
                            const idx = (y * width + x) * 4 + c;
                            newData[idx] = sum / kernelSum;
                        }
                    }
                }
                
                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }
            
            // 双边滤波
            _applyBilateralFilter() {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;
                const newData = new Uint8ClampedArray(data);
                
                const spatialSigma = 2;
                const intensitySigma = 20;
                
                for (let y = 2; y < height - 2; y++) {
                    for (let x = 2; x < width - 2; x++) {
                        for (let c = 0; c < 3; c++) {
                            let sum = 0;
                            let weightSum = 0;
                            const centerIdx = (y * width + x) * 4 + c;
                            const centerValue = data[centerIdx];
                            
                            for (let dy = -2; dy <= 2; dy++) {
                                for (let dx = -2; dx <= 2; dx++) {
                                    const neighborIdx = ((y + dy) * width + (x + dx)) * 4 + c;
                                    const neighborValue = data[neighborIdx];
                                    
                                    const spatialWeight = Math.exp(-(dx * dx + dy * dy) / (2 * spatialSigma * spatialSigma));
                                    const intensityWeight = Math.exp(-Math.pow(centerValue - neighborValue, 2) / (2 * intensitySigma * intensitySigma));
                                    const weight = spatialWeight * intensityWeight;
                                    
                                    sum += neighborValue * weight;
                                    weightSum += weight;
                                }
                            }
                            
                            newData[centerIdx] = sum / weightSum;
                        }
                    }
                }
                
                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }
            
            // 最终增强
            _applyFinalEnhancement(analysis) {
                // 根据图像分析结果应用最终的微调
                if (analysis.hasTextContent) {
                    // 对文字内容进行特殊优化
                    this._optimizeForText();
                }
            }
            
            // 文字优化
            _optimizeForText() {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                
                // 增强黑白对比，适合文字识别
                for (let i = 0; i < data.length; i += 4) {
                    const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
                    
                    // 应用阈值处理，增强文字边缘
                    const enhanced = gray > 128 ? Math.min(255, gray * 1.1) : Math.max(0, gray * 0.9);
                    
                    data[i] = enhanced;
                    data[i + 1] = enhanced;
                    data[i + 2] = enhanced;
                }
                
                this.ctx.putImageData(imageData, 0, 0);
            }

            getPreviewDataURL() {
                return this.canvas.toDataURL('image/jpeg', 0.8);
            }

            updateOptions(newOptions) {
                this.processingOptions = { ...this.processingOptions, ...newOptions };
            }

            getOptions() {
                return { ...this.processingOptions };
            }
        }

        // OCR配置选择器
        class OCRConfigSelector {
            constructor() {
                this.configHistory = [];
                this.maxHistorySize = 50;
                this.learningEnabled = true;
            }
            
            // 基于图像特征选择配置
            selectConfigForImage(imageAnalysis) {
                const config = {
                    preset: 'highAccuracy',
                    confidence: 0.5,
                    reasoning: []
                };
                
                // 基于亮度选择
                if (imageAnalysis.brightness < 0.3) {
                    config.preset = 'textOptimized';
                    config.reasoning.push('低亮度图像，使用文本优化模式');
                } else if (imageAnalysis.brightness > 0.8) {
                    config.preset = 'fastMode';
                    config.reasoning.push('高亮度图像，使用快速模式');
                }
                
                // 基于对比度选择
                if (imageAnalysis.contrast < 0.2) {
                    config.preset = 'highAccuracy';
                    config.reasoning.push('低对比度图像，使用高精度模式');
                }
                
                // 基于噪声水平选择
                if (imageAnalysis.noiseLevel > 0.6) {
                    config.preset = 'textOptimized';
                    config.reasoning.push('高噪声图像，使用文本优化模式');
                }
                
                // 基于文本内容检测选择
                if (imageAnalysis.hasTextContent) {
                    if (config.preset === 'fastMode') {
                        config.preset = 'textOptimized';
                        config.reasoning.push('检测到文本内容，切换到文本优化模式');
                    }
                } else {
                    config.preset = 'numberOptimized';
                    config.reasoning.push('未检测到明显文本，使用数字优化模式');
                }
                
                // 计算配置置信度
                config.confidence = this._calculateConfigConfidence(imageAnalysis, config.preset);
                
                return config;
            }
            
            // 计算配置置信度
            _calculateConfigConfidence(imageAnalysis, preset) {
                let confidence = 0.5; // 基础置信度
                
                // 基于图像质量调整置信度
                if (imageAnalysis.brightness > 0.3 && imageAnalysis.brightness < 0.8) {
                    confidence += 0.1;
                }
                
                if (imageAnalysis.contrast > 0.3) {
                    confidence += 0.1;
                }
                
                if (imageAnalysis.noiseLevel < 0.4) {
                    confidence += 0.1;
                }
                
                if (imageAnalysis.sharpness > 0.5) {
                    confidence += 0.1;
                }
                
                // 基于预设类型调整
                switch (preset) {
                    case 'highAccuracy':
                        confidence += 0.1;
                        break;
                    case 'textOptimized':
                        if (imageAnalysis.hasTextContent) confidence += 0.15;
                        break;
                    case 'numberOptimized':
                        if (!imageAnalysis.hasTextContent) confidence += 0.15;
                        break;
                }
                
                return Math.min(1.0, confidence);
            }
            
            // 记录配置使用结果
            recordConfigResult(config, result) {
                if (!this.learningEnabled) return;
                
                const record = {
                    timestamp: Date.now(),
                    config: config,
                    result: {
                        success: result.confidence > 60,
                        confidence: result.confidence,
                        textLength: result.text ? result.text.length : 0,
                        processingTime: result.processingTime || 0
                    }
                };
                
                this.configHistory.push(record);
                
                // 限制历史记录大小
                if (this.configHistory.length > this.maxHistorySize) {
                    this.configHistory.shift();
                }
                
                console.log('配置使用结果已记录:', record);
            }
            
            // 获取配置使用统计
            getConfigStats() {
                const stats = {
                    totalRecords: this.configHistory.length,
                    presetStats: {},
                    averageConfidence: 0,
                    successRate: 0
                };
                
                if (this.configHistory.length === 0) return stats;
                
                // 统计各预设的使用情况
                const presetCounts = {};
                let totalConfidence = 0;
                let successCount = 0;
                
                this.configHistory.forEach(record => {
                    const preset = record.config.preset;
                    
                    if (!presetCounts[preset]) {
                        presetCounts[preset] = {
                            count: 0,
                            successes: 0,
                            totalConfidence: 0,
                            avgProcessingTime: 0
                        };
                    }
                    
                    presetCounts[preset].count++;
                    presetCounts[preset].totalConfidence += record.result.confidence;
                    presetCounts[preset].avgProcessingTime += record.result.processingTime;
                    
                    if (record.result.success) {
                        presetCounts[preset].successes++;
                        successCount++;
                    }
                    
                    totalConfidence += record.result.confidence;
                });
                
                // 计算统计数据
                stats.averageConfidence = totalConfidence / this.configHistory.length;
                stats.successRate = (successCount / this.configHistory.length) * 100;
                
                // 计算各预设的详细统计
                for (const [preset, data] of Object.entries(presetCounts)) {
                    stats.presetStats[preset] = {
                        usage: data.count,
                        successRate: (data.successes / data.count) * 100,
                        avgConfidence: data.totalConfidence / data.count,
                        avgProcessingTime: data.avgProcessingTime / data.count
                    };
                }
                
                return stats;
            }
        }

        // OCR识别引擎
        class OCREngine {
            constructor() {
                this.isProcessing = false;
                this.retryCount = 0;
                this.maxRetries = 2;
                
                // 基础配置
                this.baseOptions = {
                    lang: 'chi_sim+eng',
                    logger: (m) => {
                        if (m.status === 'recognizing text') {
                            const progress = Math.round(m.progress * 100);
                            showStatus(`识别进度: ${progress}%`, 'processing');
                        }
                    }
                };
                
                // 优化的Tesseract基础配置
                this.optimizedConfig = {
                    // 页面分割模式：6 = 单一文本块
                    tessedit_pageseg_mode: '6',
                    // 字符白名单：包含常见的中英文字符和符号
                    tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz：:，。、！？（）【】《》""''物料名称编码数量个件WOXPJ-_/\\',
                    // OCR引擎模式：1 = 神经网络LSTM引擎
                    tessedit_ocr_engine_mode: '1',
                    // 启用系统词典
                    load_system_dawg: '1',
                    load_freq_dawg: '1',
                    // 文本行最小尺寸
                    textord_min_linesize: '2.5',
                    // 保留单词间空格
                    preserve_interword_spaces: '1',
                    // 噪声处理参数
                    textord_noise_sizefraction: '10.0',
                    textord_noise_sizelimit: '0.7',
                    // 字符分类参数
                    classify_enable_learning: '0',
                    classify_enable_adaptive_matcher: '1',
                    // 边缘检测参数
                    edges_use_new_outline_complexity: '1',
                    edges_debug: '0',
                    // 文本方向检测
                    textord_debug_tabfind: '0',
                    textord_use_cjk_fp_model: '1'
                };
                
                // 针对不同场景的优化配置预设
                this.presets = {
                    highAccuracy: {
                        ...this.optimizedConfig,
                        // 高精度模式：单一文本块，启用数字分类
                        tessedit_pageseg_mode: '6',
                        classify_bln_numeric_mode: '1',
                        tessedit_ocr_engine_mode: '1',
                        // 更严格的字符识别
                        classify_enable_adaptive_matcher: '1',
                        textord_noise_sizefraction: '8.0',
                        // 提高识别精度的参数
                        tessedit_reject_mode: '0',
                        tessedit_make_boxes_from_boxes: '1'
                    },
                    fastMode: {
                        ...this.optimizedConfig,
                        // 快速模式：单词级别分割，使用传统引擎
                        tessedit_pageseg_mode: '8',
                        tessedit_ocr_engine_mode: '0',
                        // 降低处理复杂度
                        classify_enable_adaptive_matcher: '0',
                        load_system_dawg: '0',
                        load_freq_dawg: '0',
                        // 放宽噪声容忍度
                        textord_noise_sizefraction: '15.0',
                        textord_noise_sizelimit: '1.0'
                    },
                    numberOptimized: {
                        ...this.optimizedConfig,
                        // 数字优化模式：专门针对数字识别
                        tessedit_char_whitelist: '0123456789WOXPJ-',
                        tessedit_pageseg_mode: '8',
                        classify_bln_numeric_mode: '1',
                        // 数字识别专用参数
                        numeric_punctuation: '1',
                        tessedit_ocr_engine_mode: '1',
                        // 优化数字识别的参数
                        classify_integer_matcher_multiplier: '10',
                        textord_min_linesize: '1.5'
                    },
                    textOptimized: {
                        ...this.optimizedConfig,
                        // 文本优化模式：专门针对中英文混合文本
                        tessedit_pageseg_mode: '6',
                        tessedit_ocr_engine_mode: '1',
                        // 文本识别优化参数
                        textord_use_cjk_fp_model: '1',
                        preserve_interword_spaces: '1',
                        // 中文识别优化
                        language_model_penalty_non_freq_dict_word: '0.1',
                        language_model_penalty_non_dict_word: '0.15'
                    }
                };
                
                this.currentPreset = 'highAccuracy';
                
                // 性能统计
                this.performanceStats = {
                    totalRecognitions: 0,
                    successfulRecognitions: 0,
                    averageConfidence: 0,
                    averageProcessingTime: 0,
                    presetPerformance: {
                        highAccuracy: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 },
                        fastMode: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 },
                        numberOptimized: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 },
                        textOptimized: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 }
                    }
                };
                
                // 动态配置选择器
                this.configSelector = new OCRConfigSelector();
            }

            async recognizeText(imageData, preset = null) {
                if (this.isProcessing) {
                    showStatus('正在处理中，请稍候...', 'warning');
                    return;
                }

                this.isProcessing = true;
                this.retryCount = 0;
                
                return this._recognizeWithRetry(imageData, preset);
            }
            
            async _recognizeWithRetry(imageData, preset = null) {
                const startTime = Date.now();
                let currentPreset = preset || this._selectOptimalPreset(imageData);
                const config = this.presets[currentPreset];
                
                showStatus(`正在预处理图像...`, 'processing');

                try {
                    // 更新统计
                    this.performanceStats.totalRecognitions++;
                    this.performanceStats.presetPerformance[currentPreset].attempts++;
                    
                    // 图像预处理
                    let processedImage = imageData;
                    const processingOptions = this._getProcessingOptions(currentPreset);
                    
                    if (imageData instanceof File || imageData instanceof Blob) {
                        processedImage = await imageProcessor.processImage(imageData, processingOptions);
                        showStatus(`图像预处理完成，开始识别 (${currentPreset}模式)...`, 'processing');
                    } else {
                        showStatus(`正在识别文字 (${currentPreset}模式)...`, 'processing');
                    }

                    const result = await Tesseract.recognize(processedImage, this.baseOptions.lang, {
                        logger: this.baseOptions.logger,
                        ...config
                    });

                    const text = result.data.text.trim();
                    const confidence = result.data.confidence;
                    const processingTime = Date.now() - startTime;
                    
                    console.log(`OCR结果 - 置信度: ${confidence}%, 文本长度: ${text.length}, 处理时间: ${processingTime}ms`);

                    // 评估识别质量
                    const qualityAssessment = this._assessRecognitionQuality(text, confidence, result.data);
                    
                    // 如果质量不佳且还有重试机会，尝试其他模式
                    if (qualityAssessment.needsRetry && this.retryCount < this.maxRetries) {
                        this.retryCount++;
                        const nextPreset = this._selectNextBestPreset(currentPreset, qualityAssessment);
                        showStatus(`识别质量不佳(${confidence}%)，尝试${nextPreset}模式...`, 'processing');
                        return this._recognizeWithRetry(imageData, nextPreset);
                    }

                    if (!text || text.length < 2) {
                        throw new Error('未识别到有效文字，请确保图片清晰且包含文字内容');
                    }

                    // 更新成功统计
                    this._updateSuccessStats(currentPreset, confidence, processingTime);
                    
                    showStatus(`识别完成！置信度: ${confidence}%`, 'success');
                    document.getElementById('ocrResult').style.display = 'block';
                    document.getElementById('ocrResult').textContent = '识别结果：\n' + text;

                    this.parseRecognitionResult(text, confidence);

                    return { text, confidence, preset: currentPreset, processingTime };
                } catch (error) {
                    console.error('OCR Error:', error);
                    
                    if (this.retryCount < this.maxRetries) {
                        this.retryCount++;
                        const nextPreset = this._getNextPreset(currentPreset);
                        showStatus(`识别失败，尝试${nextPreset}模式...`, 'processing');
                        return this._recognizeWithRetry(imageData, nextPreset);
                    }
                    
                    showStatus(`识别失败：${error.message}`, 'error');
                    throw error;
                } finally {
                    this.isProcessing = false;
                }
            }
            
            _getNextPreset(currentPreset) {
                const presetOrder = ['highAccuracy', 'fastMode', 'numberOptimized'];
                const currentIndex = presetOrder.indexOf(currentPreset);
                return presetOrder[(currentIndex + 1) % presetOrder.length];
            }
            
            _getProcessingOptions(preset) {
                const processingPresets = {
                    highAccuracy: {
                        brightness: 1.2,
                        contrast: 1.4,
                        sharpness: 1.2,
                        denoise: true,
                        resize: true,
                        maxWidth: 1920,
                        maxHeight: 1080
                    },
                    fastMode: {
                        brightness: 1.1,
                        contrast: 1.2,
                        sharpness: 1.0,
                        denoise: false,
                        resize: true,
                        maxWidth: 1280,
                        maxHeight: 720
                    },
                    numberOptimized: {
                        brightness: 1.3,
                        contrast: 1.5,
                        sharpness: 1.3,
                        denoise: true,
                        resize: true,
                        maxWidth: 1600,
                        maxHeight: 900
                    }
                };
                
                return processingPresets[preset] || processingPresets.highAccuracy;
            }

            parseRecognitionResult(text, confidence = 0) {
                console.log('开始高级文本解析...');
                
                // 使用高级文本解析器
                const parseResults = textParser.parseText(text, confidence);
                
                // 处理产品编码结果
                if (parseResults.productCode) {
                    const productCode = parseResults.productCode.code;
                    const patternName = parseResults.productCode.pattern;
                    const patternConfidence = Math.round(parseResults.productCode.confidence * 100);
                    
                    // 使用高级验证系统
                    const validation = productCodeValidator.validateProductCode(
                        productCode, 
                        currentProductCode, 
                        patternConfidence, 
                        patternName
                    );
                    
                    // 显示详细的验证结果
                    this.displayValidationResult(validation);
                    
                } else {
                    showMatch('⚠️ 未识别到有效的10位产品编码', 'error');
                    
                    // 记录未识别的情况
                    const validation = productCodeValidator.validateProductCode(
                        null, 
                        currentProductCode, 
                        confidence, 
                        '未识别'
                    );
                }

                // 处理数量结果
                if (parseResults.quantity) {
                    const quantity = parseResults.quantity.quantity;
                    const patternName = parseResults.quantity.pattern;
                    const patternConfidence = Math.round(parseResults.quantity.confidence * 100);
                    
                    // 使用智能表单控制器填充数量
                    const fillResult = formController.fillQuantity(
                        quantity, 
                        patternName, 
                        patternConfidence
                    );
                    
                    if (fillResult.success) {
                        if (fillResult.wasAdjusted) {
                            showStatus(
                                `识别到数量${quantity} (${patternName})，已调整为${fillResult.value}`,
                                'warning'
                            );
                        } else {
                            showStatus(
                                `已自动填充数量：${fillResult.value} (${patternName}, ${patternConfidence}%)`,
                                'success',
                                true
                            );
                        }
                    } else {
                        showStatus(`数量填充失败：${fillResult.reason}`, 'error');
                    }
                }

                // 处理WOXPJ编码结果
                if (parseResults.woxpjCode) {
                    const lastThreeDigits = parseResults.woxpjCode.lastThreeDigits;
                    const patternName = parseResults.woxpjCode.pattern;
                    const patternConfidence = Math.round(parseResults.woxpjCode.confidence * 100);
                    
                    if (lastThreeDigits) {
                        // 使用智能表单控制器填充备注
                        const fillResult = formController.fillRemark(
                            lastThreeDigits, 
                            patternName, 
                            patternConfidence
                        );
                        
                        if (fillResult.success) {
                            showStatus(
                                `已自动填充备注：${fillResult.value} (${patternName}, ${patternConfidence}%)`, 
                                'success', 
                                true
                            );
                        } else {
                            showStatus(`备注填充失败：${fillResult.reason}`, 'error');
                        }
                    }
                }

                // 显示解析统计信息
                const stats = textParser.getParsingStats(parseResults);
                console.log('解析统计:', stats);
                
                // 如果综合置信度较低，给出提示
                if (parseResults.overallConfidence < 70) {
                    showStatus(
                        `识别置信度较低 (${parseResults.overallConfidence}%)，建议检查识别结果`, 
                        'warning'
                    );
                }

                // 记录详细的识别结果
                this._logAdvancedRecognitionResults(parseResults);
                
                return parseResults;
            }
            
            displayValidationResult(validation) {
                const feedback = validation.visualFeedback;
                
                // 构建显示消息
                let message = `${feedback.icon} ${feedback.title}\n${feedback.message}`;
                
                if (feedback.details.length > 0) {
                    message += '\n\n' + feedback.details.join('\n');
                }
                
                // 显示主要反馈
                showMatch(message, feedback.type);
                
                // 显示建议
                if (validation.suggestions.length > 0) {
                    const suggestions = validation.suggestions
                        .map(s => `${this.getSuggestionIcon(s.type)} ${s.message}`)
                        .join('\n');
                    
                    setTimeout(() => {
                        showStatus(`建议：\n${suggestions}`, 'info');
                    }, 1000);
                }
                
                // 记录验证日志
                console.log('产品编码验证结果:', validation);
            }
            
            getSuggestionIcon(type) {
                const icons = {
                    error: '❌',
                    warning: '⚠️',
                    info: 'ℹ️',
                    success: '✅'
                };
                return icons[type] || 'ℹ️';
            }

            _logAdvancedRecognitionResults(results) {
                console.log('高级解析结果汇总:', {
                    产品编码: results.productCode ? {
                        编码: results.productCode.code,
                        模式: results.productCode.pattern,
                        置信度: results.productCode.confidence
                    } : null,
                    数量: results.quantity ? {
                        数量: results.quantity.quantity,
                        模式: results.quantity.pattern,
                        置信度: results.quantity.confidence
                    } : null,
                    WOXPJ编码: results.woxpjCode ? {
                        原始编码: results.woxpjCode.code,
                        后三位: results.woxpjCode.lastThreeDigits,
                        模式: results.woxpjCode.pattern
                    } : null,
                    综合置信度: results.overallConfidence + '%',
                    原始文本长度: results.rawText.length,
                    清理后文本长度: results.cleanText.length
                });
                
                // 显示验证统计
                const stats = productCodeValidator.getValidationStats();
                console.log('验证统计:', stats);
            }
            
            // 手动切换识别模式
            switchPreset(presetName) {
                if (this.presets[presetName]) {
                    this.currentPreset = presetName;
                    showStatus(`已切换到${presetName}模式`, 'success', true);
                }
            }
            
            // 智能选择最优预设
            _selectOptimalPreset(imageData) {
                // 基于历史性能数据选择最佳预设
                const stats = this.performanceStats.presetPerformance;
                let bestPreset = 'highAccuracy';
                let bestScore = 0;
                
                for (const [preset, performance] of Object.entries(stats)) {
                    if (performance.attempts > 0) {
                        // 计算综合评分：成功率 * 平均置信度 / 平均处理时间
                        const successRate = performance.successes / performance.attempts;
                        const avgConfidence = performance.avgConfidence / 100;
                        const timeScore = Math.max(0.1, 1 - (performance.avgTime / 10000)); // 时间越短分数越高
                        
                        const score = successRate * avgConfidence * timeScore;
                        
                        if (score > bestScore) {
                            bestScore = score;
                            bestPreset = preset;
                        }
                    }
                }
                
                console.log(`智能选择预设: ${bestPreset} (评分: ${bestScore.toFixed(3)})`);
                return bestPreset;
            }
            
            // 评估识别质量
            _assessRecognitionQuality(text, confidence, ocrData) {
                const assessment = {
                    needsRetry: false,
                    qualityScore: 0,
                    issues: [],
                    recommendations: []
                };
                
                // 置信度评估
                if (confidence < 50) {
                    assessment.needsRetry = true;
                    assessment.issues.push('置信度过低');
                } else if (confidence < 70) {
                    assessment.issues.push('置信度偏低');
                }
                
                // 文本长度评估
                if (text.length < 3) {
                    assessment.needsRetry = true;
                    assessment.issues.push('识别文本过短');
                } else if (text.length > 100) {
                    assessment.issues.push('识别文本过长，可能包含噪声');
                }
                
                // 字符质量评估
                const validChars = text.match(/[0-9A-Za-z\u4e00-\u9fa5]/g);
                const validRatio = validChars ? validChars.length / text.length : 0;
                
                if (validRatio < 0.6) {
                    assessment.needsRetry = true;
                    assessment.issues.push('有效字符比例过低');
                }
                
                // 产品编码模式检测
                const hasProductCode = /\d{10}/.test(text);
                const hasWOXPJ = /WOXPJ\d{5}/.test(text);
                
                if (!hasProductCode && !hasWOXPJ) {
                    assessment.issues.push('未检测到产品编码模式');
                }
                
                // 计算综合质量评分
                assessment.qualityScore = Math.min(100, 
                    confidence * 0.4 + 
                    validRatio * 30 + 
                    (hasProductCode || hasWOXPJ ? 20 : 0) + 
                    Math.min(20, text.length * 2)
                );
                
                // 生成建议
                if (assessment.qualityScore < 60) {
                    assessment.recommendations.push('建议重新拍照或调整图像质量');
                }
                
                return assessment;
            }
            
            // 选择下一个最佳预设
            _selectNextBestPreset(currentPreset, qualityAssessment) {
                const presetOrder = ['highAccuracy', 'textOptimized', 'numberOptimized', 'fastMode'];
                const currentIndex = presetOrder.indexOf(currentPreset);
                
                // 基于质量评估选择下一个预设
                if (qualityAssessment.issues.includes('置信度过低')) {
                    return 'textOptimized'; // 尝试文本优化模式
                } else if (qualityAssessment.issues.includes('未检测到产品编码模式')) {
                    return 'numberOptimized'; // 尝试数字优化模式
                } else {
                    // 按顺序尝试下一个
                    return presetOrder[(currentIndex + 1) % presetOrder.length];
                }
            }
            
            // 更新成功统计
            _updateSuccessStats(preset, confidence, processingTime) {
                this.performanceStats.successfulRecognitions++;
                
                const presetStats = this.performanceStats.presetPerformance[preset];
                presetStats.successes++;
                
                // 更新平均置信度
                const totalAttempts = presetStats.attempts;
                presetStats.avgConfidence = ((presetStats.avgConfidence * (totalAttempts - 1)) + confidence) / totalAttempts;
                
                // 更新平均处理时间
                presetStats.avgTime = ((presetStats.avgTime * (presetStats.successes - 1)) + processingTime) / presetStats.successes;
                
                // 更新全局统计
                this.performanceStats.averageConfidence = 
                    ((this.performanceStats.averageConfidence * (this.performanceStats.successfulRecognitions - 1)) + confidence) / 
                    this.performanceStats.successfulRecognitions;
                    
                this.performanceStats.averageProcessingTime = 
                    ((this.performanceStats.averageProcessingTime * (this.performanceStats.successfulRecognitions - 1)) + processingTime) / 
                    this.performanceStats.successfulRecognitions;
            }
            
            // 获取性能统计
            getPerformanceStats() {
                const stats = { ...this.performanceStats };
                
                // 计算成功率
                stats.successRate = this.performanceStats.totalRecognitions > 0 ? 
                    (this.performanceStats.successfulRecognitions / this.performanceStats.totalRecognitions * 100).toFixed(1) : 0;
                
                // 计算各预设的成功率
                for (const [preset, performance] of Object.entries(stats.presetPerformance)) {
                    performance.successRate = performance.attempts > 0 ? 
                        (performance.successes / performance.attempts * 100).toFixed(1) : 0;
                }
                
                return stats;
            }
            
            // 重置性能统计
            resetPerformanceStats() {
                this.performanceStats = {
                    totalRecognitions: 0,
                    successfulRecognitions: 0,
                    averageConfidence: 0,
                    averageProcessingTime: 0,
                    presetPerformance: {
                        highAccuracy: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 },
                        fastMode: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 },
                        numberOptimized: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 },
                        textOptimized: { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 }
                    }
                };
                console.log('性能统计已重置');
            }

            // 获取当前配置信息
            getCurrentConfig() {
                return {
                    preset: this.currentPreset,
                    config: this.presets[this.currentPreset],
                    isProcessing: this.isProcessing,
                    performanceStats: this.getPerformanceStats()
                };
            }
        }

        // 初始化组件
        const interactionManager = new InteractionManager();
        interactionManager.initStyles(); // 初始化样式
        const formController = new FormController();
        const productCodeValidator = new ProductCodeValidator();
        const textParser = new TextParser();
        const imageProcessor = new ImageProcessor();
        const ocrEngine = new OCREngine();

        // 照片预览管理器
        class PhotoPreviewManager {
            constructor() {
                this.previewDiv = document.getElementById('photoPreview');
                this.previewImage = document.getElementById('previewImage');
                this.retakeBtn = document.getElementById('retakeBtn');
                this.confirmBtn = document.getElementById('confirmPhotoBtn');
                this.zoomBtn = document.getElementById('zoomBtn');
                this.qualityIndicator = document.getElementById('imageQualityIndicator');
                this.qualityText = document.getElementById('qualityText');
                this.previewTips = document.getElementById('previewTips');
                this.currentBlob = null;
                this.isZoomed = false;
                
                this.initEventListeners();
            }
            
            initEventListeners() {
                // 重新拍照按钮
                this.retakeBtn.addEventListener('click', () => {
                    this.hidePreview();
                    statusManager.clearAll();
                    showStatus('请重新拍照', 'success');
                });
                
                // 确认照片按钮
                this.confirmBtn.addEventListener('click', () => {
                    if (this.currentBlob) {
                        this.hidePreview();
                        showStatus('开始识别照片...', 'processing');
                        ocrEngine.recognizeText(this.currentBlob);
                    }
                });
                
                // 图片点击放大功能
                this.previewImage.addEventListener('click', () => {
                    this.toggleZoom();
                });
                
                // 缩放按钮
                if (this.zoomBtn) {
                    this.zoomBtn.addEventListener('click', () => {
                        this.toggleZoom();
                    });
                }
            }
            
            async showPreview(blob) {
                this.currentBlob = blob;
                
                // 创建预览图片URL
                const imageUrl = URL.createObjectURL(blob);
                this.previewImage.src = imageUrl;
                
                // 显示预览界面
                this.previewDiv.style.display = 'flex';
                
                // 隐藏拍照按钮
                document.getElementById('captureBtn').style.display = 'none';
                
                // 开始图片质量检测
                this.checkImageQuality(blob);
                
                // 清理之前的URL
                this.previewImage.onload = () => {
                    URL.revokeObjectURL(imageUrl);
                    this.updatePreviewTips();
                };
            }
            
            hidePreview() {
                this.previewDiv.style.display = 'none';
                document.getElementById('captureBtn').style.display = 'block';
                if (this.qualityIndicator) {
                    this.qualityIndicator.style.display = 'none';
                }
                this.isZoomed = false;
                this.previewImage.style.transform = '';
                this.previewImage.style.maxWidth = '90%';
                this.previewImage.style.maxHeight = '65%';
                this.currentBlob = null;
                
                // 清理图片源
                if (this.previewImage.src) {
                    URL.revokeObjectURL(this.previewImage.src);
                    this.previewImage.src = '';
                }
            }
            
            toggleZoom() {
                this.isZoomed = !this.isZoomed;
                
                if (this.isZoomed) {
                    this.previewImage.style.maxWidth = '100%';
                    this.previewImage.style.maxHeight = '100%';
                    this.previewImage.style.transform = 'scale(1.2)';
                    if (this.zoomBtn) this.zoomBtn.innerHTML = '🔍 缩小';
                    if (this.previewTips) this.previewTips.textContent = '再次点击图片缩小';
                } else {
                    this.previewImage.style.maxWidth = '90%';
                    this.previewImage.style.maxHeight = '65%';
                    this.previewImage.style.transform = '';
                    if (this.zoomBtn) this.zoomBtn.innerHTML = '🔍 查看原图';
                    if (this.previewTips) this.previewTips.textContent = '点击图片可查看原始大小';
                }
            }
            
            async checkImageQuality(blob) {
                if (!this.qualityIndicator || !this.qualityText) return;
                
                try {
                    this.qualityIndicator.style.display = 'block';
                    this.qualityText.textContent = '检测中...';
                    
                    // 创建图片对象进行分析
                    const img = new Image();
                    const imageUrl = URL.createObjectURL(blob);
                    
                    img.onload = () => {
                        const quality = this.analyzeImageQuality(img, blob.size);
                        this.displayQualityResult(quality);
                        URL.revokeObjectURL(imageUrl);
                    };
                    
                    img.src = imageUrl;
                } catch (error) {
                    console.error('图片质量检测失败:', error);
                    this.qualityIndicator.style.display = 'none';
                }
            }
            
            analyzeImageQuality(img, fileSize) {
                const width = img.naturalWidth;
                const height = img.naturalHeight;
                const resolution = width * height;
                const fileSizeKB = fileSize / 1024;
                
                let score = 0;
                let issues = [];
                
                // 分辨率检查
                if (resolution >= 1000000) {
                    score += 40;
                } else if (resolution >= 500000) {
                    score += 25;
                } else {
                    score += 10;
                    issues.push('分辨率较低');
                }
                
                // 文件大小检查
                const compressionRatio = fileSizeKB / (resolution / 1000);
                if (compressionRatio > 100) {
                    score += 30;
                } else if (compressionRatio > 50) {
                    score += 20;
                } else {
                    score += 10;
                    issues.push('压缩过度');
                }
                
                // 宽高比检查
                const aspectRatio = width / height;
                if (aspectRatio > 0.5 && aspectRatio < 2) {
                    score += 20;
                } else {
                    score += 10;
                    issues.push('宽高比异常');
                }
                
                // 最小尺寸检查
                if (width >= 800 && height >= 600) {
                    score += 10;
                } else {
                    issues.push('图片尺寸偏小');
                }
                
                return {
                    score: Math.min(score, 100),
                    issues: issues,
                    resolution: `${width}×${height}`,
                    fileSize: `${fileSizeKB.toFixed(1)}KB`
                };
            }
            
            displayQualityResult(quality) {
                if (!this.qualityIndicator || !this.qualityText || !this.previewTips) return;
                
                let qualityClass = '';
                let qualityLabel = '';
                let recommendation = '';
                
                if (quality.score >= 80) {
                    qualityClass = 'quality-excellent';
                    qualityLabel = '优秀';
                    recommendation = '图片质量很好，适合OCR识别';
                } else if (quality.score >= 60) {
                    qualityClass = 'quality-good';
                    qualityLabel = '良好';
                    recommendation = '图片质量可以，建议确认后识别';
                } else {
                    qualityClass = 'quality-poor';
                    qualityLabel = '较差';
                    recommendation = '建议重新拍照以获得更好效果';
                }
                
                this.qualityIndicator.className = `image-quality-indicator ${qualityClass}`;
                this.qualityText.innerHTML = `
                    <div><strong>${qualityLabel}</strong> (${quality.score}分)</div>
                    <div style="font-size: 10px; margin-top: 2px;">
                        ${quality.resolution} • ${quality.fileSize}
                    </div>
                `;
                
                // 更新预览提示
                if (quality.score < 60) {
                    this.previewTips.innerHTML = `
                        <div style="color: #e17055;">⚠️ ${recommendation}</div>
                        <div style="font-size: 11px; margin-top: 2px;">
                            问题: ${quality.issues.join(', ')}
                        </div>
                    `;
                } else {
                    this.previewTips.innerHTML = `
                        <div style="color: #00b894;">✅ ${recommendation}</div>
                        <div style="font-size: 11px; margin-top: 2px;">
                            点击图片放大查看
                        </div>
                    `;
                }
            }
            
            updatePreviewTips() {
                if (!this.previewTips) return;
                if (!this.previewTips.innerHTML.includes('⚠️') && !this.previewTips.innerHTML.includes('✅')) {
                    this.previewTips.innerHTML = `
                        <div>点击图片可查看原始大小</div>
                        <div style="font-size: 11px; margin-top: 2px;">
                            ESC键取消，Enter键确认
                        </div>
                    `;
                }
            }
        }
        
        // 初始化预览管理器
        const photoPreviewManager = new PhotoPreviewManager();
        
        // 显示照片预览的便捷函数
        function showPhotoPreview(blob) {
            photoPreviewManager.showPreview(blob);
        }
        // 状态管理器
        class StatusManager {
            constructor() {
                this.statusDiv = document.getElementById('statusInfo');
                this.matchDiv = document.getElementById('matchResult');
                this.resultDiv = document.getElementById('ocrResult');
            }

            showStatus(message, type, autoHide = false) {
                this.statusDiv.style.display = 'block';
                this.statusDiv.textContent = message;
                this.statusDiv.className = `status-info status-${type}`;
                
                const icons = {
                    processing: '⏳',
                    success: '✅',
                    error: '❌',
                    warning: '⚠️'
                };
                
                if (icons[type]) {
                    this.statusDiv.textContent = `${icons[type]} ${message}`;
                }
                
                if (autoHide && type === 'success') {
                    setTimeout(() => {
                        this.statusDiv.style.display = 'none';
                    }, 3000);
                }
            }

            showMatch(message, type) {
                this.matchDiv.style.display = 'block';
                this.matchDiv.textContent = message;
                this.matchDiv.className = `match-result match-${type}`;
            }

            clearAll() {
                this.statusDiv.style.display = 'none';
                this.matchDiv.style.display = 'none';
                this.resultDiv.style.display = 'none';
            }
        }

        // 初始化状态管理器
        const statusManager = new StatusManager();

        // 兼容性函数
        function showStatus(message, type, autoHide = false) {
            statusManager.showStatus(message, type, autoHide);
        }

        function showMatch(message, type) {
            statusManager.showMatch(message, type);
        }
        
        // 页面加载完成后的初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 检查相机支持
            if (!cameraController.isSupported()) {
                document.getElementById('startCamera').style.display = 'none';
                document.getElementById('captureBtn').style.display = 'none';
                showStatus('您的浏览器不支持相机功能，请使用图片上传功能', 'warning');
            }
            
            // 自动设置备注为产品编码后3位
            const productCode = currentProductCode;
            if (productCode.length >= 3) {
                document.getElementById('remarkInput').value = productCode.slice(-3);
            }
            
            // OCR配置面板事件处理
            document.querySelectorAll('input[name="ocrPreset"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.checked) {
                        ocrEngine.switchPreset(this.value);
                    }
                });
            });
            
            // 图像预处理配置事件处理
            const brightnessSlider = document.getElementById('brightnessSlider');
            const contrastSlider = document.getElementById('contrastSlider');
            const sharpnessSlider = document.getElementById('sharpnessSlider');
            const denoiseSwitch = document.getElementById('denoiseSwitch');
            
            const brightnessValue = document.getElementById('brightnessValue');
            const contrastValue = document.getElementById('contrastValue');
            const sharpnessValue = document.getElementById('sharpnessValue');
            
            // 滑块事件处理
            brightnessSlider.addEventListener('input', function() {
                brightnessValue.textContent = this.value;
                updateImageProcessingOptions();
            });
            
            contrastSlider.addEventListener('input', function() {
                contrastValue.textContent = this.value;
                updateImageProcessingOptions();
            });
            
            sharpnessSlider.addEventListener('input', function() {
                sharpnessValue.textContent = this.value;
                updateImageProcessingOptions();
            });
            
            denoiseSwitch.addEventListener('change', function() {
                updateImageProcessingOptions();
            });
            
            // 新增控制选项的事件处理
            const autoEnhanceSwitch = document.getElementById('autoEnhanceSwitch');
            const adaptiveContrastSwitch = document.getElementById('adaptiveContrastSwitch');
            const edgeEnhancementSwitch = document.getElementById('edgeEnhancementSwitch');
            const autoRotateSwitch = document.getElementById('autoRotateSwitch');
            
            if (autoEnhanceSwitch) autoEnhanceSwitch.addEventListener('change', updateImageProcessingOptions);
            if (adaptiveContrastSwitch) adaptiveContrastSwitch.addEventListener('change', updateImageProcessingOptions);
            if (edgeEnhancementSwitch) edgeEnhancementSwitch.addEventListener('change', updateImageProcessingOptions);
            if (autoRotateSwitch) autoRotateSwitch.addEventListener('change', updateImageProcessingOptions);
            
            // 更新图像处理选项
            function updateImageProcessingOptions() {
                const options = {
                    brightness: parseFloat(brightnessSlider.value),
                    contrast: parseFloat(contrastSlider.value),
                    sharpness: parseFloat(sharpnessSlider.value),
                    denoise: denoiseSwitch.checked,
                    autoEnhance: autoEnhanceSwitch ? autoEnhanceSwitch.checked : true,
                    adaptiveContrast: adaptiveContrastSwitch ? adaptiveContrastSwitch.checked : true,
                    edgeEnhancement: edgeEnhancementSwitch ? edgeEnhancementSwitch.checked : false,
                    autoRotate: autoRotateSwitch ? autoRotateSwitch.checked : true
                };
                imageProcessor.updateOptions(options);
                
                // 显示当前配置状态
                console.log('图像处理选项已更新:', options);
            }
            
            // 重置按钮
            document.getElementById('resetProcessing').addEventListener('click', function() {
                brightnessSlider.value = 1.2;
                contrastSlider.value = 1.3;
                sharpnessSlider.value = 1.1;
                denoiseSwitch.checked = true;
                
                if (autoEnhanceSwitch) autoEnhanceSwitch.checked = true;
                if (adaptiveContrastSwitch) adaptiveContrastSwitch.checked = true;
                if (edgeEnhancementSwitch) edgeEnhancementSwitch.checked = false;
                if (autoRotateSwitch) autoRotateSwitch.checked = true;
                
                brightnessValue.textContent = '1.2';
                contrastValue.textContent = '1.3';
                sharpnessValue.textContent = '1.1';
                
                updateImageProcessingOptions();
                showStatus('已重置为默认预处理参数', 'success', true);
            });
            
            // 预览效果按钮
            document.getElementById('previewProcessing').addEventListener('click', function() {
                if (photoPreviewManager.currentBlob) {
                    showStatus('正在生成预处理预览...', 'processing');
                    
                    imageProcessor.processImage(photoPreviewManager.currentBlob)
                        .then(processedBlob => {
                            const previewUrl = URL.createObjectURL(processedBlob);
                            const previewWindow = window.open('', '_blank', 'width=600,height=400');
                            previewWindow.document.write(`
                                <html>
                                    <head><title>图像预处理预览</title></head>
                                    <body style="margin:0;display:flex;justify-content:center;align-items:center;background:#000;">
                                        <img src="${previewUrl}" style="max-width:100%;max-height:100%;" />
                                    </body>
                                </html>
                            `);
                            showStatus('预处理预览已打开', 'success', true);
                        })
                        .catch(error => {
                            showStatus('预览生成失败：' + error.message, 'error');
                        });
                } else {
                    showStatus('请先拍照后再预览处理效果', 'warning');
                }
            });
            
            // 验证统计相关事件处理
            document.getElementById('clearValidationHistory').addEventListener('click', function() {
                productCodeValidator.clearHistory();
                updateValidationStats();
                showStatus('验证历史已清除', 'success', true);
            });
            
            document.getElementById('showValidationDetails').addEventListener('click', function() {
                const stats = productCodeValidator.getValidationStats();
                
                if (stats.totalValidations === 0) {
                    showStatus('暂无验证记录', 'info');
                    return;
                }
                
                let details = `验证详情：\n`;
                details += `总次数：${stats.totalValidations}\n`;
                details += `成功率：${stats.successRate}%\n`;
                details += `平均置信度：${stats.averageConfidence}%\n\n`;
                
                if (stats.recentValidations.length > 0) {
                    details += `最近验证记录：\n`;
                    stats.recentValidations.forEach((v, i) => {
                        const time = new Date(v.timestamp).toLocaleTimeString();
                        details += `${i + 1}. ${time} - ${v.matchType} (${v.matchScore}分)\n`;
                    });
                }
                
                const detailWindow = window.open('', '_blank', 'width=500,height=400');
                detailWindow.document.write(`
                    <html>
                        <head><title>验证统计详情</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${details}
                        </body>
                    </html>
                `);
            });
            
            // 更新验证统计显示
            function updateValidationStats() {
                const stats = productCodeValidator.getValidationStats();
                document.getElementById('totalValidations').textContent = stats.totalValidations;
                document.getElementById('successRate').textContent = stats.successRate;
                document.getElementById('averageConfidence').textContent = stats.averageConfidence;
            }
            
            // OCR性能统计相关事件处理
            document.getElementById('resetOcrStats').addEventListener('click', function() {
                ocrEngine.resetPerformanceStats();
                updateOcrPerformanceStats();
                showStatus('OCR性能统计已重置', 'success', true);
            });
            
            document.getElementById('showOcrDetails').addEventListener('click', function() {
                const stats = ocrEngine.getPerformanceStats();
                
                if (stats.totalRecognitions === 0) {
                    showStatus('暂无识别记录', 'info');
                    return;
                }
                
                let details = `OCR性能详情：\n`;
                details += `总识别次数：${stats.totalRecognitions}\n`;
                details += `成功次数：${stats.successfulRecognitions}\n`;
                details += `成功率：${stats.successRate}%\n`;
                details += `平均置信度：${stats.averageConfidence.toFixed(1)}%\n`;
                details += `平均处理时间：${stats.averageProcessingTime.toFixed(0)}ms\n\n`;
                
                details += `各预设性能：\n`;
                for (const [preset, performance] of Object.entries(stats.presetPerformance)) {
                    if (performance.attempts > 0) {
                        details += `${preset}：\n`;
                        details += `  尝试次数：${performance.attempts}\n`;
                        details += `  成功次数：${performance.successes}\n`;
                        details += `  成功率：${performance.successRate}%\n`;
                        details += `  平均置信度：${performance.avgConfidence.toFixed(1)}%\n`;
                        details += `  平均处理时间：${performance.avgTime.toFixed(0)}ms\n\n`;
                    }
                }
                
                const detailWindow = window.open('', '_blank', 'width=600,height=500');
                detailWindow.document.write(`
                    <html>
                        <head><title>OCR性能统计详情</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${details}
                        </body>
                    </html>
                `);
            });
            
            // 更新OCR性能统计显示
            function updateOcrPerformanceStats() {
                const stats = ocrEngine.getPerformanceStats();
                document.getElementById('totalRecognitions').textContent = stats.totalRecognitions;
                document.getElementById('ocrSuccessRate').textContent = stats.successRate;
                document.getElementById('ocrAverageConfidence').textContent = stats.averageConfidence.toFixed(1);
                document.getElementById('averageProcessingTime').textContent = stats.averageProcessingTime.toFixed(0);
                
                // 找出最佳预设
                let bestPreset = '-';
                let bestScore = 0;
                for (const [preset, performance] of Object.entries(stats.presetPerformance)) {
                    if (performance.attempts > 0) {
                        const score = (performance.successes / performance.attempts) * (performance.avgConfidence / 100);
                        if (score > bestScore) {
                            bestScore = score;
                            bestPreset = preset;
                        }
                    }
                }
                document.getElementById('bestPreset').textContent = bestPreset;
            }
            
            // 定期更新统计显示
            setInterval(() => {
                updateValidationStats();
                updateOcrPerformanceStats();
            }, 2000);
            
            // 表单控制相关事件处理
            document.getElementById('enableQuantityFill').addEventListener('change', function() {
                formController.updateSettings({ enableQuantityFill: this.checked });
                showStatus(`数量自动填充已${this.checked ? '启用' : '禁用'}`, 'info', true);
            });
            
            document.getElementById('enableRemarkFill').addEventListener('change', function() {
                formController.updateSettings({ enableRemarkFill: this.checked });
                showStatus(`备注自动填充已${this.checked ? '启用' : '禁用'}`, 'info', true);
            });
            
            document.getElementById('showFillAnimation').addEventListener('change', function() {
                formController.updateSettings({ showFillAnimation: this.checked });
                showStatus(`填充动画已${this.checked ? '启用' : '禁用'}`, 'info', true);
            });
            
            document.getElementById('resetForm').addEventListener('click', function() {
                if (confirm('确定要重置表单吗？这将清除所有已填写的内容。')) {
                    formController.resetForm();
                }
            });
            
            document.getElementById('showFillHistory').addEventListener('click', function() {
                formController.showFillHistory();
            });
            
            // 添加键盘快捷键支持
            document.addEventListener('keydown', function(e) {
                // 按空格键拍照（仅在相机激活时且没有预览时）
                if (e.code === 'Space' && cameraController.isActive && photoPreviewManager.previewDiv.style.display !== 'flex') {
                    e.preventDefault();
                    document.getElementById('captureBtn').click();
                }
                
                // 按Escape键关闭相机或隐藏预览
                if (e.code === 'Escape') {
                    if (photoPreviewManager.previewDiv.style.display === 'flex') {
                        photoPreviewManager.hidePreview();
                    } else if (cameraController.isActive) {
                        document.getElementById('startCamera').click();
                    }
                }
                
                // 按Enter键确认照片（在预览模式下）
                if (e.code === 'Enter' && photoPreviewManager.previewDiv.style.display === 'flex') {
                    e.preventDefault();
                    document.getElementById('confirmPhotoBtn').click();
                }
                
                // 按Z键放大/缩小预览图片（在预览模式下）
                if (e.code === 'KeyZ' && photoPreviewManager.previewDiv.style.display === 'flex') {
                    e.preventDefault();
                    photoPreviewManager.toggleZoom();
                }
            });
            
            // 添加拍照按钮的触摸反馈
            const captureBtn = document.getElementById('captureBtn');
            let touchStartTime = 0;
            
            captureBtn.addEventListener('touchstart', function(e) {
                touchStartTime = Date.now();
                this.style.transform = 'translateX(-50%) scale(0.9)';
            });
            
            captureBtn.addEventListener('touchend', function(e) {
                this.style.transform = 'translateX(-50%) scale(1)';
                const touchDuration = Date.now() - touchStartTime;
                
                // 长按超过500ms显示提示
                if (touchDuration > 500) {
                    showStatus('💡 提示：短按拍照，长按可查看更多选项', 'success', true);
                }
            });
        });
    </script>
</body>
</html>