<?php
/**
 * 创建网站设置表
 */

require_once 'config.php';

try {
    $pdo->beginTransaction();
    
    echo "<h2>创建网站设置表...</h2>";
    echo "<pre>";
    
    // 创建网站设置表
    echo "正在创建 site_settings 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `site_settings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
            `setting_value` text COLLATE utf8mb4_unicode_ci,
            `setting_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'text, image, textarea',
            `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `setting_key` (`setting_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ site_settings 表创建成功\n\n";
    
    // 插入默认设置
    echo "正在插入默认设置...\n";
    $default_settings = [
        ['site_name', '仓库管理系统', 'text', '网站名称'],
        ['site_keywords', '仓库管理,出库管理,入库管理,库存管理', 'text', '网站关键字'],
        ['site_description', '专业的仓库管理系统', 'text', '网站描述'],
        ['site_logo', '', 'image', '网站Logo（头部）'],
        ['footer_logo', '', 'image', '底部Logo'],
        ['footer_text', '© 2025 仓库管理系统 版权所有', 'text', '底部版权文字'],
        ['head_seo', '', 'textarea', '头部SEO代码（如统计代码、广告代码等）'],
        ['footer_seo', '', 'textarea', '底部SEO代码'],
        ['contact_phone', '', 'text', '联系电话'],
        ['contact_email', '', 'text', '联系邮箱'],
        ['contact_address', '', 'text', '联系地址'],
    ];
    
    foreach ($default_settings as $setting) {
        $stmt = $pdo->prepare("
            INSERT INTO site_settings (setting_key, setting_value, setting_type, description) 
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE description = VALUES(description)
        ");
        $stmt->execute($setting);
    }
    echo "✓ 默认设置插入成功\n\n";
    
    $pdo->commit();
    
    echo "</pre>";
    echo "<h3 style='color: green;'>✓ 网站设置表创建成功！</h3>";
    echo "<p><a href='admin_dashboard.php?page=settings' class='btn btn-primary'>进入网站设置</a></p>";
    echo "<p><a href='index.php' class='btn btn-secondary'>返回主页</a></p>";
    
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "</pre>";
    echo "<h3 style='color: red;'>✗ 创建表失败</h3>";
    echo "<p style='color: red;'>错误信息：" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><a href='index.php'>返回主页</a></p>";
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>创建网站设置表</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- PHP输出内容会显示在这里 -->
    </div>
</body>
</html>



