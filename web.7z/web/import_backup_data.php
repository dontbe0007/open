<?php
/**
 * 导入备份数据脚本
 * 用于服务器迁移时导入SQL备份文件中的数据
 * 
 * 注意：此脚本会导入数据，但不会删除现有数据
 * 如果表已存在数据，可能会产生重复或冲突
 */

// 开启错误报告（开发环境）
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once 'config.php';

$error = '';
$success = '';
$backup_dir = 'backups';

// 获取备份文件列表
$backup_files = array();
if (file_exists($backup_dir)) {
    $files = glob($backup_dir . '/*.sql');
    foreach ($files as $file) {
        $backup_files[] = array(
            'name' => basename($file),
            'path' => $file,
            'size' => filesize($file),
            'date' => date('Y-m-d H:i:s', filemtime($file))
        );
    }
    // 按日期降序排序
    usort($backup_files, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
}

// 处理导入请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['import'])) {
    $backup_file = $_POST['backup_file'] ?? '';
    $clear_existing = isset($_POST['clear_existing']) && $_POST['clear_existing'] == '1';
    
    if (empty($backup_file)) {
        $error = '请选择要导入的备份文件';
    } else {
        $file_path = $backup_dir . '/' . basename($backup_file);
        
        if (!file_exists($file_path)) {
            $error = '备份文件不存在：' . htmlspecialchars($file_path);
        } else {
            try {
                // 增加内存限制和执行时间限制
                ini_set('memory_limit', '512M');
                set_time_limit(600); // 10分钟
                
                // 检查文件大小
                $file_size = filesize($file_path);
                if ($file_size > 100 * 1024 * 1024) { // 100MB
                    throw new Exception('备份文件过大（超过100MB），请使用命令行工具导入');
                }
                
                // 如果选择清空现有数据，先删除所有数据
                if ($clear_existing) {
                    try {
                        $pdo->beginTransaction();
                        
                        // 按顺序删除数据（考虑外键约束）
                        $tables = ['outbound_records', 'inbound_records', 'shift_records', 'production_plans', 'inventory', 'users'];
                        
                        // 临时禁用外键检查
                        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
                        
                        foreach ($tables as $table) {
                            try {
                                $pdo->exec("TRUNCATE TABLE `$table`");
                            } catch (PDOException $e) {
                                // 如果表不存在或为空，忽略错误
                            }
                        }
                        
                        // 重新启用外键检查
                        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
                        
                        $pdo->commit();
                    } catch (PDOException $e) {
                        if ($pdo->inTransaction()) {
                            $pdo->rollBack();
                        }
                        throw new Exception('清空数据失败：' . $e->getMessage());
                    }
                }
                
                // 使用逐行读取方式处理大型文件
                $handle = fopen($file_path, 'r');
                if ($handle === false) {
                    throw new Exception('无法打开备份文件');
                }
                
                // 开始导入事务
                $pdo->beginTransaction();
                
                // 临时禁用外键检查（导入时可能需要）
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
                
                $imported_count = 0;
                $error_count = 0;
                $errors = array();
                $current_statement = '';
                $in_insert = false;
                $line_number = 0;
                
                // 逐行读取文件
                while (($line = fgets($handle)) !== false) {
                    $line_number++;
                    $original_line = $line;
                    $line = trim($line);
                    
                    // 跳过空行和注释
                    if (empty($line) || preg_match('/^--/', $line) || preg_match('/^\/\*/', $line)) {
                        continue;
                    }
                    
                    // 跳过CREATE TABLE语句
                    if (preg_match('/^CREATE\s+TABLE/i', $line)) {
                        // 跳过整个CREATE TABLE块
                        while (($line = fgets($handle)) !== false) {
                            $line_number++;
                            if (preg_match('/\);$/', trim($line))) {
                                break;
                            }
                        }
                        continue;
                    }
                    
                    // 检测INSERT语句
                    if (preg_match('/^INSERT\s+INTO\s+(\w+)\s+VALUES\s*\((.*)\);?$/is', $line, $matches)) {
                        // 完整的单行INSERT语句
                        try {
                            $table_name = $matches[1];
                            $values = $matches[2];
                            
                            // 解析VALUES部分
                            if (preg_match('/^INSERT\s+INTO\s+(\w+)\s+VALUES\s*\((.*)\);?$/is', $line, $full_match)) {
                                $sql = trim($line);
                                // 确保以分号结尾
                                if (!preg_match('/;$/', $sql)) {
                                    $sql .= ';';
                                }
                                
                                // 执行INSERT语句
                                $pdo->exec($sql);
                                $imported_count++;
                            }
                        } catch (PDOException $e) {
                            $error_count++;
                            // 记录错误，包括行号和部分SQL
                            if ($error_count <= 10) {
                                $error_msg = "行 {$line_number}: " . substr($e->getMessage(), 0, 150);
                                $error_msg .= " | SQL: " . substr($line, 0, 100);
                                $errors[] = $error_msg;
                            }
                        }
                    } elseif (preg_match('/^INSERT\s+INTO/i', $line)) {
                        // 多行INSERT语句开始
                        $in_insert = true;
                        $current_statement = $line;
                    } elseif ($in_insert) {
                        // 继续拼接多行INSERT语句
                        $current_statement .= ' ' . trim($line);
                        
                        // 检测语句结束（分号）
                        if (preg_match('/;$/', $line)) {
                            try {
                                $sql = trim($current_statement);
                                // 确保以分号结尾
                                if (!preg_match('/;$/', $sql)) {
                                    $sql .= ';';
                                }
                                
                                // 执行INSERT语句
                                $pdo->exec($sql);
                                $imported_count++;
                            } catch (PDOException $e) {
                                $error_count++;
                                // 记录错误
                                if ($error_count <= 10) {
                                    $error_msg = "行 {$line_number}: " . substr($e->getMessage(), 0, 150);
                                    $error_msg .= " | SQL: " . substr($current_statement, 0, 100);
                                    $errors[] = $error_msg;
                                }
                            }
                            
                            $current_statement = '';
                            $in_insert = false;
                        }
                    }
                }
                
                // 处理文件末尾未完成的语句
                if ($in_insert && !empty($current_statement)) {
                    try {
                        $sql = trim($current_statement);
                        if (!preg_match('/;$/', $sql)) {
                            $sql .= ';';
                        }
                        $pdo->exec($sql);
                        $imported_count++;
                    } catch (PDOException $e) {
                        $error_count++;
                        if ($error_count <= 10) {
                            $errors[] = "文件末尾: " . substr($e->getMessage(), 0, 150);
                        }
                    }
                }
                
                fclose($handle);
                
                // 重新启用外键检查
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
                
                $pdo->commit();
                
                $success = "数据导入成功！<br>";
                $success .= "成功导入 " . number_format($imported_count) . " 条记录";
                if ($error_count > 0) {
                    $success .= "<br>有 " . number_format($error_count) . " 条记录导入失败";
                    if (!empty($errors)) {
                        $success .= "<br><small style='color: #666;'>部分错误：" . implode('<br>', array_slice($errors, 0, 5)) . "</small>";
                    }
                }
                
            } catch (Exception $e) {
                if (isset($handle) && is_resource($handle)) {
                    fclose($handle);
                }
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                // 重新启用外键检查（如果之前禁用了）
                try {
                    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
                } catch (PDOException $e2) {
                    // 忽略
                }
                $error = '导入失败：' . htmlspecialchars($e->getMessage());
            } catch (PDOException $e) {
                if (isset($handle) && is_resource($handle)) {
                    fclose($handle);
                }
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                // 重新启用外键检查（如果之前禁用了）
                try {
                    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
                } catch (PDOException $e2) {
                    // 忽略
                }
                $error = '数据库错误：' . htmlspecialchars($e->getMessage());
            }
        }
    }
}

// 格式化文件大小
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' B';
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>导入备份数据</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 5px;
        }
        .file-list {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            background: #f8f9fa;
        }
        .file-item {
            padding: 10px;
            margin-bottom: 10px;
            background: white;
            border-radius: 5px;
            border: 1px solid #dee2e6;
            cursor: pointer;
            transition: all 0.3s;
        }
        .file-item:hover {
            background: #e9ecef;
            border-color: #007bff;
        }
        .file-item.selected {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }
        .file-item input[type="radio"] {
            margin-right: 10px;
        }
        .file-info {
            font-size: 0.9em;
            color: #666;
            margin-top: 5px;
        }
        .file-item.selected .file-info {
            color: rgba(255,255,255,0.9);
        }
        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 5px;
            padding: 15px;
            margin: 20px 0;
        }
        .warning-box h5 {
            color: #856404;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">导入备份数据</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="warning-box">
            <h5>⚠️ 注意事项</h5>
            <ul class="mb-0">
                <li>导入数据前，请确保已运行 <code>create_all_tables.php</code> 创建表结构</li>
                <li>如果选择"清空现有数据"，将删除所有表中的数据后再导入</li>
                <li>如果不选择"清空现有数据"，可能会产生重复记录或主键冲突</li>
                <li>建议在导入前先备份当前数据库</li>
                <li>大型备份文件导入可能需要较长时间，请耐心等待</li>
            </ul>
        </div>
        
        <?php if (empty($backup_files)): ?>
            <div class="alert alert-warning">
                <strong>未找到备份文件</strong><br>
                请在 <code>backups</code> 文件夹中放置SQL备份文件
            </div>
        <?php else: ?>
            <form method="POST" id="importForm">
                <div class="mb-4">
                    <label class="form-label"><strong>选择备份文件：</strong></label>
                    <div class="file-list">
                        <?php foreach ($backup_files as $index => $file): ?>
                            <div class="file-item" onclick="selectFile('<?php echo htmlspecialchars($file['name']); ?>')">
                                <input type="radio" name="backup_file" value="<?php echo htmlspecialchars($file['name']); ?>" 
                                       id="file_<?php echo $index; ?>" <?php echo $index === 0 ? 'checked' : ''; ?>>
                                <label for="file_<?php echo $index; ?>" style="cursor: pointer; margin: 0;">
                                    <strong><?php echo htmlspecialchars($file['name']); ?></strong>
                                    <div class="file-info">
                                        大小：<?php echo formatFileSize($file['size']); ?> | 
                                        日期：<?php echo $file['date']; ?>
                                    </div>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="clear_existing" value="1" id="clear_existing">
                        <label class="form-check-label" for="clear_existing">
                            <strong>清空现有数据</strong>（导入前删除所有表中的数据）
                        </label>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" name="import" class="btn btn-primary btn-lg" 
                            onclick="return confirm('确定要导入选定的备份文件吗？\n\n这将' + (document.getElementById('clear_existing').checked ? '清空现有数据并' : '') + '导入备份数据。');">
                        开始导入数据
                    </button>
                    <a href="create_all_tables.php" class="btn btn-secondary">返回创建表</a>
                    <a href="index.php" class="btn btn-outline-secondary">返回主页</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <script>
        function selectFile(filename) {
            document.querySelectorAll('input[name="backup_file"]').forEach(function(radio) {
                if (radio.value === filename) {
                    radio.checked = true;
                    // 更新选中样式
                    document.querySelectorAll('.file-item').forEach(function(item) {
                        item.classList.remove('selected');
                    });
                    radio.closest('.file-item').classList.add('selected');
                }
            });
        }
        
        // 初始化选中样式
        document.addEventListener('DOMContentLoaded', function() {
            const checked = document.querySelector('input[name="backup_file"]:checked');
            if (checked) {
                checked.closest('.file-item').classList.add('selected');
            }
        });
    </script>
</body>
</html>

