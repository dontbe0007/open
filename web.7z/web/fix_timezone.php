<?php
/**
 * 修复时区问题
 * 检查和设置MySQL时区，并分析时间差异
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$messages = [];
$warnings = [];
$errors = [];

// 1. 检查PHP时区
$php_timezone = date_default_timezone_get();
$php_time = date('Y-m-d H:i:s');
$messages[] = "✓ PHP时区: {$php_timezone}";
$messages[] = "✓ PHP当前时间: {$php_time}";

// 2. 检查MySQL时区
try {
    // 获取MySQL当前时间（使用不同的别名避免关键字冲突）
    $mysql_now = $pdo->query("SELECT NOW() AS mysql_time")->fetch(PDO::FETCH_ASSOC);
    $mysql_time = $mysql_now['mysql_time'];
    
    // 获取时区设置
    $global_tz_result = $pdo->query("SELECT @@global.time_zone AS timezone")->fetch(PDO::FETCH_ASSOC);
    $session_tz_result = $pdo->query("SELECT @@session.time_zone AS timezone")->fetch(PDO::FETCH_ASSOC);
    
    $global_tz = $global_tz_result['timezone'];
    $session_tz = $session_tz_result['timezone'];
    
    $messages[] = "✓ MySQL当前时间: {$mysql_time}";
    $messages[] = "✓ MySQL全局时区: {$global_tz}";
    $messages[] = "✓ MySQL会话时区: {$session_tz}";
    
    // 计算时间差
    $php_dt = new DateTime($php_time);
    $mysql_dt = new DateTime($mysql_time);
    $time_diff = $php_dt->getTimestamp() - $mysql_dt->getTimestamp();
    $time_diff_hours = $time_diff / 3600;
    
    if (abs($time_diff) > 5) {
        $warnings[] = "⚠️ PHP和MySQL时间差异: " . number_format($time_diff_hours, 2) . " 小时";
        if ($time_diff > 0) {
            $warnings[] = "   MySQL时间比PHP时间慢 " . abs($time_diff_hours) . " 小时";
        } else {
            $warnings[] = "   MySQL时间比PHP时间快 " . abs($time_diff_hours) . " 小时";
        }
    } else {
        $messages[] = "✓ PHP和MySQL时间一致";
    }
    
    // 3. 检查数据库中的最新记录
    $latest_outbound = $pdo->query("SELECT id, outbound_date, created_at FROM outbound_records ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if ($latest_outbound) {
        $record_time = new DateTime($latest_outbound['outbound_date']);
        $record_diff = $php_dt->getTimestamp() - $record_time->getTimestamp();
        $record_diff_hours = $record_diff / 3600;
        
        $messages[] = "✓ 最新出库记录时间: {$latest_outbound['outbound_date']}";
        
        if (abs($record_diff_hours) > 1) {
            $warnings[] = "⚠️ 最新记录时间与当前时间差异: " . number_format($record_diff_hours, 2) . " 小时";
        }
    }
    
    // 4. 处理时区修复请求
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fix_timezone'])) {
        try {
            // 设置MySQL会话时区
            $pdo->exec("SET time_zone = '+08:00'");
            $messages[] = "✓ 已设置MySQL会话时区为 +08:00";
            
            // 验证设置
            $new_session_tz_result = $pdo->query("SELECT @@session.time_zone AS timezone")->fetch(PDO::FETCH_ASSOC);
            $new_mysql_time_result = $pdo->query("SELECT NOW() AS mysql_time")->fetch(PDO::FETCH_ASSOC);
            
            $new_session_tz = $new_session_tz_result['timezone'];
            $new_mysql_time = $new_mysql_time_result['mysql_time'];
            
            $messages[] = "✓ 新的MySQL会话时区: {$new_session_tz}";
            $messages[] = "✓ 新的MySQL时间: {$new_mysql_time}";
            
            // 重新计算时间差
            $new_mysql_dt = new DateTime($new_mysql_time);
            $new_time_diff = $php_dt->getTimestamp() - $new_mysql_dt->getTimestamp();
            
            if (abs($new_time_diff) <= 5) {
                $messages[] = "✓ 时区修复成功！PHP和MySQL时间现在一致";
            } else {
                $warnings[] = "⚠️ 时区已设置，但时间仍有差异: " . number_format($new_time_diff / 3600, 2) . " 小时";
            }
            
        } catch (PDOException $e) {
            $errors[] = "✗ 设置时区失败: " . $e->getMessage();
        }
    }
    
    // 5. 处理更新记录时间请求（如果需要）
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_records']) && isset($_POST['hours_offset'])) {
        $hours_offset = (float)$_POST['hours_offset'];
        $seconds_offset = $hours_offset * 3600;
        
        try {
            $pdo->beginTransaction();
            
            // 更新出库记录时间
            $update_count = $pdo->exec("
                UPDATE outbound_records 
                SET outbound_date = DATE_ADD(outbound_date, INTERVAL {$seconds_offset} SECOND),
                    created_at = DATE_ADD(created_at, INTERVAL {$seconds_offset} SECOND)
                WHERE DATE(outbound_date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            ");
            
            $pdo->commit();
            
            $messages[] = "✓ 已更新 {$update_count} 条最近7天的出库记录时间";
            $messages[] = "✓ 时间调整: " . ($hours_offset > 0 ? "+" : "") . number_format($hours_offset, 2) . " 小时";
            
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = "✗ 更新记录失败: " . $e->getMessage();
        }
    }
    
} catch (PDOException $e) {
    $errors[] = "✗ MySQL错误: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修复时区问题</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .message {
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .message.warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .action-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">🕐 修复时区问题</h2>
        
        <!-- 消息显示 -->
        <?php foreach ($messages as $msg): ?>
            <div class="message success"><?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <?php foreach ($warnings as $msg): ?>
            <div class="message warning"><?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <?php foreach ($errors as $msg): ?>
            <div class="message error"><?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <!-- 操作区域 -->
        <?php if (isset($time_diff_hours) && abs($time_diff_hours) > 0.1): ?>
            <div class="action-box">
                <h5>修复MySQL时区</h5>
                <p>检测到MySQL时区可能不正确。点击下方按钮设置MySQL会话时区为 +08:00（北京时间）。</p>
                <form method="POST" style="display: inline;">
                    <button type="submit" name="fix_timezone" class="btn btn-primary" 
                            onclick="return confirm('确定要设置MySQL时区为 +08:00 吗？\n\n这将影响后续的时间记录。');">
                        设置MySQL时区为 +08:00
                    </button>
                </form>
            </div>
            
            <?php if (isset($record_diff_hours) && abs($record_diff_hours) > 1): ?>
                <div class="action-box">
                    <h5>⚠️ 更新已有记录时间</h5>
                    <p>检测到数据库中的记录时间与当前时间差异较大（<?php echo number_format($record_diff_hours, 2); ?> 小时）。</p>
                    <p><strong>注意：</strong>此操作将调整最近7天的出库记录时间。请谨慎操作！</p>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">时间调整（小时）:</label>
                            <input type="number" name="hours_offset" class="form-control" 
                                   value="<?php echo number_format($record_diff_hours, 2); ?>" 
                                   step="0.01" required>
                            <small class="form-text text-muted">
                                正数表示向后调整，负数表示向前调整
                            </small>
                        </div>
                        <button type="submit" name="update_records" class="btn btn-warning" 
                                onclick="return confirm('确定要调整记录时间吗？\n\n此操作不可逆！');">
                            更新记录时间
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <div class="mt-4">
            <a href="check_time.php" class="btn btn-secondary">返回时间检测</a>
            <a href="index.php" class="btn btn-primary">返回主页</a>
        </div>
    </div>
</body>
</html>

