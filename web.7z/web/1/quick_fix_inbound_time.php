<?php
/**
 * 快速修复最近一条入库记录的时间
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$message = '';
$error = '';

// 获取最近一条入库记录
try {
    $latest = $pdo->query("
        SELECT id, inbound_date, remark, inbound_quantity, product_code, location
        FROM inbound_records 
        ORDER BY id DESC 
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);
    
    if ($latest) {
        $record_time = strtotime($latest['inbound_date']);
        $current_time = time();
        $time_diff = $current_time - $record_time;
        $hours_diff = $time_diff / 3600;
        
        // 如果时间差在7-9小时之间，说明是UTC时间，需要+8小时
        if ($hours_diff > 7 && $hours_diff < 9) {
            // 修复这条记录
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fix'])) {
                try {
                    $pdo->beginTransaction();
                    
                    // 将时间向前调整8小时
                    $stmt = $pdo->prepare("
                        UPDATE inbound_records 
                        SET inbound_date = DATE_ADD(inbound_date, INTERVAL 8 HOUR)
                        WHERE id = ?
                    ");
                    $stmt->execute([$latest['id']]);
                    
                    $pdo->commit();
                    
                    $message = "✓ 已修复记录 ID {$latest['id']} 的时间（+8小时）";
                    
                    // 重新获取修复后的记录
                    $latest = $pdo->query("
                        SELECT id, inbound_date, remark, inbound_quantity, product_code, location
                        FROM inbound_records 
                        WHERE id = {$latest['id']}
                    ")->fetch(PDO::FETCH_ASSOC);
                    
                } catch (PDOException $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = "修复失败: " . $e->getMessage();
                }
            } else {
                $message = "发现时间错误的记录，需要修复";
            }
        } else {
            $message = "记录时间看起来正常（差异: " . number_format($hours_diff, 2) . " 小时）";
        }
    } else {
        $message = "未找到入库记录";
    }
} catch (PDOException $e) {
    $error = "查询失败: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>快速修复入库时间</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .record-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">快速修复最近一条入库记录</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($latest): ?>
            <div class="record-info">
                <h5>最近一条入库记录：</h5>
                <p><strong>ID:</strong> <?php echo $latest['id']; ?></p>
                <p><strong>入库时间:</strong> <?php echo htmlspecialchars($latest['inbound_date']); ?></p>
                <p><strong>产品编码:</strong> <?php echo htmlspecialchars($latest['product_code']); ?></p>
                <p><strong>数量:</strong> <?php echo $latest['inbound_quantity']; ?></p>
                <p><strong>库位:</strong> <?php echo htmlspecialchars($latest['location']); ?></p>
                <p><strong>备注:</strong> <?php echo htmlspecialchars($latest['remark'] ?? ''); ?></p>
                
                <?php 
                $record_time = strtotime($latest['inbound_date']);
                $current_time = time();
                $time_diff = $current_time - $record_time;
                $hours_diff = $time_diff / 3600;
                ?>
                <p><strong>与当前时间差:</strong> <?php echo number_format($hours_diff, 2); ?> 小时</p>
                
                <?php if ($hours_diff > 7 && $hours_diff < 9): ?>
                    <div class="alert alert-warning mt-3">
                        <strong>⚠️ 检测到时间错误！</strong><br>
                        这条记录的时间比当前时间慢约8小时，可能是UTC时间。<br>
                        修复后时间将变为: <?php echo date('Y-m-d H:i:s', $record_time + 8*3600); ?>
                    </div>
                    
                    <form method="POST">
                        <button type="submit" name="fix" class="btn btn-warning" 
                                onclick="return confirm('确定要修复这条记录的时间吗？\n\n将时间向前调整8小时。');">
                            修复这条记录（+8小时）
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div class="mt-4">
            <a href="inbound.php" class="btn btn-primary">返回入库页面</a>
            <a href="quick_fix_time.php" class="btn btn-secondary">修复出库时间</a>
        </div>
    </div>
</body>
</html>


