<?php
/**
 * 测试导入功能 - 检查基本环境
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>环境检查</h2>";
echo "<pre>";

// 检查PHP版本
echo "PHP版本: " . PHP_VERSION . "\n";

// 检查内存限制
echo "内存限制: " . ini_get('memory_limit') . "\n";

// 检查执行时间限制
echo "执行时间限制: " . ini_get('max_execution_time') . " 秒\n";

// 检查文件上传限制
echo "文件上传限制: " . ini_get('upload_max_filesize') . "\n";

// 检查backups目录
$backup_dir = 'backups';
if (file_exists($backup_dir)) {
    echo "backups目录: 存在\n";
    echo "目录权限: " . substr(sprintf('%o', fileperms($backup_dir)), -4) . "\n";
    
    $files = glob($backup_dir . '/*.sql');
    echo "备份文件数量: " . count($files) . "\n";
    foreach ($files as $file) {
        echo "  - " . basename($file) . " (" . number_format(filesize($file) / 1024, 2) . " KB)\n";
    }
} else {
    echo "backups目录: 不存在\n";
}

// 检查config.php
if (file_exists('config.php')) {
    echo "config.php: 存在\n";
    require_once 'config.php';
    
    // 测试数据库连接
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "数据库连接: 成功\n";
        
        // 检查表是否存在
        $tables = ['users', 'production_plans', 'outbound_records', 'inbound_records', 'inventory', 'shift_records'];
        echo "\n表检查:\n";
        foreach ($tables as $table) {
            try {
                $result = $pdo->query("SELECT COUNT(*) FROM `$table`");
                $count = $result->fetchColumn();
                echo "  - $table: 存在 (记录数: $count)\n";
            } catch (PDOException $e) {
                echo "  - $table: 不存在或错误 - " . $e->getMessage() . "\n";
            }
        }
    } catch (PDOException $e) {
        echo "数据库连接: 失败 - " . $e->getMessage() . "\n";
    }
} else {
    echo "config.php: 不存在\n";
}

echo "</pre>";

echo "<h3>快速链接</h3>";
echo "<ul>";
echo "<li><a href='create_all_tables.php'>创建数据库表</a></li>";
echo "<li><a href='import_backup_data.php'>导入备份数据</a></li>";
echo "<li><a href='index.php'>返回主页</a></li>";
echo "</ul>";
?>



