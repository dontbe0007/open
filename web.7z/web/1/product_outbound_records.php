<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 获取日期和班次参数
$selected_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$shift = isset($_GET['shift']) ? $_GET['shift'] : 'day'; // day: 白班, night: 夜班

// 根据班次设置时间条件和班次名称
if ($shift === 'day') {
    // 白班：07:30 - 19:30
    $time_where = "((DATE(o.outbound_date) = ? AND TIME(o.outbound_date) >= '07:30:00' AND TIME(o.outbound_date) <= '19:30:00'))";
    $params_base = [$selected_date];
    $shift_name = '白班 (07:30-19:30)';
} else {
    // 夜班：19:30 - 次日07:30
    $time_where = "((DATE(o.outbound_date) = ? AND TIME(o.outbound_date) > '19:30:00') OR (DATE(o.outbound_date) = DATE_ADD(?, INTERVAL 1 DAY) AND TIME(o.outbound_date) <= '07:30:00'))";
    $params_base = [$selected_date, $selected_date];
    $shift_name = '夜班 (19:30-次日07:30)';
}

// 获取所有产品编码的出库记录
try {
    // 根据用户角色获取数据
    if ($is_admin || $is_storage) {
        // 管理员和仓管可以看到所有数据
        $stmt = $pdo->prepare("
            SELECT 
                p.product_code,
                o.outbound_quantity,
                o.remark,
                o.outbound_date,
                o.id as outbound_id,
                u.username as operator_name
            FROM outbound_records o
            INNER JOIN production_plans p ON o.plan_id = p.id
            LEFT JOIN users u ON o.user_id = u.id
            WHERE $time_where
            ORDER BY p.product_code, o.outbound_date DESC
        ");
        $stmt->execute($params_base);
    } else {
        // 普通用户只能看到自己的数据
        $stmt = $pdo->prepare("
            SELECT 
                p.product_code,
                o.outbound_quantity,
                o.remark,
                o.outbound_date,
                o.id as outbound_id,
                u.username as operator_name
            FROM outbound_records o
            INNER JOIN production_plans p ON o.plan_id = p.id
            LEFT JOIN users u ON o.user_id = u.id
            WHERE o.user_id = ? AND $time_where
            ORDER BY p.product_code, o.outbound_date DESC
        ");
        $params = array_merge([$user_id], $params_base);
        $stmt->execute($params);
    }
    $records = $stmt->fetchAll();
    
    // 从备注中提取库位信息的函数（提取后四位数字）
    function extractLocation($remark) {
        if (empty($remark)) {
            return '未设置';
        }
        // 提取备注中的所有数字
        preg_match_all('/\d+/', $remark, $matches);
        if (empty($matches[0])) {
            return '未设置';
        }
        
        // 将所有数字连接起来
        $all_digits = implode('', $matches[0]);
        
        // 如果数字少于4位，返回未设置
        if (strlen($all_digits) < 4) {
            return '未设置';
        }
        
        // 提取最后4位数字
        $last_four = substr($all_digits, -4);
        
        // 分成前2位和后2位，去掉前导0
        $first_part = (int)substr($last_four, 0, 2);
        $second_part = (int)substr($last_four, 2, 2);
        
        // 格式化为库位：前部分-后部分
        return $first_part . '-' . $second_part;
    }
    
    // 按产品编码分组
    $grouped_records = [];
    $product_totals = [];
    $location_stats = []; // 库位统计：按产品编码 -> 库位 -> [每次出库数量数组]
    
    foreach ($records as $record) {
        $product_code = $record['product_code'] ?? '未设置';
        $remark = $record['remark'] ?? '';
        $quantity = (int)$record['outbound_quantity'];
        $location = extractLocation($remark);
        
        if (!isset($grouped_records[$product_code])) {
            $grouped_records[$product_code] = [];
            $product_totals[$product_code] = 0;
            $location_stats[$product_code] = [];
        }
        
        $grouped_records[$product_code][] = $record;
        $product_totals[$product_code] += $quantity;
        
        // 统计库位信息：保存每次出库的数量
        if (!isset($location_stats[$product_code][$location])) {
            $location_stats[$product_code][$location] = [];
        }
        $location_stats[$product_code][$location][] = $quantity;
    }
    
    // 按产品编码排序
    ksort($grouped_records);
    ksort($product_totals);
    
    // 对每个产品编码的库位统计进行排序
    foreach ($location_stats as $product_code => &$locations) {
        ksort($locations);
    }
    
} catch(PDOException $e) {
    $error = "获取出库记录失败：" . $e->getMessage();
    $grouped_records = [];
    $product_totals = [];
    $location_stats = [];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>产品编码出库记录 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card { 
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .btn {
            border-radius: 5px;
        }
        .form-control {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
        .product-section {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .product-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px solid #007bff;
        }
        .product-code-title {
            font-size: 20px;
            font-weight: 600;
            color: #333;
        }
        .product-total {
            font-size: 18px;
            font-weight: 600;
            color: #007bff;
        }
        .records-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 12px;
        }
        /* 确保在大屏幕上至少显示4列 */
        @media (min-width: 900px) {
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
        .record-item {
            display: flex;
            flex-direction: column;
            padding: 12px;
            background-color: #f8f9fa;
            border-radius: 5px;
            border-left: 3px solid #007bff;
        }
        .record-quantity {
            font-weight: 600;
            color: #333;
            font-size: 16px;
            margin-bottom: 4px;
        }
        .record-remark {
            color: #666;
            font-size: 14px;
            word-break: break-word;
        }
        .record-operator {
            color: #999;
            font-size: 12px;
            margin-top: 4px;
        }
        .location-summary {
            margin-top: 20px;
            padding: 15px;
            background-color: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
        }
        .location-summary-header {
            font-size: 16px;
            font-weight: 600;
            color: #856404;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #ffc107;
        }
        .location-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
        }
        .location-stat-item {
            background-color: white;
            padding: 10px;
            border-radius: 6px;
            border-left: 4px solid #ffc107;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .location-name {
            font-weight: 600;
            color: #333;
            font-size: 14px;
            margin-bottom: 8px;
        }
        .location-quantities {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            align-items: center;
        }
        .quantity-badge {
            display: inline-block;
            background-color: #e7f3ff;
            color: #007bff;
            font-weight: 600;
            font-size: 14px;
            padding: 4px 10px;
            border-radius: 4px;
            border: 1px solid #b3d9ff;
            white-space: nowrap;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .nav-buttons {
            display: flex;
            gap: 10px;
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        @media (max-width: 1200px) {
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            }
            .location-stats-grid {
                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            }
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .d-flex.justify-content-between {
                flex-direction: column;
                gap: 15px;
            }
            .nav-buttons {
                flex-direction: row;
                flex-wrap: wrap;
                width: 100%;
                justify-content: flex-start;
            }
            .nav-buttons .btn {
                flex: 1;
                min-width: 120px;
                margin-bottom: 5px;
            }
            .product-section {
                padding: 15px;
            }
            .product-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            .location-summary {
                padding: 12px;
                margin-top: 15px;
            }
            .location-summary-header {
                font-size: 14px;
            }
            .location-stats-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                gap: 8px;
            }
            .location-stat-item {
                padding: 8px;
            }
            .location-name {
                font-size: 13px;
            }
            .location-quantities {
                gap: 5px;
            }
            .quantity-badge {
                font-size: 13px;
                padding: 3px 8px;
            }
        }
        @media (max-width: 480px) {
            .records-list {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }
            .location-stats-grid {
                grid-template-columns: 1fr;
            }
            .location-stat-item {
                padding: 10px;
            }
            .location-quantities {
                gap: 4px;
            }
            .quantity-badge {
                font-size: 12px;
                padding: 3px 6px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_dashboard.php?page=users">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">产品编码出库记录 - <?php echo $shift_name; ?></h1>
            <div>
                <div class="d-flex gap-2">
                    <div class="nav-buttons">
                        <a href="index.php" class="btn btn-primary">返回主页</a>
                        <?php if ($is_admin || $is_storage): ?>
                        <a href="backup.php" class="btn btn-info">备份管理</a>
                        <?php endif; ?>
                        <a href="navigation.php" class="btn btn-info">不迷路</a>
                        <a href="daily_report.php" class="btn btn-info">出库日报表</a>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- 日期和班次选择 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">选择日期和班次</h5>
            </div>
            <div class="card-body">
                <form method="GET" class="d-flex gap-2">
                    <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($selected_date); ?>" max="<?php echo date('Y-m-d'); ?>" required>
                    <select name="shift" class="form-control">
                        <option value="day" <?php echo $shift === 'day' ? 'selected' : ''; ?>>白班 (07:30-19:30)</option>
                        <option value="night" <?php echo $shift === 'night' ? 'selected' : ''; ?>>夜班 (19:30-次日07:30)</option>
                    </select>
                    <button type="submit" class="btn btn-primary">查询</button>
                </form>
            </div>
        </div>

        <!-- 产品编码出库记录列表 -->
        <?php if (empty($grouped_records)): ?>
            <div class="card">
                <div class="card-body">
                    <div class="empty-state">
                        <div class="empty-state-icon">📦</div>
                        <h5>暂无出库记录</h5>
                        <p><?php echo $selected_date . ' ' . $shift_name; ?> - 无出库记录</p>
                        <p class="text-muted">请选择其他日期或班次查看出库记录</p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($grouped_records as $product_code => $records): ?>
                <div class="product-section">
                    <div class="product-header">
                        <div class="product-code-title">产品编码：<?php echo htmlspecialchars($product_code); ?></div>
                        <div class="product-total">出库总数：<?php echo number_format($product_totals[$product_code]); ?></div>
                    </div>
                    
                    <div class="records-list">
                        <?php foreach ($records as $record): ?>
                            <div class="record-item">
                                <div class="record-quantity">数量：<?php echo number_format($record['outbound_quantity']); ?></div>
                                <div class="record-remark">备注：<?php echo htmlspecialchars($record['remark'] ?? '无'); ?></div>
                                <?php if ($is_admin || $is_storage): ?>
                                <div class="record-operator">操作人：<?php echo htmlspecialchars($record['operator_name'] ?? '未知'); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- 库位统计汇总 -->
                    <?php if (isset($location_stats[$product_code]) && !empty($location_stats[$product_code])): ?>
                        <div class="location-summary">
                            <div class="location-summary-header d-flex justify-content-between align-items-center">
                                <strong>📊 库位统计汇总</strong>
                                <button type="button" class="btn btn-sm btn-success" onclick="exportLocationStats('<?php echo htmlspecialchars($product_code); ?>')">
                                    📋 导出库位统计
                                </button>
                            </div>
                            <div class="location-stats-grid" id="location-stats-<?php echo htmlspecialchars($product_code); ?>">
                                <?php foreach ($location_stats[$product_code] as $location => $quantities): ?>
                                    <div class="location-stat-item" data-location="<?php echo htmlspecialchars($location); ?>">
                                        <div class="location-name">库位：<?php echo htmlspecialchars($location); ?></div>
                                        <div class="location-quantities">
                                            <?php foreach ($quantities as $qty): ?>
                                                <span class="quantity-badge"><?php echo number_format($qty); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // 导出库位统计功能
    function exportLocationStats(productCode) {
        const statsContainer = document.getElementById('location-stats-' + productCode);
        if (!statsContainer) return;
        
        const statItems = statsContainer.querySelectorAll('.location-stat-item');
        let exportText = `产品编码：${productCode}\n`;
        exportText += `日期：<?php echo $selected_date; ?> <?php echo $shift_name; ?>\n`;
        exportText += `库位统计汇总\n`;
        exportText += `${'='.repeat(40)}\n\n`;
        
        statItems.forEach(item => {
            const location = item.getAttribute('data-location');
            const quantities = Array.from(item.querySelectorAll('.quantity-badge')).map(badge => badge.textContent.trim());
            
            exportText += `库位：${location}\n`;
            exportText += `${quantities.join(' ')}\n`;
            exportText += `\n`;
        });
        
        // 复制到剪贴板
        navigator.clipboard.writeText(exportText).then(() => {
            alert('库位统计已复制到剪贴板！\n\n可以直接粘贴到文档或打印。');
        }).catch(err => {
            console.error('复制失败:', err);
            // 备用方案：显示文本让用户手动复制
            const textarea = document.createElement('textarea');
            textarea.value = exportText;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                alert('库位统计已复制到剪贴板！');
            } catch (e) {
                // 如果复制失败，显示文本让用户手动复制
                const newWindow = window.open();
                newWindow.document.write('<pre>' + exportText.replace(/\n/g, '<br>') + '</pre>');
            }
            document.body.removeChild(textarea);
        });
    }
    </script>
</body>
</html>

