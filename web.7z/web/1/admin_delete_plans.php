<?php
// 批量删除计划页面
?>

<div class="content-header">
    <h2><i class="bi bi-trash"></i> 批量删除计划</h2>
</div>

<div class="content-body">
    <?php if (!empty($delete_success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($delete_success); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($delete_error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($delete_error); ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0"><i class="bi bi-exclamation-triangle"></i> 批量删除生产计划</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-warning">
                <h6><i class="bi bi-info-circle"></i> 操作说明</h6>
                <ul class="mb-0">
                    <li>此操作将删除指定日期范围内的所有生产计划</li>
                    <li>计划将被移至回收站，可以从回收站恢复</li>
                    <li>相关的出库记录不会被删除</li>
                    <li><strong>建议在执行前先备份数据</strong></li>
                </ul>
            </div>
            
            <form method="POST" class="row g-3">
                <div class="col-md-4">
                    <label for="start_date" class="form-label">开始日期</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" required>
                </div>
                <div class="col-md-4">
                    <label for="end_date" class="form-label">结束日期</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" required>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" name="delete_plans_by_date" class="btn btn-danger w-100" 
                            onclick="return confirm('⚠️ 确定要删除指定日期范围内的所有计划吗？\n\n此操作将把计划移至回收站，可以从回收站恢复。');">
                        <i class="bi bi-trash"></i> 删除计划
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


