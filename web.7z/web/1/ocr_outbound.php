<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 获取计划ID
$plan_id = isset($_GET['plan_id']) ? (int) $_GET['plan_id'] : 0;
if (!$plan_id) {
    header('Location: index.php');
    exit;
}

// 获取计划信息
try {
    if ($is_admin) {
        $stmt = $pdo->prepare("
            SELECT p.*, 
                   COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id
            WHERE p.id = ?
            GROUP BY p.id
        ");
        $stmt->execute([$plan_id]);
    } else {
        $stmt = $pdo->prepare("
            SELECT p.*, 
                   COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
            FROM production_plans p
            LEFT JOIN outbound_records o ON p.id = o.plan_id
            WHERE p.id = ? AND p.user_id = ?
            GROUP BY p.id
        ");
        $stmt->execute([$plan_id, $user_id]);
    }
    $plan = $stmt->fetch();

    if (!$plan) {
        header('Location: index.php');
        exit;
    }
} catch (Exception $e) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

// 处理出库请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['outbound_quantity'])) {
    $outbound_quantity = (int) $_POST['outbound_quantity'];
    $remark = trim($_POST['remark']);

    if (empty($remark)) {
        $remark = '识别码';
    }

    try {
        // 开始事务
        $pdo->beginTransaction();

        // 检查出库数量
        if ($outbound_quantity <= 0) {
            throw new Exception('出库数量必须大于0');
        }

        // 检查是否超过计划数量
        if ($outbound_quantity > ($plan['planned_quantity'] - $plan['total_outbound'])) {
            throw new Exception('出库数量不能超过计划剩余数量');
        }

        // 处理照片上传
        $photo_path = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/outbound_photos/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

            if (!in_array($file_extension, $allowed_extensions)) {
                throw new Exception('只允许上传 JPG, JPEG, PNG 或 GIF 格式的图片');
            }

            $new_filename = uniqid() . '.' . $file_extension;
            $target_path = $upload_dir . $new_filename;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)) {
                $photo_path = $target_path;
            } else {
                throw new Exception('照片上传失败');
            }
        }

        // 添加出库记录
        $check_photo_field = $pdo->query("SHOW COLUMNS FROM outbound_records LIKE 'photo_path'");
        if ($check_photo_field->rowCount() == 0) {
            $pdo->exec("ALTER TABLE outbound_records ADD COLUMN photo_path VARCHAR(255) DEFAULT NULL AFTER remark");
        }

        // 使用 PHP 时间确保时区正确
        $current_time = date('Y-m-d H:i:s');
        
        $stmt = $pdo->prepare(
            "INSERT INTO outbound_records (plan_id, user_id, outbound_quantity, remark, photo_path, outbound_date)
            VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([$plan_id, $user_id, $outbound_quantity, $remark, $photo_path, $current_time]);

        // 提交事务
        $pdo->commit();

        $success = '出库成功！';

        // 重新获取计划信息
        if ($is_admin) {
            $stmt = $pdo->prepare("
                SELECT p.*, 
                       COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
                FROM production_plans p
                LEFT JOIN outbound_records o ON p.id = o.plan_id
                WHERE p.id = ?
                GROUP BY p.id
            ");
            $stmt->execute([$plan_id]);
        } else {
            $stmt = $pdo->prepare("
                SELECT p.*, 
                       COALESCE(SUM(o.outbound_quantity), 0) as total_outbound
                FROM production_plans p
                LEFT JOIN outbound_records o ON p.id = o.plan_id
                WHERE p.id = ? AND p.user_id = ?
                GROUP BY p.id
            ");
            $stmt->execute([$plan_id, $user_id]);
        }
        $plan = $stmt->fetch();

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = '出库失败：' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智能出库 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Tesseract.js OCR库 -->
    <script src="https://cdn.jsdelivr.net/npm/tesseract.js@4/dist/tesseract.min.js"></script>
    <!-- html5-qrcode 统一扫码库 (支持条码+二维码) -->
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    <style>
        body {
            padding: 15px;
            background-color: #f8f9fa;
        }

        .card {
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .camera-container {
            position: relative;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
        }

        #video {
            width: 100%;
            border-radius: 10px;
        }

        #canvas {
            display: none;
        }

        .capture-btn {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: #007bff;
            border: 3px solid white;
            color: white;
            font-size: 24px;
        }

        .ocr-result {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin: 15px 0;
            font-family: monospace;
            white-space: pre-wrap;
        }

        .recognition-status {
            text-align: center;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            font-weight: 500;
            border: 1px solid transparent;
            transition: all 0.3s ease;
        }

        .status-processing {
            background-color: #fff3cd;
            color: #856404;
            border-color: #ffeaa7;
            animation: pulse 1.5s infinite;
        }

        .status-success {
            background-color: #d1edff;
            color: #0c5460;
            border-color: #74b9ff;
        }

        .status-error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #fd79a8;
        }

        .status-warning {
            background-color: #ffeaa7;
            color: #2d3436;
            border-color: #fdcb6e;
        }

        .product-match {
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            font-weight: bold;
            border: 2px solid transparent;
            white-space: pre-line;
            transition: all 0.3s ease;
        }

        .match-success {
            background-color: #d4edda;
            color: #155724;
            border-color: #00b894;
        }

        .match-error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #e17055;
        }

        .capture-btn {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: #007bff;
            border: 3px solid white;
            color: white;
            font-size: 24px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .capture-btn:hover {
            background: #0056b3;
            transform: translateX(-50%) scale(1.1);
        }

        .capture-btn:active {
            transform: translateX(-50%) scale(0.95);
        }

        .photo-preview {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 10;
            backdrop-filter: blur(5px);
        }

        .photo-preview img {
            max-width: 90%;
            max-height: 65%;
            border-radius: 8px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.5);
            transition: transform 0.3s ease;
            cursor: pointer;
        }

        .photo-preview img:hover {
            transform: scale(1.02);
        }

        .preview-info {
            position: absolute;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            color: white;
            text-align: center;
            font-size: 14px;
            background: rgba(0, 0, 0, 0.7);
            padding: 8px 16px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }

        .preview-controls {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .preview-controls .btn {
            min-width: 110px;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }

        .preview-controls .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.4);
        }

        .image-quality-indicator {
            position: absolute;
            top: 60px;
            right: 15px;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 12px;
            backdrop-filter: blur(10px);
        }

        .quality-excellent { border-left: 4px solid #00b894; }
        .quality-good { border-left: 4px solid #fdcb6e; }
        .quality-poor { border-left: 4px solid #e17055; }

        .capture-success {
            animation: captureFlash 0.3s ease-out;
        }

        @keyframes captureFlash {
            0% {
                background-color: rgba(255, 255, 255, 0.8);
            }

            100% {
                background-color: transparent;
            }
        }

        @keyframes pulse {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0.7;
            }

            100% {
                opacity: 1;
            }
        }

        .btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .btn-group .btn {
            flex: 1;
            min-width: 120px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">智能出库</h1>
            <a href="index.php" class="btn btn-secondary">返回主页</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- 计划信息 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">计划信息</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>计划名称：</strong><?php echo htmlspecialchars($plan['plan_name']); ?></p>
                        <p><strong>产品编码：</strong><span
                                id="currentProductCode"><?php echo htmlspecialchars($plan['product_code']); ?></span>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>计划数量：</strong><?php echo $plan['planned_quantity']; ?></p>
                        <p><strong>剩余数量：</strong><?php echo $plan['planned_quantity'] - $plan['total_outbound']; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- OCR识别区域 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">📷 智能识别</h5>
            </div>
            <div class="card-body">
                <div class="camera-container">
                    <video id="video" autoplay playsinline></video>
                    <canvas id="canvas" style="display: none;"></canvas>
                    
                    <!-- html5-qrcode 扫码容器 -->
                    <div id="scannerContainer" style="display: none; position: relative;">
                        <div id="qr-reader" style="width: 100%; max-width: 500px; margin: 0 auto;"></div>
                        <div id="scannerStatus" style="text-align: center; margin-top: 10px; padding: 10px; 
                                                     background: rgba(0,0,0,0.8); color: white; border-radius: 10px;">
                            <div id="scannerTips">📱 将条码或二维码对准扫描区域</div>
                            <div id="scannerInfo" style="font-size: 12px; margin-top: 5px; color: #ccc;">
                                支持：QR码、条形码、Data Matrix等多种格式
                            </div>
                        </div>
                    </div>
                    <div id="photoPreview" class="photo-preview" style="display: none;">
                        <div class="preview-info">
                            <div>📷 拍照预览</div>
                            <small id="previewTips">点击图片可查看原始大小</small>
                        </div>
                        <div id="imageQualityIndicator" class="image-quality-indicator" style="display: none;">
                            <span id="qualityText">图片质量检测中...</span>
                        </div>
                        <img id="previewImage" src="" alt="拍照预览" title="点击查看原始大小">
                        <div class="preview-controls">
                            <button id="retakeBtn" class="btn btn-warning">🔄 重新拍照</button>
                            <button id="confirmPhotoBtn" class="btn btn-success">✅ 确认识别</button>
                        </div>
                    </div>
                    <button id="captureBtn" class="capture-btn">📷</button>
                </div>

                <div class="btn-group mt-3">
                    <button id="startCamera" class="btn btn-primary">📷 启动相机</button>
                    <button id="startScanner" class="btn btn-warning">📱 扫码识别</button>
                    <button id="autoRecognize" class="btn btn-success" disabled>🔍 OCR识别</button>
                    <input type="file" id="fileInput" accept="image/*" style="display: none;">
                    <button id="uploadBtn" class="btn btn-info">📁 选择图片</button>
                </div>

                <div class="text-center mt-2">
                    <small class="text-muted">
                        💡 提示：空格键拍照，ESC键关闭相机/取消预览，Enter键确认照片
                    </small>
                </div>

                <!-- OCR配置面板 -->
                <div class="mt-3">
                    <button class="btn btn-outline-secondary btn-sm" type="button" data-bs-toggle="collapse"
                        data-bs-target="#ocrConfig">
                        ⚙️ OCR设置
                    </button>
                    <div class="collapse mt-2" id="ocrConfig">
                        <div class="card card-body">
                            <h6>识别模式</h6>
                            <div class="btn-group-sm" role="group">
                                <input type="radio" class="btn-check" name="ocrPreset" id="highAccuracy"
                                    value="highAccuracy" checked>
                                <label class="btn btn-outline-primary" for="highAccuracy">高精度</label>

                                <input type="radio" class="btn-check" name="ocrPreset" id="fastMode" value="fastMode">
                                <label class="btn btn-outline-primary" for="fastMode">快速</label>

                                <input type="radio" class="btn-check" name="ocrPreset" id="numberOptimized"
                                    value="numberOptimized">
                                <label class="btn btn-outline-primary" for="numberOptimized">数字优化</label>
                            </div>
                            <small class="text-muted mt-2">
                                高精度：适合清晰图片 | 快速：适合模糊图片 | 数字优化：专门识别产品编码
                            </small>

                            <hr class="my-3">

                            <h6>图像预处理</h6>
                            <div class="row g-2">
                                <div class="col-6">
                                    <label class="form-label form-label-sm">亮度</label>
                                    <input type="range" class="form-range" id="brightnessSlider" min="0.5" max="2"
                                        step="0.1" value="1.2">
                                    <small class="text-muted">当前: <span id="brightnessValue">1.2</span></small>
                                </div>
                                <div class="col-6">
                                    <label class="form-label form-label-sm">对比度</label>
                                    <input type="range" class="form-range" id="contrastSlider" min="0.5" max="2.5"
                                        step="0.1" value="1.3">
                                    <small class="text-muted">当前: <span id="contrastValue">1.3</span></small>
                                </div>
                                <div class="col-6">
                                    <label class="form-label form-label-sm">锐化</label>
                                    <input type="range" class="form-range" id="sharpnessSlider" min="0.5" max="2"
                                        step="0.1" value="1.1">
                                    <small class="text-muted">当前: <span id="sharpnessValue">1.1</span></small>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-switch mt-4">
                                        <input class="form-check-input" type="checkbox" id="denoiseSwitch" checked>
                                        <label class="form-check-label" for="denoiseSwitch">降噪处理</label>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-info btn-sm"
                                    id="resetProcessing">重置默认</button>
                                <button type="button" class="btn btn-outline-success btn-sm"
                                    id="previewProcessing">预览效果</button>
                            </div>

                            <hr class="my-3">

                            <h6>验证统计</h6>
                            <div id="validationStats" class="small text-muted">
                                <div>总验证次数: <span id="totalValidations">0</span></div>
                                <div>成功率: <span id="successRate">0</span>%</div>
                                <div>平均置信度: <span id="averageConfidence">0</span>%</div>
                            </div>

                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-secondary btn-sm"
                                    id="clearValidationHistory">清除历史</button>
                                <button type="button" class="btn btn-outline-info btn-sm"
                                    id="showValidationDetails">查看详情</button>
                            </div>

                            <hr class="my-3">

                            <h6>表单控制</h6>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="enableQuantityFill" checked>
                                <label class="form-check-label" for="enableQuantityFill">自动填充数量</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="enableRemarkFill" checked>
                                <label class="form-check-label" for="enableRemarkFill">自动填充备注</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="showFillAnimation" checked>
                                <label class="form-check-label" for="showFillAnimation">填充动画</label>
                            </div>

                            <div class="mt-2">
                                <button type="button" class="btn btn-outline-warning btn-sm"
                                    id="resetForm">重置表单</button>
                                <button type="button" class="btn btn-outline-info btn-sm"
                                    id="showFillHistory">填充历史</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="recognitionStatus" class="recognition-status" style="display: none;"></div>
                <div id="productMatch" class="product-match" style="display: none;"></div>
                <div id="ocrResult" class="ocr-result" style="display: none;"></div>
            </div>
        </div>

        <!-- 出库表单 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">出库信息</h5>
            </div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">出库数量</label>
                        <input type="number" id="outboundQuantity" name="outbound_quantity" class="form-control"
                            required min="1" max="<?php echo $plan['planned_quantity'] - $plan['total_outbound']; ?>">
                        <div id="quantityWarning" class="mt-2" style="display: none;">
                            <small class="text-danger"><strong>⚠️ 警告：出库数量超过剩余数量！</strong></small>
                        </div>
                        <div id="quantityInfo" class="mt-2">
                            <small class="text-muted">剩余数量：<strong id="remainingQuantity"><?php echo $plan['planned_quantity'] - $plan['total_outbound']; ?></strong></small>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">备注</label>
                        <input type="text" id="remarkInput" name="remark" class="form-control" placeholder="识别码（最后4位数字将作为库位）"
                            value="<?php echo htmlspecialchars(substr($plan['product_code'], -3)); ?>">
                        <small class="text-muted">提示：备注最后4位数字将自动提取为库位（如：106-019-0804 → 库位：8-4）</small>
                        <div id="locationPreview" class="mt-2" style="display: none;">
                            <span class="badge bg-info">库位预览：<span id="locationPreviewText"></span></span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">上传照片</label>
                        <input type="file" name="photo" class="form-control" accept="image/*">
                        <small class="text-muted">可选：上传出库照片</small>
                    </div>
                    <button type="submit" class="btn btn-primary w-100" id="submitBtn">确认出库</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- 智能相机启动脚本 -->
    <script>
        // 检查环境支持
        function checkEnvironment() {
            const isHTTPS = location.protocol === 'https:' || 
                           location.hostname === 'localhost' || 
                           location.hostname === '127.0.0.1';
            
            const hasMediaDevices = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
            
            return {
                isHTTPS: isHTTPS,
                hasMediaDevices: hasMediaDevices,
                canUseCamera: isHTTPS && hasMediaDevices
            };
        }
        
        // 显示状态信息
        function showStatus(message, type = 'info') {
            const statusDiv = document.getElementById('recognitionStatus');
            if (statusDiv) {
                statusDiv.style.display = 'block';
                statusDiv.className = `recognition-status status-${type}`;
                statusDiv.innerHTML = message;
            }
            console.log(message);
        }
        
        // 智能相机按钮处理
        function handleCameraButton() {
            console.log('🎉 相机按钮被点击！');
            
            const env = checkEnvironment();
            const button = document.getElementById('startCamera');
            
            if (!env.isHTTPS) {
                showStatus(`
                    ⚠️ 相机功能需要HTTPS环境<br>
                    <strong>当前环境：</strong> ${location.protocol}//${location.host}<br>
                    <strong>解决方案：</strong><br>
                    1. 使用HTTPS访问此页面<br>
                    2. 或使用下方的"选择图片"功能上传照片
                `, 'warning');
                
                // 高亮显示上传按钮
                const uploadBtn = document.getElementById('uploadBtn');
                if (uploadBtn) {
                    uploadBtn.style.backgroundColor = '#28a745';
                    uploadBtn.style.color = 'white';
                    uploadBtn.innerHTML = '📁 点击这里上传图片 (推荐)';
                    
                    setTimeout(() => {
                        uploadBtn.style.backgroundColor = '';
                        uploadBtn.style.color = '';
                        uploadBtn.innerHTML = '📁 选择图片';
                    }, 5000);
                }
                
                return;
            }
            
            if (!env.hasMediaDevices) {
                showStatus(`
                    ❌ 浏览器不支持相机功能<br>
                    <strong>当前浏览器：</strong> ${navigator.userAgent.split(' ')[0]}<br>
                    <strong>建议：</strong><br>
                    1. 使用Chrome、Firefox或Safari最新版<br>
                    2. 或使用"选择图片"功能
                `, 'error');
                return;
            }
            
            // 环境支持，尝试启动相机
            startCamera();
        }
        
        // 启动相机功能
        async function startCamera() {
            const button = document.getElementById('startCamera');
            const video = document.getElementById('video');
            
            try {
                button.disabled = true;
                button.textContent = '🔄 启动中...';
                showStatus('🔄 正在请求相机权限，请允许访问...', 'processing');
                
                // 尝试不同的相机配置
                const constraints = [
                    { video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } } },
                    { video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } },
                    { video: true }
                ];
                
                let stream = null;
                for (let i = 0; i < constraints.length; i++) {
                    try {
                        stream = await navigator.mediaDevices.getUserMedia(constraints[i]);
                        break;
                    } catch (err) {
                        console.log(`配置 ${i + 1} 失败:`, err.message);
                        if (i === constraints.length - 1) throw err;
                    }
                }
                
                video.srcObject = stream;
                video.style.display = 'block';
                
                button.textContent = '❌ 关闭相机';
                button.className = 'btn btn-danger';
                
                showStatus('✅ 相机启动成功！现在可以拍照识别了', 'success');
                
                // 启用其他功能
                const autoRecognizeBtn = document.getElementById('autoRecognize');
                if (autoRecognizeBtn) {
                    autoRecognizeBtn.disabled = false;
                }
                
            } catch (error) {
                console.error('相机启动失败:', error);
                
                let errorMessage = '❌ 相机启动失败<br>';
                switch (error.name) {
                    case 'NotAllowedError':
                        errorMessage += '<strong>原因：</strong>权限被拒绝<br><strong>解决：</strong>请允许相机访问权限';
                        break;
                    case 'NotFoundError':
                        errorMessage += '<strong>原因：</strong>未找到相机设备<br><strong>解决：</strong>请检查设备是否有摄像头';
                        break;
                    default:
                        errorMessage += `<strong>错误：</strong>${error.message}`;
                }
                
                errorMessage += '<br><br>💡 <strong>替代方案：</strong>使用下方"选择图片"功能';
                showStatus(errorMessage, 'error');
                
                button.textContent = '📷 启动相机';
                button.className = 'btn btn-primary';
            } finally {
                button.disabled = false;
            }
        }
        
        // 页面加载完成后执行
        window.onload = function() {
            console.log('✅ 页面加载完成');
            
            const env = checkEnvironment();
            console.log('环境检查:', env);
            
            // 查找按钮并添加事件
            const btn = document.getElementById('startCamera');
            if (btn) {
                console.log('✅ 找到相机按钮');
                
                // 添加点击事件
                btn.onclick = handleCameraButton;
                btn.ontouchend = function(e) {
                    e.preventDefault();
                    handleCameraButton();
                };
                
                // 根据环境显示初始状态
                if (!env.canUseCamera) {
                    if (!env.isHTTPS) {
                        showStatus('⚠️ 需要HTTPS环境才能使用相机，请使用"选择图片"功能', 'warning');
                        btn.innerHTML = '🔒 需要HTTPS';
                        btn.title = '相机功能需要HTTPS环境，请使用选择图片功能';
                    } else if (!env.hasMediaDevices) {
                        showStatus('❌ 浏览器不支持相机，请使用"选择图片"功能', 'error');
                        btn.innerHTML = '❌ 不支持相机';
                        btn.title = '浏览器不支持相机功能，请使用选择图片功能';
                    }
                } else {
                    showStatus('✅ 相机功能已准备就绪，点击启动相机开始使用', 'success');
                }
                
                console.log('✅ 事件监听器已添加');
            } else {
                console.error('❌ 找不到相机按钮');
            }
            
            // html5-qrcode 扫码功能实现
            const startScannerBtn = document.getElementById('startScanner');
            let html5QrCode = null;
            let isScanning = false;
            
            if (startScannerBtn) {
                startScannerBtn.onclick = async function() {
                    if (isScanning) {
                        await stopScanner();
                    } else {
                        await startScanner();
                    }
                };
            }
            
            // 启动扫码功能
            async function startScanner() {
                try {
                    // 检查环境支持
                    if (!checkEnvironment().canUseCamera) {
                        showStatus('❌ 扫码功能需要HTTPS环境和相机权限', 'error');
                        return;
                    }
                    
                    // 检查html5-qrcode库是否加载
                    if (typeof Html5Qrcode === 'undefined') {
                        showStatus('❌ 扫码库未加载，请刷新页面重试', 'error');
                        return;
                    }
                    
                    startScannerBtn.disabled = true;
                    showStatus('🔄 正在启动扫码功能...', 'processing');
                    
                    // 隐藏其他容器，显示扫码容器
                    document.getElementById('video').style.display = 'none';
                    document.getElementById('scannerContainer').style.display = 'block';
                    
                    // 初始化html5-qrcode扫描器
                    html5QrCode = new Html5Qrcode("qr-reader");
                    
                    // 获取相机设备
                    const cameras = await Html5Qrcode.getCameras();
                    if (cameras && cameras.length) {
                        // 优先使用后置摄像头
                        let cameraId = cameras[0].id;
                        for (const camera of cameras) {
                            if (camera.label && camera.label.toLowerCase().includes('back')) {
                                cameraId = camera.id;
                                break;
                            }
                        }
                        
                        console.log(`使用相机: ${cameras.find(c => c.id === cameraId)?.label || cameraId}`);
                        
                        // 扫码配置
                        const config = {
                            fps: 10,    // 扫描帧率
                            qrbox: {    // 扫描区域
                                width: 300,
                                height: 200
                            },
                            aspectRatio: 1.777778,  // 16:9
                            disableFlip: false,     // 允许翻转
                            videoConstraints: {
                                facingMode: "environment"  // 后置摄像头
                            }
                        };
                        
                        // 启动扫码
                        await html5QrCode.start(
                            cameraId,
                            config,
                            (decodedText, decodedResult) => {
                                // 扫码成功回调
                                console.log(`扫码成功: ${decodedText}`, decodedResult);
                                handleScanResult(decodedText, decodedResult.result.format?.formatName || 'unknown');
                            },
                            (errorMessage) => {
                                // 扫码失败回调 (正常情况，不需要处理)
                                // console.log(`扫码中: ${errorMessage}`);
                            }
                        );
                        
                        isScanning = true;
                        startScannerBtn.textContent = '❌ 停止扫码';
                        startScannerBtn.className = 'btn btn-danger';
                        startScannerBtn.disabled = false;
                        
                        showStatus('📱 扫码已启动，请将条码或二维码对准扫描区域', 'success');
                        updateScannerTips('🔍 正在扫描中...', '支持QR码、条形码、Data Matrix等多种格式');
                        
                    } else {
                        throw new Error('未找到可用的相机设备');
                    }
                    
                } catch (error) {
                    console.error('扫码启动失败:', error);
                    showStatus(`❌ 扫码启动失败: ${error.message}`, 'error');
                    startScannerBtn.disabled = false;
                    
                    // 清理资源
                    if (html5QrCode) {
                        try {
                            await html5QrCode.stop();
                        } catch (e) {}
                        html5QrCode = null;
                    }
                }
            }
            
            // 停止扫码功能
            async function stopScanner() {
                try {
                    if (html5QrCode && isScanning) {
                        await html5QrCode.stop();
                        html5QrCode.clear();
                        html5QrCode = null;
                    }
                    
                    // 隐藏扫码容器
                    document.getElementById('scannerContainer').style.display = 'none';
                    document.getElementById('video').style.display = 'block';
                    
                    isScanning = false;
                    startScannerBtn.textContent = '📱 扫码识别';
                    startScannerBtn.className = 'btn btn-warning';
                    
                    showStatus('扫码已停止', 'success');
                    
                } catch (error) {
                    console.error('停止扫码失败:', error);
                    showStatus('扫码停止完成', 'success');
                }
            }
            
            // 更新扫码提示信息
            function updateScannerTips(tips, info) {
                const tipsElement = document.getElementById('scannerTips');
                const infoElement = document.getElementById('scannerInfo');
                
                if (tipsElement) tipsElement.textContent = tips;
                if (infoElement) infoElement.textContent = info;
            }
            
            // 处理扫码结果
            function handleScanResult(scannedData, formatName) {
                console.log(`扫码成功 (${formatName}):`, scannedData);
                
                // 停止扫码
                stopScanner();
                
                // 格式化显示名称
                const formatDisplayName = getFormatDisplayName(formatName);
                
                // 显示扫码结果
                showStatus(`✅ 扫码成功 (${formatDisplayName}): ${scannedData}`, 'success');
                
                // 播放成功音效 (如果支持)
                playSuccessSound();
                
                // 解析扫码数据
                parseScanResult(scannedData, formatName);
            }
            
            // 获取格式显示名称
            function getFormatDisplayName(formatName) {
                const formatMap = {
                    'QR_CODE': 'QR码',
                    'CODE_128': 'Code 128',
                    'CODE_39': 'Code 39',
                    'EAN_13': 'EAN-13',
                    'EAN_8': 'EAN-8',
                    'UPC_A': 'UPC-A',
                    'UPC_E': 'UPC-E',
                    'CODABAR': 'Codabar',
                    'ITF': 'ITF',
                    'DATA_MATRIX': 'Data Matrix',
                    'PDF_417': 'PDF417',
                    'AZTEC': 'Aztec',
                    'unknown': '未知格式'
                };
                
                return formatMap[formatName] || formatName || '条码';
            }
            
            // 播放成功音效
            function playSuccessSound() {
                try {
                    // 创建简单的成功音效
                    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    
                    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                    oscillator.frequency.setValueAtTime(1000, audioContext.currentTime + 0.1);
                    
                    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
                    
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.2);
                } catch (e) {
                    // 音效播放失败，忽略错误
                    console.log('音效播放失败:', e.message);
                }
            }
            
            // 解析扫码数据 (增强版)
            function parseScanResult(data, formatName) {
                console.log('开始解析扫码数据:', { data, formatName });
                
                let results = [];
                let hasMatch = false;
                const formatDisplayName = getFormatDisplayName(formatName);
                
                // 数据预处理 - 清理和标准化
                const cleanData = data.trim().replace(/\s+/g, ' ');
                
                // 1. 智能产品编码识别 (10位数字)
                const productCodePatterns = [
                    /(?:产品编码|物料编码|product|material)[:：\s]*(\d{10})/i,
                    /(?:code|编码)[:：\s]*(\d{10})/i,
                    /\b(\d{10})\b/g  // 任何10位数字
                ];
                
                let productCode = null;
                for (const pattern of productCodePatterns) {
                    const match = cleanData.match(pattern);
                    if (match) {
                        productCode = match[1] || match[0].match(/\d{10}/)[0];
                        break;
                    }
                }
                
                if (productCode) {
                    const currentCode = document.getElementById('currentProductCode').textContent.trim();
                    if (productCode === currentCode) {
                        results.push(`✅ 产品编码: ${productCode} (匹配)`);
                        hasMatch = true;
                    } else {
                        results.push(`❌ 产品编码: ${productCode} (不匹配，期望: ${currentCode})`);
                        // 即使不匹配也继续处理其他信息
                    }
                }
                
                // 2. 智能数量识别
                const quantityPatterns = [
                    /(?:qty|quantity|数量|出库数量)[:：\s]*(\d{1,3})/i,
                    /(\d{1,3})\s*(?:个|件|只|台|套|pcs|pieces)/i,
                    /(?:count|cnt)[:：\s]*(\d{1,3})/i,
                    /(?:共|总|计)\s*(\d{1,3})/i
                ];
                
                let quantity = null;
                for (const pattern of quantityPatterns) {
                    const match = cleanData.match(pattern);
                    if (match) {
                        const num = parseInt(match[1]);
                        if (num > 0 && num <= 999) {
                            quantity = num;
                            break;
                        }
                    }
                }
                
                // 如果没有找到带关键词的数量，尝试纯数字
                if (!quantity && /^\d{1,3}$/.test(cleanData)) {
                    const num = parseInt(cleanData);
                    if (num > 0 && num <= 999) {
                        quantity = num;
                    }
                }
                
                if (quantity) {
                    const quantityInput = document.getElementById('outboundQuantity');
                    if (quantityInput) {
                        const maxQuantity = parseInt(quantityInput.getAttribute('max')) || 999;
                        
                        if (quantity <= maxQuantity) {
                            quantityInput.value = quantity;
                            quantityInput.style.backgroundColor = '#d4edda';
                            quantityInput.style.border = '2px solid #28a745';
                            quantityInput.style.boxShadow = '0 0 10px rgba(40, 167, 69, 0.3)';
                            
                            setTimeout(() => {
                                quantityInput.style.backgroundColor = '';
                                quantityInput.style.border = '';
                                quantityInput.style.boxShadow = '';
                            }, 3000);
                            
                            results.push(`✅ 出库数量: ${quantity}`);
                            hasMatch = true;
                        } else {
                            results.push(`⚠️ 识别数量 ${quantity} 超过剩余库存 ${maxQuantity}`);
                        }
                    }
                }
                
                // 3. 智能WOXPJ编码识别
                const woxpjPatterns = [
                    /WOXPJ\d*[-－—]\s*(\d{3})/i,
                    /WOXPJ\s*(\d{3})/i,
                    /woxpj\d*[-－—]\s*(\d{3})/i,
                    /woxpj\s*(\d{3})/i
                ];
                
                let woxpjCode = null;
                for (const pattern of woxpjPatterns) {
                    const match = cleanData.match(pattern);
                    if (match) {
                        woxpjCode = match[1];
                        break;
                    }
                }
                
                if (woxpjCode) {
                    const remarkInput = document.getElementById('remarkInput');
                    if (remarkInput) {
                        remarkInput.value = woxpjCode;
                        remarkInput.style.backgroundColor = '#d4edda';
                        remarkInput.style.border = '2px solid #28a745';
                        remarkInput.style.boxShadow = '0 0 10px rgba(40, 167, 69, 0.3)';
                        
                        setTimeout(() => {
                            remarkInput.style.backgroundColor = '';
                            remarkInput.style.border = '';
                            remarkInput.style.boxShadow = '';
                        }, 3000);
                        
                        results.push(`✅ 备注编码: ${woxpjCode}`);
                        hasMatch = true;
                    }
                }
                
                // 4. JSON格式数据解析
                try {
                    const jsonData = JSON.parse(cleanData);
                    if (typeof jsonData === 'object') {
                        // 尝试从JSON中提取信息
                        const jsonResults = parseJSONData(jsonData);
                        if (jsonResults.length > 0) {
                            results.push(...jsonResults);
                            hasMatch = true;
                        }
                    }
                } catch (e) {
                    // 不是JSON格式，继续其他解析
                }
                
                // 5. URL格式数据解析
                if (cleanData.startsWith('http') || cleanData.includes('://')) {
                    try {
                        const url = new URL(cleanData);
                        const urlResults = parseURLData(url);
                        if (urlResults.length > 0) {
                            results.push(...urlResults);
                            hasMatch = true;
                        }
                    } catch (e) {
                        // URL解析失败，继续其他解析
                    }
                }
                
                // 显示解析结果
                displayScanResults(cleanData, formatDisplayName, results, hasMatch);
                
                console.log('扫码解析完成:', {
                    originalData: data,
                    cleanData: cleanData,
                    formatName: formatName,
                    productCode: productCode,
                    quantity: quantity,
                    woxpjCode: woxpjCode,
                    results: results,
                    hasMatch: hasMatch
                });
            }
            
            // 解析JSON格式数据
            function parseJSONData(jsonData) {
                const results = [];
                
                // 常见的JSON字段映射
                const fieldMappings = {
                    productCode: ['product_code', 'productCode', 'code', 'id', 'material_code'],
                    quantity: ['quantity', 'qty', 'count', 'amount', 'num'],
                    woxpj: ['woxpj', 'WOXPJ', 'remark', 'note', 'suffix']
                };
                
                // 提取产品编码
                for (const field of fieldMappings.productCode) {
                    if (jsonData[field] && /^\d{10}$/.test(jsonData[field].toString())) {
                        const currentCode = document.getElementById('currentProductCode').textContent.trim();
                        if (jsonData[field].toString() === currentCode) {
                            results.push(`✅ 产品编码: ${jsonData[field]} (JSON匹配)`);
                        } else {
                            results.push(`❌ 产品编码: ${jsonData[field]} (JSON不匹配)`);
                        }
                        break;
                    }
                }
                
                // 提取数量
                for (const field of fieldMappings.quantity) {
                    if (jsonData[field] && !isNaN(jsonData[field])) {
                        const qty = parseInt(jsonData[field]);
                        if (qty > 0 && qty <= 999) {
                            results.push(`✅ 数量: ${qty} (来源JSON)`);
                            // 这里可以添加实际的表单填充逻辑
                            break;
                        }
                    }
                }
                
                return results;
            }
            
            // 解析URL格式数据
            function parseURLData(url) {
                const results = [];
                const params = url.searchParams;
                
                // 检查URL参数中的产品信息
                const productCode = params.get('product_code') || params.get('code') || params.get('id');
                const quantity = params.get('quantity') || params.get('qty');
                const woxpj = params.get('woxpj') || params.get('remark');
                
                if (productCode && /^\d{10}$/.test(productCode)) {
                    results.push(`✅ 产品编码: ${productCode} (来源URL)`);
                }
                
                if (quantity && !isNaN(quantity)) {
                    const qty = parseInt(quantity);
                    if (qty > 0 && qty <= 999) {
                        results.push(`✅ 数量: ${qty} (来源URL)`);
                    }
                }
                
                if (woxpj && /^\d{3}$/.test(woxpj)) {
                    results.push(`✅ WOXPJ: ${woxpj} (来源URL)`);
                }
                
                return results;
            }
            
            // 显示扫码结果
            function displayScanResults(data, formatName, results, hasMatch) {
                // 状态消息
                if (results.length > 0) {
                    const summaryMessage = `
                        <strong>📱 扫码解析结果:</strong><br>
                        ${results.join('<br>')}<br><br>
                        <strong>扫码格式:</strong> ${formatName}<br>
                        <strong>数据长度:</strong> ${data.length} 字符
                    `;
                    
                    setTimeout(() => {
                        showStatus(summaryMessage, hasMatch ? 'success' : 'warning');
                    }, 1000);
                } else {
                    showStatus(`
                        ⚠️ 扫码数据无法解析<br><br>
                        <strong>扫码格式:</strong> ${formatName}<br>
                        <strong>数据内容:</strong> ${data.substring(0, 100)}${data.length > 100 ? '...' : ''}<br>
                        <strong>建议:</strong> 确认条码/二维码包含产品信息
                    `, 'warning');
                }
                
                // OCR结果区域显示
                const resultDiv = document.getElementById('ocrResult');
                if (resultDiv) {
                    resultDiv.style.display = 'block';
                    resultDiv.innerHTML = `
                        <div style="background: #e8f5e8; padding: 15px; border-radius: 5px; border-left: 4px solid #28a745;">
                            <strong>📱 扫码识别结果:</strong><br>
                            <strong>格式:</strong> ${formatName}<br>
                            <strong>数据:</strong> <code style="word-break: break-all;">${data}</code><br><br>
                            <strong>解析结果:</strong><br>
                            ${results.length > 0 ? results.join('<br>') : '<span style="color: #dc3545;">未识别到有效信息</span>'}
                            
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #007bff;">🔍 查看解析详情</summary>
                                <div style="margin-top: 10px; font-size: 12px; color: #666;">
                                    <strong>支持的数据格式:</strong><br>
                                    • 产品编码: 10位数字<br>
                                    • 数量信息: 1-3位数字 + 单位<br>
                                    • WOXPJ编码: WOXPJ + 3位数字<br>
                                    • JSON格式: {"product_code": "1234567890"}<br>
                                    • URL格式: http://example.com?code=1234567890
                                </div>
                            </details>
                        </div>
                    `;
                }
            }
            
            // 增强上传按钮功能
            const uploadBtn = document.getElementById('uploadBtn');
            const fileInput = document.getElementById('fileInput');
            const autoRecognizeBtn = document.getElementById('autoRecognize');
            
            if (uploadBtn && fileInput) {
                uploadBtn.onclick = function() {
                    fileInput.click();
                };
                
                fileInput.onchange = function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        showStatus(`✅ 已选择图片：${file.name}<br>文件大小：${(file.size/1024/1024).toFixed(2)}MB<br>点击"自动识别"开始OCR处理`, 'success');
                        
                        // 启用自动识别按钮
                        if (autoRecognizeBtn) {
                            autoRecognizeBtn.disabled = false;
                            autoRecognizeBtn.innerHTML = '🔍 开始识别';
                            autoRecognizeBtn.style.backgroundColor = '#28a745';
                            
                            // 存储文件引用
                            window.selectedImageFile = file;
                        }
                    }
                };
            }
            
            // 自动识别按钮功能
            if (autoRecognizeBtn) {
                autoRecognizeBtn.onclick = async function() {
                    console.log('🔍 自动识别按钮被点击');
                    
                    if (!window.selectedImageFile) {
                        showStatus('❌ 请先选择图片', 'error');
                        return;
                    }
                    
                    try {
                        this.disabled = true;
                        this.innerHTML = '🔄 识别中...';
                        showStatus('🔄 正在进行OCR识别，请稍候...', 'processing');
                        
                        // 执行OCR识别
                        await performOCR(window.selectedImageFile);
                        
                    } catch (error) {
                        console.error('OCR识别失败:', error);
                        showStatus(`❌ OCR识别失败: ${error.message}`, 'error');
                    } finally {
                        this.disabled = false;
                        this.innerHTML = '🔍 重新识别';
                    }
                };
            }
            
            // 图像预处理函数 - 提高OCR识别准确率
            async function preprocessImage(imageFile) {
                return new Promise((resolve) => {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    const img = new Image();
                    
                    img.onload = function() {
                        // 设置画布尺寸
                        canvas.width = img.width;
                        canvas.height = img.height;
                        
                        // 绘制原始图像
                        ctx.drawImage(img, 0, 0);
                        
                        // 获取图像数据
                        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                        const data = imageData.data;
                        
                        // 图像增强处理
                        for (let i = 0; i < data.length; i += 4) {
                            // 转换为灰度
                            const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
                            
                            // 增强对比度和亮度
                            let enhanced = gray;
                            
                            // 亮度调整
                            enhanced = enhanced * 1.2 + 20;
                            
                            // 对比度增强
                            enhanced = ((enhanced - 128) * 1.5) + 128;
                            
                            // 二值化处理 - 提高数字识别准确率
                            enhanced = enhanced > 140 ? 255 : 0;
                            
                            // 应用处理结果
                            data[i] = enhanced;     // R
                            data[i + 1] = enhanced; // G
                            data[i + 2] = enhanced; // B
                            // data[i + 3] 保持不变 (Alpha)
                        }
                        
                        // 将处理后的数据放回画布
                        ctx.putImageData(imageData, 0, 0);
                        
                        // 转换为Blob并返回
                        canvas.toBlob((blob) => {
                            console.log('图像预处理完成');
                            resolve(blob);
                        }, 'image/png', 1.0);
                    };
                    
                    img.src = URL.createObjectURL(imageFile);
                });
            }
            
            // OCR识别函数 - 优化数字识别准确率
            async function performOCR(imageFile) {
                try {
                    // 检查Tesseract.js是否加载
                    if (typeof Tesseract === 'undefined') {
                        throw new Error('OCR库未加载，请刷新页面重试');
                    }
                    
                    showStatus('🔄 初始化OCR引擎...', 'processing');
                    
                    // 图像预处理以提高识别准确率
                    const preprocessedImage = await preprocessImage(imageFile);
                    
                    // 优化的OCR配置 - 专门针对数字识别
                    const ocrOptions = {
                        logger: m => {
                            if (m.status === 'recognizing text') {
                                const progress = Math.round(m.progress * 100);
                                showStatus(`🔄 识别进度: ${progress}%`, 'processing');
                            }
                        },
                        // Tesseract配置参数 - 优化数字识别
                        tessedit_pageseg_mode: '6', // 单一文本块
                        tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz物料编码数量个件只台套WOXPJ：:-', // 限制字符集
                        preserve_interword_spaces: '1', // 保留单词间空格
                        tessedit_do_invert: '0', // 不反转图像
                        load_system_dawg: '0', // 不加载系统词典
                        load_freq_dawg: '0', // 不加载频率词典
                    };
                    
                    // 执行OCR识别
                    const { data: { text, confidence } } = await Tesseract.recognize(
                        preprocessedImage,
                        'chi_sim+eng', // 中英文识别
                        ocrOptions
                    );
                    
                    console.log('OCR识别完成:', { text, confidence });
                    
                    if (!text || text.trim().length === 0) {
                        throw new Error('未识别到任何文字，请检查图片质量');
                    }
                    
                    // 显示识别结果和调试信息
                    const resultDiv = document.getElementById('ocrResult');
                    if (resultDiv) {
                        resultDiv.style.display = 'block';
                        resultDiv.innerHTML = `
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 10px;">
                                <strong>📄 OCR识别结果 (置信度: ${Math.round(confidence)}%):</strong><br>
                                <pre style="background: white; padding: 10px; border-radius: 3px; margin: 10px 0;">${text}</pre>
                                
                                <details style="margin-top: 10px;">
                                    <summary style="cursor: pointer; color: #007bff; font-weight: bold;">🔍 数量识别调试信息</summary>
                                    <div id="quantityDebug" style="margin-top: 10px; font-size: 12px; color: #666;">
                                        <em>解析完成后显示...</em>
                                    </div>
                                </details>
                            </div>
                        `;
                    }
                    
                    // 解析识别结果
                    parseOCRResult(text);
                    
                    showStatus(`✅ OCR识别完成！置信度: ${Math.round(confidence)}%`, 'success');
                    
                } catch (error) {
                    console.error('OCR处理错误:', error);
                    throw error;
                }
            }
            
            // 解析OCR结果 - 根据实际标签格式定制
            function parseOCRResult(text) {
                console.log('开始解析OCR结果:', text);
                
                let results = [];
                let hasMatch = false;
                
                // 1. 识别物料编码：物 料 编 码 : 后面10位数字
                const materialCodePatterns = [
                    /物\s*料\s*编\s*码\s*[:：]\s*(\d{10})/g,
                    /物料编码\s*[:：]\s*(\d{10})/g,
                    /物\s*料\s*名\s*称\s*[:：]\s*(\d{10})/g,
                    /物料名称\s*[:：]\s*(\d{10})/g,
                    /\b(\d{10})\b/g  // 备用：任何10位数字
                ];
                
                let materialCode = null;
                for (const pattern of materialCodePatterns) {
                    const match = text.match(pattern);
                    if (match) {
                        materialCode = match[0].match(/(\d{10})/)[1];
                        console.log('识别到物料编码:', materialCode);
                        break;
                    }
                }
                
                // 验证物料编码与当前出库产品编码
                if (materialCode) {
                    const currentCode = document.getElementById('currentProductCode').textContent.trim();
                    
                    if (materialCode === currentCode) {
                        showStatus(`✅ 物料编码匹配成功: ${materialCode}`, 'success');
                        results.push(`✅ 物料编码: ${materialCode} (匹配)`);
                        hasMatch = true;
                    } else {
                        showStatus(`❌ 物料编码不匹配<br><strong>当前计划:</strong> ${currentCode}<br><strong>识别结果:</strong> ${materialCode}<br><br>⚠️ 请确认是否为正确的产品`, 'error');
                        results.push(`❌ 物料编码: ${materialCode} (不匹配，期望: ${currentCode})`);
                        // 即使不匹配也继续处理其他信息
                    }
                }
                
                // 2. 识别出库数量：多种模式识别，提高准确率
                const quantityPatterns = [
                    // 精确匹配模式 - 优先级最高
                    { pattern: /出\s*库\s*数\s*量\s*[:：]\s*(\d{1,3})(?!\d)/g, priority: 1, name: '出库数量' },
                    { pattern: /数\s*量\s*[:：]\s*(\d{1,3})(?!\d)/g, priority: 2, name: '数量' },
                    { pattern: /qty\s*[:：]\s*(\d{1,3})(?!\d)/gi, priority: 3, name: 'QTY' },
                    { pattern: /quantity\s*[:：]\s*(\d{1,3})(?!\d)/gi, priority: 4, name: 'Quantity' },
                    
                    // 单位后缀模式
                    { pattern: /(\d{1,3})\s*个(?!\d)/g, priority: 5, name: '个' },
                    { pattern: /(\d{1,3})\s*件(?!\d)/g, priority: 6, name: '件' },
                    { pattern: /(\d{1,3})\s*只(?!\d)/g, priority: 7, name: '只' },
                    { pattern: /(\d{1,3})\s*台(?!\d)/g, priority: 8, name: '台' },
                    { pattern: /(\d{1,3})\s*套(?!\d)/g, priority: 9, name: '套' },
                    { pattern: /(\d{1,3})\s*pcs(?!\d)/gi, priority: 10, name: 'pcs' },
                    
                    // 宽松匹配模式 - 最后尝试
                    { pattern: /(?:共|总|计)\s*(\d{1,3})(?!\d)/g, priority: 11, name: '总计' },
                    { pattern: /(\d{1,3})(?=\s*(?:个|件|只|台|套|pcs))/gi, priority: 12, name: '数字+单位' }
                ];
                
                let quantityResults = [];
                
                // 按优先级尝试所有模式
                for (const { pattern, priority, name } of quantityPatterns) {
                    const matches = [...text.matchAll(pattern)];
                    
                    for (const match of matches) {
                        const num = parseInt(match[1]);
                        if (num > 0 && num <= 999) {
                            quantityResults.push({
                                value: num,
                                priority: priority,
                                source: name,
                                matchText: match[0].trim(),
                                confidence: calculateQuantityConfidence(match[0], name)
                            });
                            console.log(`识别到数量候选: ${num} (来源: ${name}, 匹配: "${match[0].trim()}")`);
                        }
                    }
                }
                
                // 选择最佳数量结果
                let quantity = null;
                let bestMatch = null;
                
                if (quantityResults.length > 0) {
                    // 按优先级和置信度排序
                    quantityResults.sort((a, b) => {
                        if (a.priority !== b.priority) return a.priority - b.priority;
                        return b.confidence - a.confidence;
                    });
                    
                    bestMatch = quantityResults[0];
                    quantity = bestMatch.value;
                    
                    console.log('最佳数量匹配:', bestMatch);
                    
                    // 如果有多个候选，显示所有选项
                    if (quantityResults.length > 1) {
                        const alternatives = quantityResults.slice(1, 3).map(r => 
                            `${r.value}(${r.source})`
                        ).join(', ');
                        console.log(`其他数量候选: ${alternatives}`);
                    }
                }
                
                // 数量置信度计算函数
                function calculateQuantityConfidence(matchText, source) {
                    let confidence = 50; // 基础置信度
                    
                    // 根据匹配源调整置信度
                    const sourceBonus = {
                        '出库数量': 30,
                        '数量': 25,
                        'QTY': 20,
                        'Quantity': 20,
                        '个': 15,
                        '件': 15,
                        '只': 10,
                        '台': 10,
                        '套': 10,
                        'pcs': 15,
                        '总计': 5,
                        '数字+单位': 5
                    };
                    
                    confidence += sourceBonus[source] || 0;
                    
                    // 根据匹配文本特征调整
                    if (matchText.includes('出库')) confidence += 10;
                    if (matchText.includes('数量')) confidence += 8;
                    if (/\d+\s*[个件只台套]/.test(matchText)) confidence += 5;
                    
                    return Math.min(confidence, 100);
                }
                
                // 自动填充出库数量（增强版）
                if (quantity && quantity > 0 && quantity <= 999) {
                    const quantityInput = document.getElementById('outboundQuantity');
                    if (quantityInput) {
                        // 检查是否超过剩余库存
                        const maxQuantity = parseInt(quantityInput.getAttribute('max')) || 999;
                        
                        if (quantity <= maxQuantity) {
                            quantityInput.value = quantity;
                            quantityInput.style.backgroundColor = '#d4edda';
                            quantityInput.style.border = '2px solid #28a745';
                            quantityInput.style.boxShadow = '0 0 10px rgba(40, 167, 69, 0.3)';
                            
                            setTimeout(() => {
                                quantityInput.style.backgroundColor = '';
                                quantityInput.style.border = '';
                                quantityInput.style.boxShadow = '';
                            }, 3000);
                            
                            // 详细的成功信息
                            const confidenceText = bestMatch ? ` (置信度: ${bestMatch.confidence}%, 来源: ${bestMatch.source})` : '';
                            results.push(`✅ 出库数量: ${quantity}${confidenceText}`);
                            
                            // 如果有多个候选，提供选择
                            if (quantityResults.length > 1) {
                                const alternatives = quantityResults.slice(1, 3);
                                const altText = alternatives.map(r => `${r.value}(${r.source})`).join(', ');
                                results.push(`💡 其他识别选项: ${altText}`);
                            }
                            
                            hasMatch = true;
                        } else {
                            results.push(`⚠️ 识别数量 ${quantity} 超过剩余库存 ${maxQuantity}`);
                            
                            // 提供库存范围内的建议
                            const suggestedQty = Math.min(quantity, maxQuantity);
                            if (suggestedQty > 0) {
                                results.push(`💡 建议数量: ${suggestedQty} (库存范围内)`);
                                
                                // 可选：自动填充建议数量
                                quantityInput.value = suggestedQty;
                                quantityInput.style.backgroundColor = '#fff3cd';
                                quantityInput.style.border = '2px solid #ffc107';
                                
                                setTimeout(() => {
                                    quantityInput.style.backgroundColor = '';
                                    quantityInput.style.border = '';
                                }, 3000);
                            }
                        }
                    }
                } else if (quantityResults.length > 0) {
                    // 有识别结果但不在有效范围内
                    const invalidResults = quantityResults.filter(r => r.value <= 0 || r.value > 999);
                    if (invalidResults.length > 0) {
                        results.push(`⚠️ 识别到无效数量: ${invalidResults.map(r => r.value).join(', ')} (超出范围1-999)`);
                    }
                }
                
                // 3. 识别WOXPJ编码，提取最后的三位数字，自动填充到备注
                const woxpjPatterns = [
                    // 新格式：WOXPJ25100300445-024 (提取最后的024)
                    { pattern: /WOXPJ\d+[-－—](\d{3})(?!\d)/gi, priority: 1, name: 'WOXPJ长编码-后缀' },
                    
                    // 标准格式：WOXPJ-024 或 WOXPJ 024
                    { pattern: /WOXPJ\s*[-－—]\s*(\d{3})(?!\d)/gi, priority: 2, name: 'WOXPJ-标准' },
                    { pattern: /WOXPJ\s+(\d{3})(?!\d)/gi, priority: 3, name: 'WOXPJ 空格' },
                    
                    // 简化格式：WOXPJ024
                    { pattern: /WOXPJ(\d{3})(?!\d)/gi, priority: 4, name: 'WOXPJ直连' },
                    
                    // 小写格式
                    { pattern: /woxpj\d+[-－—](\d{3})(?!\d)/gi, priority: 5, name: 'woxpj长编码-后缀' },
                    { pattern: /woxpj\s*[-－—]\s*(\d{3})(?!\d)/gi, priority: 6, name: 'woxpj-标准' },
                    { pattern: /woxpj\s+(\d{3})(?!\d)/gi, priority: 7, name: 'woxpj 空格' },
                    { pattern: /woxpj(\d{3})(?!\d)/gi, priority: 8, name: 'woxpj直连' }
                ];
                
                let woxpjResults = [];
                
                // 尝试所有WOXPJ模式
                for (const { pattern, priority, name } of woxpjPatterns) {
                    const matches = [...text.matchAll(pattern)];
                    
                    for (const match of matches) {
                        const code = match[1];
                        if (code && /^\d{3}$/.test(code)) {
                            woxpjResults.push({
                                code: code,
                                priority: priority,
                                source: name,
                                matchText: match[0].trim(),
                                confidence: calculateWOXPJConfidence(match[0], name)
                            });
                            console.log(`识别到WOXPJ候选: ${code} (来源: ${name}, 匹配: "${match[0].trim()}")`);
                        }
                    }
                }
                
                // 选择最佳WOXPJ结果
                let woxpjCode = null;
                let bestWoxpjMatch = null;
                
                if (woxpjResults.length > 0) {
                    // 按优先级和置信度排序
                    woxpjResults.sort((a, b) => {
                        if (a.priority !== b.priority) return a.priority - b.priority;
                        return b.confidence - a.confidence;
                    });
                    
                    bestWoxpjMatch = woxpjResults[0];
                    woxpjCode = bestWoxpjMatch.code;
                    
                    console.log('最佳WOXPJ匹配:', bestWoxpjMatch);
                    
                    // 如果有多个候选，显示所有选项
                    if (woxpjResults.length > 1) {
                        const alternatives = woxpjResults.slice(1, 3).map(r => 
                            `${r.code}(${r.source})`
                        ).join(', ');
                        console.log(`其他WOXPJ候选: ${alternatives}`);
                    }
                }
                
                // WOXPJ置信度计算函数
                function calculateWOXPJConfidence(matchText, source) {
                    let confidence = 50; // 基础置信度
                    
                    // 根据匹配源调整置信度
                    const sourceBonus = {
                        'WOXPJ长编码-后缀': 40,  // 最高优先级，符合新格式
                        'WOXPJ-标准': 35,
                        'WOXPJ 空格': 30,
                        'WOXPJ直连': 25,
                        'woxpj长编码-后缀': 35,
                        'woxpj-标准': 30,
                        'woxpj 空格': 25,
                        'woxpj直连': 20
                    };
                    
                    confidence += sourceBonus[source] || 0;
                    
                    // 根据匹配文本特征调整
                    if (matchText.includes('-')) confidence += 10;  // 有分隔符更可靠
                    if (/WOXPJ\d{8,}[-－—]\d{3}/.test(matchText)) confidence += 15;  // 长编码格式
                    if (matchText.toUpperCase().includes('WOXPJ')) confidence += 5;
                    
                    return Math.min(confidence, 100);
                }
                
                // 自动填充备注（WOXPJ编码的最后3位数字）
                if (woxpjCode) {
                    const remarkInput = document.getElementById('remarkInput');
                    if (remarkInput) {
                        remarkInput.value = woxpjCode;
                        remarkInput.style.backgroundColor = '#d4edda';
                        remarkInput.style.border = '2px solid #28a745';
                        remarkInput.style.boxShadow = '0 0 10px rgba(40, 167, 69, 0.3)';
                        
                        setTimeout(() => {
                            remarkInput.style.backgroundColor = '';
                            remarkInput.style.border = '';
                            remarkInput.style.boxShadow = '';
                        }, 3000);
                        
                        // 详细的成功信息
                        const confidenceText = bestWoxpjMatch ? ` (置信度: ${bestWoxpjMatch.confidence}%, 来源: ${bestWoxpjMatch.source})` : '';
                        results.push(`✅ 备注编码: ${woxpjCode}${confidenceText}`);
                        
                        // 如果有多个候选，提供选择
                        if (woxpjResults.length > 1) {
                            const alternatives = woxpjResults.slice(1, 3);
                            const altText = alternatives.map(r => `${r.code}(${r.source})`).join(', ');
                            results.push(`💡 其他WOXPJ选项: ${altText}`);
                        }
                        
                        hasMatch = true;
                    }
                } else if (woxpjResults.length > 0) {
                    // 有识别结果但格式不正确
                    const invalidResults = woxpjResults.filter(r => !/^\d{3}$/.test(r.code));
                    if (invalidResults.length > 0) {
                        results.push(`⚠️ 识别到无效WOXPJ格式: ${invalidResults.map(r => r.code).join(', ')} (需要3位数字)`);
                    }
                }
                
                // 显示解析结果摘要
                if (results.length > 0) {
                    const summaryMessage = `
                        <strong>📋 解析结果摘要:</strong><br>
                        ${results.join('<br>')}
                        <br><br>
                        ${hasMatch ? '✅ 信息已自动填充到相应字段' : '⚠️ 未找到可填充的信息'}
                    `;
                    
                    setTimeout(() => {
                        showStatus(summaryMessage, hasMatch ? 'success' : 'warning');
                    }, 1000);
                } else {
                    showStatus(`
                        ⚠️ 未识别到有效信息<br><br>
                        <strong>请确认图片包含以下格式:</strong><br>
                        • 物料编码: 1234567890 (10位数字)<br>
                        • 出库数量: 123 (1-3位数字)<br>
                        • WOXPJ-123 或 WOXPJ123 (3位数字)
                    `, 'warning');
                }
                
                // 更新调试面板
                const debugDiv = document.getElementById('quantityDebug');
                if (debugDiv) {
                    let debugContent = '';
                    
                    // 数量识别调试信息
                    if (quantityResults.length > 0) {
                        const quantityDebugInfo = quantityResults.map((r, i) => 
                            `${i + 1}. <strong>${r.value}</strong> (来源: ${r.source}, 置信度: ${r.confidence}%, 匹配: "${r.matchText}")`
                        ).join('<br>');
                        
                        debugContent += `
                            <strong>🔢 数量识别详情:</strong><br>
                            ${quantityDebugInfo}<br><br>
                            <strong>📊 最终选择:</strong> ${quantity || '无'} ${bestMatch ? `(${bestMatch.source})` : ''}<br>
                        `;
                    } else {
                        debugContent += `
                            <strong>🔢 数量识别详情:</strong><br>
                            <span style="color: #dc3545;">未识别到有效数量信息</span><br>
                        `;
                    }
                    
                    // WOXPJ识别调试信息
                    if (woxpjResults.length > 0) {
                        const woxpjDebugInfo = woxpjResults.map((r, i) => 
                            `${i + 1}. <strong>${r.code}</strong> (来源: ${r.source}, 置信度: ${r.confidence}%, 匹配: "${r.matchText}")`
                        ).join('<br>');
                        
                        debugContent += `
                            <br><strong>🏷️ WOXPJ识别详情:</strong><br>
                            ${woxpjDebugInfo}<br><br>
                            <strong>📊 最终选择:</strong> ${woxpjCode || '无'} ${bestWoxpjMatch ? `(${bestWoxpjMatch.source})` : ''}<br>
                        `;
                    } else {
                        debugContent += `
                            <br><strong>🏷️ WOXPJ识别详情:</strong><br>
                            <span style="color: #dc3545;">未识别到WOXPJ编码</span><br>
                        `;
                    }
                    
                    debugContent += `
                        <br><strong>🎯 识别策略:</strong> 优先级排序 + 置信度评估<br>
                        <strong>💡 支持格式:</strong><br>
                        • 数量: "数量: 50个", "qty: 25", "100件"<br>
                        • WOXPJ: "WOXPJ25100300445-024", "WOXPJ-123", "WOXPJ 456"
                    `;
                    
                    debugDiv.innerHTML = debugContent;
                }
                
                // 在控制台输出详细的调试信息
                console.log('OCR解析完成:', {
                    materialCode: materialCode,
                    quantity: quantity,
                    quantityResults: quantityResults,
                    bestMatch: bestMatch,
                    woxpjCode: woxpjCode,
                    results: results,
                    hasMatch: hasMatch
                });
            }
        };
    </script>
    
    <script>
        // 相机控制组件类
        class CameraController {
            constructor(videoElement, canvasElement) {
                this.video = videoElement;
                this.canvas = canvasElement;
                this.ctx = this.canvas.getContext('2d');
                this.stream = null;
                this.isActive = false;
                this.constraints = {
                    video: {
                        facingMode: 'environment',
                        width: { ideal: 1280 },
                        height: { ideal: 720 }
                    }
                };
            }

            // 检查相机支持
            isSupported() {
                return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
            }

            // 启动相机
            async startCamera() {
                if (!this.isSupported()) {
                    throw new Error('您的浏览器不支持相机功能');
                }

                if (this.isActive) {
                    return; // 相机已经启动
                }

                try {
                    // 先尝试后置摄像头（安卓优化）
                    let constraints = {
                        video: {
                            facingMode: { exact: 'environment' },
                            width: { ideal: 1280, max: 1920 },
                            height: { ideal: 720, max: 1080 }
                        }
                    };

                    try {
                        this.stream = await navigator.mediaDevices.getUserMedia(constraints);
                    } catch (error) {
                        // 如果后置摄像头失败，尝试任意摄像头
                        console.warn('后置摄像头不可用，尝试使用任意摄像头:', error);
                        constraints = {
                            video: {
                                facingMode: 'environment',
                                width: { ideal: 1280 },
                                height: { ideal: 720 }
                            }
                        };
                        this.stream = await navigator.mediaDevices.getUserMedia(constraints);
                    }

                    this.video.srcObject = this.stream;
                    this.isActive = true;

                    // 等待视频加载，增加超时处理
                    return new Promise((resolve, reject) => {
                        const timeout = setTimeout(() => {
                            reject(new Error('视频加载超时，请检查相机权限'));
                        }, 10000);

                        this.video.onloadedmetadata = () => {
                            clearTimeout(timeout);
                            // 确保视频开始播放
                            this.video.play().then(() => {
                                resolve();
                            }).catch((playError) => {
                                console.warn('视频自动播放失败:', playError);
                                resolve(); // 即使播放失败也继续，用户可以手动点击播放
                            });
                        };

                        this.video.onerror = (error) => {
                            clearTimeout(timeout);
                            reject(new Error('视频加载失败: ' + error.message));
                        };
                    });
                } catch (error) {
                    this.handleCameraError(error);
                    throw error;
                }
            }

            // 关闭相机
            stopCamera() {
                if (this.stream) {
                    this.stream.getTracks().forEach(track => track.stop());
                    this.video.srcObject = null;
                    this.stream = null;
                    this.isActive = false;
                }
            }

            // 拍照
            capturePhoto() {
                if (!this.isActive || !this.video.videoWidth) {
                    throw new Error('相机未启动或视频未加载');
                }

                this.canvas.width = this.video.videoWidth;
                this.canvas.height = this.video.videoHeight;
                this.ctx.drawImage(this.video, 0, 0);

                return new Promise((resolve) => {
                    this.canvas.toBlob((blob) => {
                        resolve(blob);
                    }, 'image/jpeg', 0.9);
                });
            }

            // 处理相机错误
            handleCameraError(error) {
                let message = '相机访问失败';
                let suggestions = [];

                switch (error.name) {
                    case 'NotAllowedError':
                        message = '❌ 相机权限被拒绝';
                        suggestions = [
                            '1. 点击地址栏左侧的🔒或📷图标',
                            '2. 选择"允许"相机权限',
                            '3. 刷新页面重试',
                            '4. 如果是安卓Chrome，检查系统设置→应用→Chrome→权限→相机'
                        ];
                        break;
                    case 'NotFoundError':
                        message = '❌ 未找到可用的相机设备';
                        suggestions = [
                            '1. 确认设备有摄像头',
                            '2. 检查其他应用是否占用相机',
                            '3. 重启浏览器或设备'
                        ];
                        break;
                    case 'NotSupportedError':
                        message = '❌ 浏览器不支持相机功能';
                        suggestions = [
                            '1. 使用Chrome、Firefox或Safari最新版本',
                            '2. 确保使用HTTPS访问',
                            '3. 更新浏览器到最新版本'
                        ];
                        break;
                    case 'NotReadableError':
                        message = '❌ 相机被其他应用占用';
                        suggestions = [
                            '1. 关闭其他使用相机的应用',
                            '2. 重启浏览器',
                            '3. 检查系统相机应用是否在后台运行'
                        ];
                        break;
                    case 'OverconstrainedError':
                        message = '❌ 相机配置不支持';
                        suggestions = [
                            '1. 设备相机不支持请求的分辨率',
                            '2. 将自动尝试降低画质重试'
                        ];
                        break;
                    case 'AbortError':
                        message = '❌ 相机启动被中断';
                        suggestions = [
                            '1. 请重新点击启动相机',
                            '2. 确保网络连接稳定'
                        ];
                        break;
                    default:
                        message = `❌ 相机错误: ${error.message}`;
                        suggestions = [
                            '1. 刷新页面重试',
                            '2. 重启浏览器',
                            '3. 使用"选择图片"功能作为替代方案'
                        ];
                }

                // 在控制台显示详细错误信息
                console.error('Camera error details:', {
                    name: error.name,
                    message: error.message,
                    stack: error.stack,
                    suggestions: suggestions
                });

                // 返回用户友好的错误信息
                const fullMessage = message + '\n\n💡 解决方案:\n' + suggestions.join('\n');
                return fullMessage;
            }

            // 获取相机状态
            getStatus() {
                return {
                    isActive: this.isActive,
                    isSupported: this.isSupported(),
                    hasStream: !!this.stream
                };
            }
        }

        // 初始化组件
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const cameraController = new CameraController(video, canvas);
        const currentProductCode = document.getElementById('currentProductCode').textContent.trim();

        // 从备注中提取库位（提取后4位数字）
        function extractLocationFromRemark(remark) {
            if (!remark) return null;
            // 提取所有数字
            const digits = remark.match(/\d/g);
            if (!digits || digits.length < 4) return null;
            // 取最后4位
            const lastFour = digits.slice(-4).join('');
            // 分成前2位和后2位，去掉前导0
            const firstPart = parseInt(lastFour.substring(0, 2));
            const secondPart = parseInt(lastFour.substring(2, 4));
            return firstPart + '-' + secondPart;
        }

        // 页面加载时检查相机支持
        document.addEventListener('DOMContentLoaded', function() {
            const startCameraBtn = document.getElementById('startCamera');
            
            // 备注库位预览功能
            const remarkInput = document.getElementById('remarkInput');
            const locationPreview = document.getElementById('locationPreview');
            const locationPreviewText = document.getElementById('locationPreviewText');
            
            if (remarkInput && locationPreview && locationPreviewText) {
                remarkInput.addEventListener('input', function() {
                    const location = extractLocationFromRemark(this.value);
                    if (location) {
                        locationPreviewText.textContent = location;
                        locationPreview.style.display = 'block';
                    } else {
                        locationPreview.style.display = 'none';
                    }
                });
                
                // 初始检查
                if (remarkInput.value) {
                    const location = extractLocationFromRemark(remarkInput.value);
                    if (location) {
                        locationPreviewText.textContent = location;
                        locationPreview.style.display = 'block';
                    }
                }
            }
            
            // 数量验证和提醒功能
            const outboundQuantity = document.getElementById('outboundQuantity');
            const quantityWarning = document.getElementById('quantityWarning');
            const remainingQuantity = document.getElementById('remainingQuantity');
            const submitBtn = document.querySelector('button[type="submit"]');
            const maxQuantity = <?php echo $plan['planned_quantity'] - $plan['total_outbound']; ?>;
            
            if (outboundQuantity && quantityWarning && remainingQuantity) {
                outboundQuantity.addEventListener('input', function() {
                    const value = parseInt(this.value) || 0;
                    const remaining = parseInt(remainingQuantity.textContent) || 0;
                    
                    if (value > remaining) {
                        quantityWarning.style.display = 'block';
                        this.style.borderColor = '#dc3545';
                        if (submitBtn) submitBtn.disabled = true;
                    } else if (value > 0) {
                        quantityWarning.style.display = 'none';
                        this.style.borderColor = '#28a745';
                        if (submitBtn) submitBtn.disabled = false;
                    } else {
                        quantityWarning.style.display = 'none';
                        this.style.borderColor = '';
                        if (submitBtn) submitBtn.disabled = false;
                    }
                });
            }
            
            // 出库前二次确认
            const outboundForm = document.querySelector('form[method="POST"]');
            if (outboundForm && submitBtn) {
                outboundForm.addEventListener('submit', function(e) {
                    const quantity = parseInt(outboundQuantity?.value) || 0;
                    const remark = remarkInput?.value || '';
                    const location = extractLocationFromRemark(remark);
                    const remaining = parseInt(remainingQuantity?.textContent) || 0;
                    
                    if (quantity <= 0) {
                        e.preventDefault();
                        alert('出库数量必须大于0！');
                        return false;
                    }
                    
                    if (quantity > remaining) {
                        e.preventDefault();
                        alert(`出库数量（${quantity}）不能超过剩余数量（${remaining}）！`);
                        return false;
                    }
                    
                    // 显示确认对话框
                    let confirmMsg = `确认出库信息：\n\n`;
                    confirmMsg += `产品编码：<?php echo htmlspecialchars($plan['product_code']); ?>\n`;
                    confirmMsg += `出库数量：${quantity}\n`;
                    confirmMsg += `剩余数量：${remaining}\n`;
                    confirmMsg += `备注：${remark}\n`;
                    if (location) {
                        confirmMsg += `库位：${location}\n`;
                    }
                    confirmMsg += `\n确认提交吗？`;
                    
                    if (!confirm(confirmMsg)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }
            
            // 检查基本支持
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                startCameraBtn.disabled = true;
                startCameraBtn.innerHTML = '❌ 不支持相机';
                startCameraBtn.title = '您的浏览器不支持相机功能，请使用最新版Chrome、Firefox或Safari';
                showStatus('⚠️ 浏览器不支持相机，请使用"选择图片"功能', 'warning');
                return;
            }

            // 检查HTTPS
            if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
                startCameraBtn.innerHTML = '🔒 需要HTTPS';
                startCameraBtn.title = '相机功能需要HTTPS环境';
                showStatus('⚠️ 相机功能需要HTTPS环境，当前可使用"选择图片"功能', 'warning');
                return;
            }

            // 检查设备类型并给出提示
            const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            if (isMobile) {
                showStatus('📱 移动设备检测到，点击"启动相机"时请允许相机权限', 'success');
            }
        });

        // 检查HTTPS和相机支持
        function checkCameraSupport() {
            // 检查HTTPS
            if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
                showStatus('⚠️ 相机功能需要HTTPS环境，请使用HTTPS访问或在本地环境测试', 'warning');
                return false;
            }

            // 检查浏览器支持
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                showStatus('❌ 您的浏览器不支持相机功能，请使用Chrome、Firefox或Safari最新版本', 'error');
                return false;
            }

            return true;
        }

        // 添加调试功能
        function debugLog(message, data = null) {
            console.log(`[OCR Debug] ${message}`, data);
            // 在页面上也显示调试信息（开发时使用）
            if (window.location.search.includes('debug=1')) {
                const debugDiv = document.getElementById('debugInfo') || (() => {
                    const div = document.createElement('div');
                    div.id = 'debugInfo';
                    div.style.cssText = 'position:fixed;top:10px;right:10px;background:rgba(0,0,0,0.8);color:white;padding:10px;border-radius:5px;font-size:12px;max-width:300px;z-index:9999;';
                    document.body.appendChild(div);
                    return div;
                })();
                debugDiv.innerHTML = `${new Date().toLocaleTimeString()}: ${message}<br>` + debugDiv.innerHTML.split('<br>').slice(0, 10).join('<br>');
            }
        }

        // 相机控制按钮事件处理函数
        async function handleCameraButtonClick(event) {
            console.log('启动相机按钮被点击', event);
            const button = document.getElementById('startCamera');

            // 检查基本支持
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                showStatus('❌ 浏览器不支持相机功能', 'error');
                return;
            }

            // 检查HTTPS
            const isSecure = location.protocol === 'https:' || 
                            location.hostname === 'localhost' || 
                            location.hostname === '127.0.0.1';
            
            if (!isSecure) {
                showStatus('❌ 相机功能需要HTTPS环境', 'error');
                return;
            }

            if (cameraController.isActive) {
                // 关闭相机
                cameraController.stopCamera();
                button.textContent = '📷 启动相机';
                button.className = 'btn btn-primary';
                document.getElementById('autoRecognize').disabled = true;
                showStatus('相机已关闭', 'success');
            } else {
                // 启动相机
                button.disabled = true;
                showStatus('🔄 正在请求相机权限...', 'processing');

                try {
                    await cameraController.startCamera();
                    button.textContent = '❌ 关闭相机';
                    button.className = 'btn btn-danger';
                    document.getElementById('autoRecognize').disabled = false;
                    showStatus('✅ 相机启动成功，可以开始拍照识别', 'success');
                } catch (error) {
                    const errorMessage = cameraController.handleCameraError(error);
                    showStatus(errorMessage, 'error');
                    console.error('Camera start error:', error);
                    
                    // 提供备选方案
                    setTimeout(() => {
                        showStatus('💡 您可以使用"选择图片"功能上传照片进行识别', 'warning');
                    }, 3000);
                } finally {
                    button.disabled = false;
                }
            }
        }
        }

        // 简单的测试函数
        function testCameraClick() {
            console.log('🎉 相机按钮被点击了！');
            alert('相机按钮点击成功！\n\n现在开始启动相机...');
            
            // 显示状态
            const statusDiv = document.getElementById('recognitionStatus');
            if (statusDiv) {
                statusDiv.style.display = 'block';
                statusDiv.className = 'recognition-status status-success';
                statusDiv.textContent = '✅ 按钮点击成功！正在启动相机...';
            }
            
            // 实际启动相机
            startCameraFunction();
        }
        
        // 实际的相机启动函数
        async function startCameraFunction() {
            const button = document.getElementById('startCamera');
            
            try {
                // 检查基本支持
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    throw new Error('浏览器不支持相机功能');
                }

                // 检查HTTPS
                const isSecure = location.protocol === 'https:' || 
                                location.hostname === 'localhost' || 
                                location.hostname === '127.0.0.1';
                
                if (!isSecure) {
                    throw new Error('相机功能需要HTTPS环境');
                }

                console.log('开始请求相机权限...');
                button.disabled = true;
                button.textContent = '🔄 启动中...';
                
                // 尝试启动相机
                const stream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        facingMode: 'environment',
                        width: { ideal: 640 },
                        height: { ideal: 480 }
                    }
                });
                
                const video = document.getElementById('video');
                video.srcObject = stream;
                
                button.textContent = '❌ 关闭相机';
                button.className = 'btn btn-danger';
                
                console.log('✅ 相机启动成功！');
                alert('相机启动成功！');
                
            } catch (error) {
                console.error('相机启动失败:', error);
                alert('相机启动失败: ' + error.message);
                
                button.textContent = '📷 启动相机';
                button.className = 'btn btn-primary';
            } finally {
                button.disabled = false;
            }
        }

        // 页面加载完成后的初始化
        window.addEventListener('load', function() {
            console.log('页面完全加载完成');
            
            const startCameraBtn = document.getElementById('startCamera');
            if (startCameraBtn) {
                console.log('✅ 找到相机按钮，按钮已准备就绪');
                console.log('按钮文本:', startCameraBtn.textContent);
                console.log('按钮类名:', startCameraBtn.className);
                
                // 显示准备就绪消息
                const statusDiv = document.getElementById('recognitionStatus');
                if (statusDiv) {
                    statusDiv.style.display = 'block';
                    statusDiv.className = 'recognition-status status-success';
                    statusDiv.textContent = '✅ 相机功能已准备就绪，请点击"启动相机"按钮测试';
                }
            } else {
                console.error('❌ 找不到相机按钮');
            }
        });
        // 拍照按钮事件处理函数
        async function handleCaptureButtonClick(event) {
            debugLog('拍照按钮被点击', { event });
            if (!cameraController.isActive) {
                showStatus('请先启动相机', 'error');
                return;
            }

            try {
                showStatus('正在拍照...', 'processing');

                // 添加拍照闪光效果
                const cameraContainer = document.querySelector('.camera-container');
                cameraContainer.classList.add('capture-success');
                setTimeout(() => cameraContainer.classList.remove('capture-success'), 300);

                // 播放拍照音效（如果支持）
                try {
                    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
                    audio.volume = 0.3;
                    audio.play().catch(() => { }); // 忽略音频播放错误
                } catch (e) { }

                const blob = await cameraController.capturePhoto();

                // 显示预览
                showPhotoPreview(blob);
                showStatus('拍照成功！请确认照片或重新拍照', 'success');

            } catch (error) {
                showStatus('拍照失败: ' + error.message, 'error');
                console.error('Capture error:', error);
            }
        }

        // 自动识别按钮事件
        document.getElementById('autoRecognize').addEventListener('click', async function () {
            if (!cameraController.isActive) {
                showStatus('请先启动相机', 'error');
                return;
            }

            try {
                showStatus('正在拍照识别...', 'processing');
                const blob = await cameraController.capturePhoto();
                recognizeText(blob);
            } catch (error) {
                showStatus('拍照识别失败：' + error.message, 'error');
            }
        });

        // 选择图片按钮事件
        document.getElementById('uploadBtn').addEventListener('click', function () {
            document.getElementById('fileInput').click();
        });

        // 文件选择事件
        document.getElementById('fileInput').addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                // 验证文件类型
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(file.type)) {
                    showStatus('请选择有效的图片文件 (JPG, PNG, GIF)', 'error');
                    return;
                }

                // 验证文件大小 (最大10MB)
                if (file.size > 10 * 1024 * 1024) {
                    showStatus('图片文件过大，请选择小于10MB的图片', 'error');
                    return;
                }

                showStatus('正在处理图片...', 'processing');
                recognizeText(file);
            }
        });
        // 降级和替代方案器
        class FallbackHandler {
           ructor() {
          this.fallba
    ameraUnavailable
                       Failed    cons
      tructor() {  networkOffline: 
                    retry   nt: 0,
          thi       maxRs.erro: 3
          rLo   };
      g = []; 
           .initNetworkMg();
          
            
            // 初     this.maxLogSize = 100;
            initNet    Monitoring         this.retryAttempts = new Map();
                // 监听网络    
                win   this.maxRListener('online', () =>etries = 3;
                    this.    backState    workOffline = false      this.retryDelay = 1000; // 1秒
                    this.handle   store();
            );
              
              winListener('off> {
             thislbackState.networkOftrue;
                dleNetworkOffline();
    });
           
                // 初始网络状态            this.errorTypes = {
                this.fallbackS        workOffline = !n   CAMERA_ELine;
       RROR: 'camera',
            
            // 处理相  可用的降级方案
            h  OCR_ERRraFallbacOR: 'ocr',
                t     allbackSt           navailable =     ;
             NETWORK_ERROR: 'network',
                c         g('相机降级处理:', erro       VALIDATION_ERROR: 'validation',
                                 FORM_ERROR: 'form',
                // 隐                   IMAGE_PROCESSING_ERROR: 'image_processing',
                const st   CameraBtn = documen        mentById('s      PERa');
  MISS     ION_ERROR: captureBtn = d'pement.getElemenrmyId('captureBtn');ission',
                         UNKNOWN_ERROR: 'unknown'
                          ameraBtn) {
     };           startCameraBtn.le.display =
                          
                if (captureBtn) {           this.errorSeverity = {
                     aptureBt        LOWplay = 'none';
 :              }'low',
                
               ME/ 突出显示图片上传选项
   DIUM:        this.hig'medium',Option();
       
                                  HIGH: 'high',
                const fal         CRe = this.getCameraFaITICAL: 'crie(error.nameti
                showStatucal'Message, 'warning');
                
                // 添加降级状态指示
                this.  owFallbackInd  };amera', '相可用，已切换);
        }
            
       // 获取相机降级提示信
            g           lbackMessage(err     {
       const messa = {
                'NotAllowed: '相机权限被拒绝，请"功能上传照片
                    '      this.rr': '未检测到相机ecoveryStr片"功能上传照片进行识别',
ategies = {        'NotSuppo: '浏览器不支持相机功能，请使用择图片"功能上传照片进行识别'
                    'NotReada      RETRY'相机被其他应用占用，请使用: 're"功能上传照片进行识别'try',
                };
                
                      Fmessages[errorNALLBACK: 相机暂时不可用，请使用"选择图片'fallb片进行识别';
           ack',
            
                出显示上传选项
            highligh      dOption() {
  USER          _ACTI uploadBtnON: 'useent.getElemenr_actiouploadBtn');
 n',            if (uploa
                    uploadBtn.clas       emove('btn-inf     IGNORE: 'ignore',
                    uploadB        List.add('btn  rimary');
              RELOAD: loadBtn.innerHTML ='reload图片 (推荐)';
    '           
                            };
              uploadBtn.ation = 'pulsite';
             
                    // 3秒后           
                             t(() => {
                         tloadBtn.styhis.init();n = '';
          }, 6000);
            
            }
            
             }R失败的降级方案
         handleOCRFallor, context = {}) 
           llbackState.ocrF= true;
          this.fallbacate.retryC+;
          
                console.log('OCR         iror.message, '重试nit() {his.fallbaryCount);
        
                // 如果还有重试机会
     this.s     if (this.fallbacketupGlobaryCount < this.falErrorHandl.maxRetries) {
 ing()              const retryDe;= this.fallbackStyCount * 1000; // 递增延时
                             this.setupUnhandledRejectionHandling();
                    s         (`OCR识别失败，${retry  lay/1000}秒后自动重试 (${thi  thisbackState.retryC.createErros.fallbackStatrReporetries})`tingarning');
         UI()       
      ;         setTimeout(() => {
              if (cxt.retryFunction) {
                           }xt.ret);
                   
             }, ryDelay);
              
      return fal; // 表示正在重试
      }
           
                //完，提供手动输入选
       .showManualIion();
           owFallbacndicatocr', 'OCR识别失败，输入模式');
              
       urn true; // 表示已
      }
         
            // 显示选项
     showlInputOption() {
     // 聚焦到出库数量输入
                con           // 主要 = document.queryS错误处理方法input[name=uantity"]');
                if (quan     nput) {handleError(error, context = {}) {
                    quantityInput.   cs();
     onst err       quantiorInfo =style.borderColo t= '#007bff';
  hi         s.analyzeantityInputError(eroxShadowror, co 0 0.2rem rgba(0,1ntext5,.25)';
    ); }
             
                // 显示手动输             this.logError(errorInfo);
                co      nualInputTip =       ateElement(
          manualInpu.id = 'manua
                manualutTip.className alert ale-info mt-2';
      manualInputTi = `
                 <str示：</strong><br
                    •             const recovery = this.determineRecoveryStrategy(errorInfo);
                      可在备注中添加   息<br>
                          retur识别，请重新选择图片
  n this.e      `;
  xecuteRec     
  overy(errorI  // 插入到表单区域
           nfo, recoveformContainry);ment.querySelntainer form')
                if (formConta     }ument.getElemnputTip')) {
                 const firstForm = formContainer.quemb-3');
                irstFormGroup) {
              firsparentNode.insertBeforeInputTip, firstFmGroup);
          
        }
            
             // 5秒后自动移除提示
  setTi=> {
               const tip = dment.getElementById('mantTip');
           if (tip) {
             ip.remove();
                }
        if (qtityInput) {
                  quantityInpu.borderColor = '';
                    nput.style.bow = '';
        }
         }, 10000);
   
            
     网络离线状态
        handleNetworkOne() {
         console.log(络离线，启用离线模式'
                      // 分析错误
                        wFallbackIndica    anetwork', '网络连接中断，已启alyzeErr
        or(er   
             ror, co示离线提示
              ntext) {('网络连接中断，当前处于离线模式。在网络恢复后同步。', 'warning'
                
                // 启用离线数据存储
             conshis.enableOft errorInfge();
   o = { }
            
            // 处理网络恢复
            handleNetworkRes  re() {
                console.log('网络已恢复');
                
                this.hideFallbackIndicator('network');
                showStatus('网络连接已恢复', 'success');
                
                // 同步离线数据
                this.syncOfflineData();
            }
            
            // 启用离线存储
            enableOfflineStorage() {
                // 检查localStorage支持
                if (!this.isLocalStorageAvailable()) {
                    showStatus('浏览器不支持离线存储功能', 'error');
                    return;
                }
                
                // 保存当前表单状态
                this.saveFormStateToLocal();
                
                // 修改表单提交行为
                this.modifyFormForOffline();
            }
            
            // 检查localStorage可用性
            isLocalStorageAvailable() {
                try {
                    const test = '__localStorage_test__';
                    localStorage.setItem(test, test);
                    localStorage.removeItem(test);
                    return true;
                } catch (e) {
                    return false;
                }
            }
            
            // 保存表单状态到本地
            saveFormStateToLocal() {
                const formData = {
                    timestamp: Date.now(),
                    data: {}
                };
                
                // 收集表单数据
                const form = document.querySelector('form');
                if (form) {
                    const formElements = form.querySelectorAll('input, select, textarea');
                    formElements.forEach(element => {
                        if (element.name) {
                            formData.data[element.name] = element.value;
                        }
                    });
                }
                
                // 保存到localStorage
                const offlineData = JSON.parse(localStorage.getItem('offlineOutboundData') || '[]');
                offlineData.push(formData);
                localStorage.setItem('offlineOutboundData', JSON.stringify(offlineData));
            }
            
            // 修改表单为离线模式
            modifyFormForOffline() {
                const form = document.querySelector('form');
                if (!form) return;
                
                // 添加离线提交处理
                const originalAction = form.action;
                form.addEventListener('submit', (e) => {
                    if (this.fallbackState.networkOffline) {
                        e.preventDefault();
                        this.handleOfflineSubmit(form);
                    }
                });
            }
            
            // 处理离线提交
            handleOfflineSubmit(form) {
                const formData = new FormData(form);
                const offlineEntry = {
                    timestamp: Date.now(),
                    action: form.action,
                    method: form.method || 'POST',
                    data: {}
                };
                
                // 转换FormData为普通对象
                for (let [key, value] of formData.entries()) {
                    offlineEntry.data[key] = value;
                }
                
                // 保存到离线队列
                const offlineQueue = JSON.parse(localStorage.getItem('offlineSubmissionQueue') || '[]');
                offlineQueue.push(offlineEntry);
                localStorage.setItem('offlineSubmissionQueue', JSON.stringify(offlineQueue));
                
                showStatus('数据已保存到离线队列，网络恢复后将自动提交', 'info');
                
                // 显示离线提交成功反馈
                this.showOfflineSubmitFeedback();
            }
            
            // 显示离线提交反馈
            showOfflineSubmitFeedback() {
                const feedback = document.createElement('div');
                feedback.className = 'alert alert-success mt-3';
                feedback.innerHTML = `
                    <strong>✅ 离线保存成功</strong><br>
                    您的数据已保存到本地，网络恢复后将自动同步到服务器。<br>
                    <small class="text-muted">保存时间: ${new Date().toLocaleString()}</small>
                `;
                
                const container = document.querySelector('.container');
                if (container) {
                    container.insertBefore(feedback, container.firstChild);
                    
                    // 3秒后自动移除
                    setTimeout(() => {
                        feedback.remove();
                    }, 5000);
                }
            }
            
            // 同步离线数据
            async syncOfflineData() {
                const offlineQueue = JSON.parse(localStorage.getItem('offlineSubmissionQueue') || '[]');
                
                if (offlineQueue.length === 0) {
                    return;
                }
                
                showStatus(`正在同步 ${offlineQueue.length} 条离线数据...`, 'processing');
                
                let successCount = 0;
                let failCount = 0;
                
                for (let i = 0; i < offlineQueue.length; i++) {
                    const entry = offlineQueue[i];
                    
                    try {
                        const formData = new FormData();
                        Object.entries(entry.data).forEach(([key, value]) => {
                            formData.append(key, value);
                        });
                        
                        const response = await fetch(entry.action, {
                            method: entry.method,
                            body: formData
                        });
                        
                        if (response.ok) {
                            successCount++;
                        } else {
                            failCount++;
                        }
                    } catch (error) {
                        console.error('同步离线数据失败:', error);
                        failCount++;
                    }
                }
                
                // 清除已同步的数据
                if (successCount > 0) {
                    localStorage.removeItem('offlineSubmissionQueue');
                }
                
                // 显示同步结果
                if (failCount === 0) {
                    showStatus(`离线数据同步完成，成功同步 ${successCount} 条记录`, 'success');
                } else {
                    showStatus(`部分数据同步失败，成功: ${successCount}，失败: ${failCount}`, 'warning');
                }
            }
            
            // 显示降级状态指示器
            showFallbackIndicator(type, message) {
                const indicator = document.createElement('div');
                indicator.id = `fallback-indicator-${type}`;
                indicator.className = 'alert alert-warning alert-dismissible fade show mt-2';
                indicator.innerHTML = `
                    <strong>⚠️ 降级模式:</strong> ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                
                // 插入到页面顶部
                const container = document.querySelector('.container');
                if (container && !document.getElementById(`fallback-indicator-${type}`)) {
                    container.insertBefore(indicator, container.firstChild);
                }
            }
            
            // 隐藏降级状态指示器
            hideFallbackIndicator(type) {
                const indicator = document.getElementById(`fallback-indicator-${type}`);
                if (indicator) {
                    indicator.remove();
                }
            }
            
            // 重置降级状态
            resetFallbackState() {
                this.fallbackState = {
                    cameraUnavailable: false,
                    ocrFailed: false,
                    networkOffline: !navigator.onLine,
                    retryCount: 0,
                    maxRetries: 3
                };
                
                // 移除所有降级指示器
                ['camera', 'ocr', 'network'].forEach(type => {
                    this.hideFallbackIndicator(type);
                });
                
                // 恢复按钮状态
                this.restoreButtonStates();
            }
            
            // 恢复按钮状态
            restoreButtonStates() {
                const startCameraBtn = document.getElementById('startCamera');
                const uploadBtn = document.getElementById('uploadBtn');
                
                if (startCameraBtn && !this.fallbackState.cameraUnavailable) {
                    startCameraBtn.style.display = '';
                }
                
                if (uploadBtn) {
                    uploadBtn.classList.remove('btn-primary');
                    uploadBtn.classList.add('btn-info');
                    uploadBtn.innerHTML = '📁 选择图片';
                    uploadBtn.style.animation = '';
                }
            }
            
            // 获取降级状态报告
            getFallbackStatus() {
                return {
                    cameraUnavailable: this.fallbackState.cameraUnavailable,
                    ocrFailed: this.fallbackState.ocrFailed,
                    networkOffline: this.fallbackState.networkOffline,
                    retryCount: this.fallbackState.retryCount,
                    hasOfflineData: this.hasOfflineData()
                };
            }
            
            // 检查是否有离线数据
            hasOfflineData() {
                const offlineQueue = JSON.parse(localStorage.getItem('offlineSubmissionQueue') || '[]');
                return offlineQueue.length > 0;
            }
        }

        // 错误处理框架
        class ErrorHandler {id: Date.now(),
                    timestamp: new Date(),
                    message: error.message || error.toString(),
                    stack: error.stack,
                    type: this.classifyError(error),
                    severity: this.determineSeverity(error),
                    context: context,
                    userAgent: navigator.userAgent,
                    url: window.location.href,
                    retryCount: this.getRetryCount(context.operation || 'unknown')
                };

                // 添加特定错误的详细信息
                if (error.name) errorInfo.name = error.name;
                if (error.code) errorInfo.code = error.code;
                
                return errorInfo;
            }

            // 错误分类
            classifyError(error) {
                const message = error.message?.toLowerCase() || '';
                const name = error.name?.toLowerCase() || '';

                // 相机错误
                if (name.includes('notallowed') || message.includes('permission')) {
                    return this.errorTypes.PERMISSION_ERROR;
                }
                if (name.includes('notfound') || message.includes('camera') || message.includes('media')) {
                    return this.errorTypes.CAMERA_ERROR;
                }

                // OCR错误
                if (message.includes('tesseract') || message.includes('ocr') || message.includes('recognize')) {
                    return this.errorTypes.OCR_ERROR;
                }

                // 网络错误
                if (message.includes('network') || message.includes('fetch') || name.includes('networkerror')) {
                    return this.errorTypes.NETWORK_ERROR;
                }

                // 图像处理错误
                if (message.includes('image') || message.includes('canvas') || message.includes('blob')) {
                    return this.errorTypes.IMAGE_PROCESSING_ERROR;
                }

                // 验证错误
                if (message.includes('validation') || message.includes('invalid')) {
                    return this.errorTypes.VALIDATION_ERROR;
                }

                // 表单错误
                if (message.includes('form') || message.includes('input')) {
                    return this.errorTypes.FORM_ERROR;
                }

                return this.errorTypes.UNKNOWN_ERROR;
            }

            // 确定错误严重程度
            determineSeverity(error) {
                const type = this.classifyError(error);
                
                switch (type) {
                    case this.errorTypes.PERMISSION_ERROR:
                    case this.errorTypes.CAMERA_ERROR:
                        return this.errorSeverity.HIGH;
                    
                    case this.errorTypes.OCR_ERROR:
                    case this.errorTypes.IMAGE_PROCESSING_ERROR:
                        return this.errorSeverity.MEDIUM;
                    
                    case this.errorTypes.VALIDATION_ERROR:
                    case this.errorTypes.FORM_ERROR:
                        return this.errorSeverity.LOW;
                    
                    case this.errorTypes.NETWORK_ERROR:
                        return this.errorSeverity.MEDIUM;
                    
                    default:
                        return this.errorSeverity.MEDIUM;
                }
            }

            // 确定恢复策略
            determineRecoveryStrategy(errorInfo) {
                const { type, severity, retryCount } = errorInfo;

                // 基于错误类型的策略
                switch (type) {
                    case this.errorTypes.CAMERA_ERROR:
                        return {
                            strategy: this.recoveryStrategies.FALLBACK,
                            action: 'showImageUpload',
                            message: '相机不可用，请使用图片上传功能'
                        };

                    case this.errorTypes.PERMISSION_ERROR:
                        return {
                            strategy: this.recoveryStrategies.USER_ACTION,
                            action: 'requestPermission',
                            message: '需要相机权限，请在浏览器设置中允许访问'
                        };

                    case this.errorTypes.OCR_ERROR:
                        if (retryCount < this.maxRetries) {
                            return {
                                strategy: this.recoveryStrategies.RETRY,
                                action: 'retryOCR',
                                delay: this.retryDelay * (retryCount + 1),
                                message: `OCR识别失败，正在重试 (${retryCount + 1}/${this.maxRetries})`
                            };
                        } else {
                            return {
                                strategy: this.recoveryStrategies.FALLBACK,
                                action: 'manualInput',
                                message: 'OCR识别多次失败，请手动输入信息'
                            };
                        }

                    case this.errorTypes.IMAGE_PROCESSING_ERROR:
                        return {
                            strategy: this.recoveryStrategies.FALLBACK,
                            action: 'skipProcessing',
                            message: '图像处理失败，使用原始图像进行识别'
                        };

                    case this.errorTypes.NETWORK_ERROR:
                        if (retryCount < this.maxRetries) {
                            return {
                                strategy: this.recoveryStrategies.RETRY,
                                action: 'retryNetwork',
                                delay: this.retryDelay * 2,
                                message: '网络错误，正在重试连接'
                            };
                        } else {
                            return {
                                strategy: this.recoveryStrategies.USER_ACTION,
                                action: 'checkConnection',
                                message: '网络连接失败，请检查网络设置'
                            };
                        }

                    case this.errorTypes.VALIDATION_ERROR:
                        return {
                            strategy: this.recoveryStrategies.USER_ACTION,
                            action: 'showValidationError',
                            message: '输入验证失败，请检查输入内容'
                        };

                    default:
                        if (severity === this.errorSeverity.CRITICAL) {
                            return {
                                strategy: this.recoveryStrategies.RELOAD,
                                action: 'reloadPage',
                                message: '发生严重错误，建议刷新页面'
                            };
                        } else {
                            return {
                                strategy: this.recoveryStrategies.IGNORE,
                                action: 'logOnly',
                                message: '发生未知错误，已记录日志'
                            };
                        }
                }
            }

            // 执行恢复策略
            async executeRecovery(errorInfo, recovery) {
                const { strategy, action, delay, message } = recovery;

                // 显示用户友好的错误消息
                this.showUserFriendlyError(errorInfo, message);

                switch (strategy) {
                    case this.recoveryStrategies.RETRY:
                        return this.executeRetry(errorInfo, action, delay);

                    case this.recoveryStrategies.FALLBACK:
                        return this.executeFallback(errorInfo, action);

                    case this.recoveryStrategies.USER_ACTION:
                        return this.requestUserAction(errorInfo, action);

                    case this.recoveryStrategies.RELOAD:
                        return this.executeReload(errorInfo);

                    case this.recoveryStrategies.IGNORE:
                    default:
                        return { success: false, handled: true };
                }
            }

            // 执行重试
            async executeRetry(errorInfo, action, delay = 1000) {
                const operation = errorInfo.context.operation || 'unknown';
                this.incrementRetryCount(operation);

                await new Promise(resolve => setTimeout(resolve, delay));

                try {
                    // 根据操作类型执行重试
                    switch (action) {
                        case 'retryOCR':
                            if (errorInfo.context.retryFunction) {
                                return await errorInfo.context.retryFunction();
                            }
                            break;
                        case 'retryNetwork':
                            if (errorInfo.context.networkFunction) {
                                return await errorInfo.context.networkFunction();
                            }
                            break;
                    }
                    
                    return { success: false, handled: true };
                } catch (retryError) {
                    return this.handleError(retryError, {
                        ...errorInfo.context,
                        isRetry: true
                    });
                }
            }

            // 执行降级方案
            executeFallback(errorInfo, action) {
                switch (action) {
                    case 'showImageUpload':
                        this.showImageUploadOption();
                        break;
                    case 'manualInput':
                        this.showManualInputOption();
                        break;
                    case 'skipProcessing':
                        this.skipImageProcessing();
                        break;
                }
                
                return { success: true, handled: true, fallback: true };
            }

            // 请求用户操作
            requestUserAction(errorInfo, action) {
                switch (action) {
                    case 'requestPermission':
                        this.showPermissionGuide();
                        break;
                    case 'checkConnection':
                        this.showNetworkGuide();
                        break;
                    case 'showValidationError':
                        this.showValidationGuide(errorInfo);
                        break;
                }
                
                return { success: false, handled: true, userActionRequired: true };
            }

            // 执行页面重载
            executeReload(errorInfo) {
                const shouldReload = confirm('发生严重错误，是否刷新页面？');
                if (shouldReload) {
                    window.location.reload();
                }
                return { success: false, handled: true, reloadRequested: shouldReload };
            }

            // 显示用户友好的错误消息
            showUserFriendlyError(errorInfo, message) {
                const { type, severity } = errorInfo;
                
                let statusType = 'error';
                if (severity === this.errorSeverity.LOW) {
                    statusType = 'warning';
                } else if (severity === this.errorSeverity.MEDIUM) {
                    statusType = 'error';
                } else {
                    statusType = 'error';
                }

                showStatus(message, statusType);
                
                // 对于高严重性错误，显示更详细的信息
                if (severity === this.errorSeverity.HIGH || severity === this.errorSeverity.CRITICAL) {
                    setTimeout(() => {
                        this.showDetailedErrorInfo(errorInfo);
                    }, 2000);
                }
            }

            // 显示详细错误信息
            showDetailedErrorInfo(errorInfo) {
                const errorDetails = `
错误类型: ${errorInfo.type}
错误时间: ${errorInfo.timestamp.toLocaleString()}
错误消息: ${errorInfo.message}
重试次数: ${errorInfo.retryCount}

如果问题持续存在，请联系技术支持。
错误ID: ${errorInfo.id}
                `.trim();

                // 创建错误详情对话框
                const errorDialog = document.createElement('div');
                errorDialog.className = 'error-dialog';
                errorDialog.innerHTML = `
                    <div class="error-dialog-content">
                        <h5>错误详情</h5>
                        <pre class="error-details">${errorDetails}</pre>
                        <div class="error-actions">
                            <button class="btn btn-sm btn-secondary" onclick="this.parentElement.parentElement.parentElement.remove()">关闭</button>
                            <button class="btn btn-sm btn-primary" onclick="errorHandler.reportError('${errorInfo.id}')">报告错误</button>
                        </div>
                    </div>
                `;

                errorDialog.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0,0,0,0.5);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 2000;
                `;

                document.body.appendChild(errorDialog);
            }

            // 降级方案实现
            showImageUploadOption() {
                const cameraBtn = document.getElementById('startCamera');
                const captureBtn = document.getElementById('captureBtn');
                
                if (cameraBtn) {
                    cameraBtn.style.display = 'none';
                }
                if (captureBtn) {
                    captureBtn.style.display = 'none';
                }
                
                showStatus('相机不可用，请使用"选择图片"功能上传照片', 'warning');
            }

            showManualInputOption() {
                showStatus('OCR识别失败，请手动输入产品信息', 'warning');
                
                // 聚焦到第一个输入字段
                const firstInput = document.getElementById('outboundQuantity');
                if (firstInput) {
                    firstInput.focus();
                }
            }

            skipImageProcessing() {
                showStatus('图像预处理已跳过，使用原始图像进行识别', 'info');
            }

            // 用户指导实现
            showPermissionGuide() {
                const guide = `
请按以下步骤允许相机权限：
1. 点击地址栏左侧的锁图标
2. 选择"允许"相机权限
3. 刷新页面重试

或者您可以使用"选择图片"功能上传照片。
                `.trim();

                showStatus(guide, 'info');
            }

            showNetworkGuide() {
                const guide = `
网络连接问题，请检查：
1. 网络连接是否正常
2. 防火墙设置
3. 刷新页面重试

如果问题持续，请联系技术支持。
                `.trim();

                showStatus(guide, 'warning');
            }

            showValidationGuide(errorInfo) {
                const message = `输入验证失败：${errorInfo.message}`;
                showStatus(message, 'warning');
            }

            // 重试计数管理
            getRetryCount(operation) {
                return this.retryAttempts.get(operation) || 0;
            }

            incrementRetryCount(operation) {
                const current = this.getRetryCount(operation);
                this.retryAttempts.set(operation, current + 1);
            }

            resetRetryCount(operation) {
                this.retryAttempts.delete(operation);
            }

            // 错误日志记录
            logError(errorInfo) {
                this.errorLog.unshift(errorInfo);
                
                // 限制日志大小
                if (this.errorLog.length > this.maxLogSize) {
                    this.errorLog = this.errorLog.slice(0, this.maxLogSize);
                }

                // 控制台输出
                console.error('Error logged:', errorInfo);
                
                // 更新错误报告UI
                this.updateErrorReportingUI();
            }

            // 全局错误处理设置
            setupGlobalErrorHandling() {
                window.addEventListener('error', (event) => {
                    this.handleError(event.error, {
                        operation: 'global',
                        source: event.filename,
                        line: event.lineno,
                        column: event.colno
                    });
                });
            }

            setupUnhandledRejectionHandling() {
                window.addEventListener('unhandledrejection', (event) => {
                    this.handleError(event.reason, {
                        operation: 'promise_rejection',
                        promise: event.promise
                    });
                });
            }

            // 错误报告UI
            createErrorReportingUI() {
                // 创建错误报告按钮（隐藏，仅在有错误时显示）
                const errorReportBtn = document.createElement('button');
                errorReportBtn.id = 'errorReportBtn';
                errorReportBtn.className = 'btn btn-sm btn-outline-danger';
                errorReportBtn.innerHTML = '⚠️ 错误报告';
                errorReportBtn.style.cssText = `
                    position: fixed;
                    top: 10px;
                    right: 10px;
                    z-index: 1500;
                    display: none;
                `;
                
                errorReportBtn.addEventListener('click', () => {
                    this.showErrorReport();
                });
                
                document.body.appendChild(errorReportBtn);
            }

            updateErrorReportingUI() {
                const errorReportBtn = document.getElementById('errorReportBtn');
                if (errorReportBtn) {
                    errorReportBtn.style.display = this.errorLog.length > 0 ? 'block' : 'none';
                    errorReportBtn.innerHTML = `⚠️ 错误报告 (${this.errorLog.length})`;
                }
            }

            showErrorReport() {
                const recentErrors = this.errorLog.slice(0, 10);
                let reportContent = '最近错误报告：\n\n';
                
                recentErrors.forEach((error, index) => {
                    reportContent += `${index + 1}. ${error.timestamp.toLocaleTimeString()}\n`;
                    reportContent += `   类型: ${error.type}\n`;
                    reportContent += `   消息: ${error.message}\n`;
                    reportContent += `   严重程度: ${error.severity}\n\n`;
                });

                const reportWindow = window.open('', '_blank', 'width=600,height=500');
                reportWindow.document.write(`
                    <html>
                        <head><title>错误报告</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${reportContent}
                        </body>
                    </html>
                `);
            }

            // 错误报告
            reportError(errorId) {
                const error = this.errorLog.find(e => e.id.toString() === errorId);
                if (error) {
                    // 这里可以实现发送错误报告到服务器的逻辑
                    console.log('Reporting error:', error);
                    showStatus('错误报告已发送', 'success', true);
                }
            }

            // 获取错误统计
            getErrorStats() {
                const stats = {
                    totalErrors: this.errorLog.length,
                    errorsByType: {},
                    errorsBySeverity: {},
                    recentErrors: this.errorLog.slice(0, 5)
                };

                this.errorLog.forEach(error => {
                    stats.errorsByType[error.type] = (stats.errorsByType[error.type] || 0) + 1;
                    stats.errorsBySeverity[error.severity] = (stats.errorsBySeverity[error.severity] || 0) + 1;
                });

                return stats;
            }

            // 清除错误日志
            clearErrorLog() {
                this.errorLog = [];
                this.retryAttempts.clear();
                this.updateErrorReportingUI();
                showStatus('错误日志已清除', 'success', true);
            }
        }

        // 降级方案管理器
        class FallbackManager {
            constructor() {
                this.fallbackStrategies = new Map();
                this.currentFallbacks = new Set();
                this.fallbackHistory = [];
                
                this.init();
            }

            init() {
                this.registerFallbackStrategies();
                this.setupFallbackUI();
            }

            // 注册降级策略
            registerFallbackStrategies() {
                // 相机降级策略
                this.fallbackStrategies.set('camera', {
                    name: '相机功能降级',
                    trigger: ['NotAllowedError', 'NotFoundError', 'NotSupportedError'],
                    action: this.activateCameraFallback.bind(this),
                    priority: 1,
                    description: '当相机不可用时，启用图片上传功能'
                });

                // OCR降级策略
                this.fallbackStrategies.set('ocr', {
                    name: 'OCR识别降级',
                    trigger: ['OCR_ERROR', 'RECOGNITION_FAILED'],
                    action: this.activateOCRFallback.bind(this),
                    priority: 2,
                    description: '当OCR识别失败时，提供手动输入选项'
                });

                // 网络降级策略
                this.fallbackStrategies.set('network', {
                    name: '网络功能降级',
                    trigger: ['NetworkError', 'NETWORK_ERROR'],
                    action: this.activateNetworkFallback.bind(this),
                    priority: 3,
                    description: '当网络不可用时，启用离线模式'
                });

                // 图像处理降级策略
                this.fallbackStrategies.set('imageProcessing', {
                    name: '图像处理降级',
                    trigger: ['IMAGE_PROCESSING_ERROR'],
                    action: this.activateImageProcessingFallback.bind(this),
                    priority: 4,
                    description: '当图像处理失败时，跳过预处理步骤'
                });
            }

            // 激活降级方案
            activateFallback(type, context = {}) {
                const strategy = this.fallbackStrategies.get(type);
                if (!strategy) {
                    console.warn(`Unknown fallback type: ${type}`);
                    return false;
                }

                if (this.currentFallbacks.has(type)) {
                    console.log(`Fallback ${type} already active`);
                    return true;
                }

                try {
                    const result = strategy.action(context);
                    if (result) {
                        this.currentFallbacks.add(type);
                        this.recordFallback(type, strategy, context);
                        this.updateFallbackUI();
                        
                        showStatus(`已启用${strategy.name}`, 'info');
                        return true;
                    }
                } catch (error) {
                    console.error(`Failed to activate fallback ${type}:`, error);
                }
                
                return false;
            }

            // 相机降级实现
            activateCameraFallback(context) {
                // 隐藏相机相关按钮
                const cameraBtn = document.getElementById('startCamera');
                const captureBtn = document.getElementById('captureBtn');
                const videoElement = document.getElementById('video');
                
                if (cameraBtn) {
                    cameraBtn.style.display = 'none';
                    cameraBtn.disabled = true;
                }
                
                if (captureBtn) {
                    captureBtn.style.display = 'none';
                    captureBtn.disabled = true;
                }
                
                if (videoElement) {
                    videoElement.style.display = 'none';
                }

                // 突出显示图片上传选项
                const uploadBtn = document.getElementById('imageUpload');
                if (uploadBtn) {
                    uploadBtn.style.cssText += `
                        border: 2px solid #007bff;
                        box-shadow: 0 0 10px rgba(0,123,255,0.3);
                        animation: pulse 2s infinite;
                    `;
                    
                    // 添加提示文本
                    const hint = document.createElement('div');
                    hint.className = 'fallback-hint';
                    hint.innerHTML = '📷 相机不可用，请点击此处上传图片';
                    hint.style.cssText = `
                        color: #007bff;
                        font-size: 0.9em;
                        margin-top: 5px;
                        text-align: center;
                        font-weight: bold;
                    `;
                    
                    uploadBtn.parentNode.insertBefore(hint, uploadBtn.nextSibling);
                }

                // 添加CSS动画
                if (!document.getElementById('fallback-styles')) {
                    const style = document.createElement('style');
                    style.id = 'fallback-styles';
                    style.textContent = `
                        @keyframes pulse {
                            0% { transform: scale(1); }
                            50% { transform: scale(1.05); }
                            100% { transform: scale(1); }
                        }
                    `;
                    document.head.appendChild(style);
                }

                return true;
            }

            // OCR降级实现
            activateOCRFallback(context) {
                // 显示手动输入提示
                const manualInputHint = document.createElement('div');
                manualInputHint.className = 'ocr-fallback-hint alert alert-warning';
                manualInputHint.innerHTML = `
                    <h6>📝 OCR识别失败</h6>
                    <p>请手动输入产品信息，或尝试以下建议：</p>
                    <ul class="mb-2">
                        <li>确保图片清晰，光线充足</li>
                        <li>产品标签完整可见</li>
                        <li>避免反光和阴影</li>
                    </ul>
                    <button class="btn btn-sm btn-primary" onclick="fallbackManager.retryOCR()">重新识别</button>
                    <button class="btn btn-sm btn-secondary" onclick="fallbackManager.showManualInputGuide()">输入指南</button>
                `;

                // 插入到表单上方
                const form = document.querySelector('form');
                if (form) {
                    form.parentNode.insertBefore(manualInputHint, form);
                }

                // 聚焦到第一个输入字段并高亮
                const quantityInput = document.getElementById('outboundQuantity');
                if (quantityInput) {
                    quantityInput.focus();
                    quantityInput.style.cssText += `
                        border: 2px solid #ffc107;
                        box-shadow: 0 0 5px rgba(255,193,7,0.5);
                    `;
                }

                return true;
            }

            // 网络降级实现
            activateNetworkFallback(context) {
                // 启用离线模式提示
                const offlineHint = document.createElement('div');
                offlineHint.className = 'network-fallback-hint alert alert-info';
                offlineHint.innerHTML = `
                    <h6>🌐 网络连接问题</h6>
                    <p>已启用离线模式，您可以：</p>
                    <ul class="mb-2">
                        <li>继续使用本地OCR识别功能</li>
                        <li>数据将在网络恢复后同步</li>
                        <li>避免使用需要网络的功能</li>
                    </ul>
                    <button class="btn btn-sm btn-info" onclick="fallbackManager.checkNetworkStatus()">检查网络</button>
                `;

                document.body.insertBefore(offlineHint, document.body.firstChild);

                // 禁用需要网络的功能
                this.disableNetworkFeatures();

                return true;
            }

            // 图像处理降级实现
            activateImageProcessingFallback(context) {
                showStatus('图像预处理已跳过，直接进行OCR识别', 'warning');
                
                // 设置标志跳过图像处理
                window.skipImageProcessing = true;
                
                return true;
            }

            // 禁用网络功能
            disableNetworkFeatures() {
                // 这里可以禁用需要网络的特定功能
                // 例如：在线验证、云端同步等
                console.log('Network features disabled due to connectivity issues');
            }

            // 重试OCR
            retryOCR() {
                const lastImage = window.lastCapturedImage || window.lastUploadedImage;
                if (lastImage && window.ocrEngine) {
                    showStatus('正在重新识别...', 'processing');
                    window.ocrEngine.recognizeText(lastImage)
                        .then(result => {
                            showStatus('重新识别成功', 'success');
                            // 处理识别结果
                        })
                        .catch(error => {
                            showStatus('重新识别失败', 'error');
                        });
                } else {
                    showStatus('没有可重新识别的图片', 'warning');
                }
            }

            // 显示手动输入指南
            showManualInputGuide() {
                const guide = `
手动输入指南：

1. 出库数量：
   - 输入需要出库的产品数量
   - 必须为正整数
   - 不能超过计划剩余数量

2. 备注信息：
   - 输入产品相关信息
   - 可包含产品编码、批次等
   - 建议格式：产品编码-批次-其他信息

3. 输入技巧：
   - 仔细核对产品标签信息
   - 使用Tab键快速切换字段
   - 输入完成后点击提交
                `.trim();

                alert(guide);
            }

            // 检查网络状态
            async checkNetworkStatus() {
                try {
                    const response = await fetch(window.location.href, { 
                        method: 'HEAD',
                        cache: 'no-cache'
                    });
                    
                    if (response.ok) {
                        showStatus('网络连接已恢复', 'success');
                        this.deactivateFallback('network');
                    } else {
                        showStatus('网络仍然不可用', 'warning');
                    }
                } catch (error) {
                    showStatus('网络检查失败', 'error');
                }
            }

            // 停用降级方案
            deactivateFallback(type) {
                if (!this.currentFallbacks.has(type)) {
                    return false;
                }

                this.currentFallbacks.delete(type);
                
                // 移除相关UI元素
                document.querySelectorAll(`.${type}-fallback-hint`).forEach(el => el.remove());
                document.querySelectorAll('.fallback-hint').forEach(el => el.remove());
                
                // 恢复原始状态
                this.restoreOriginalState(type);
                
                this.updateFallbackUI();
                
                const strategy = this.fallbackStrategies.get(type);
                if (strategy) {
                    showStatus(`已停用${strategy.name}`, 'info');
                }
                
                return true;
            }

            // 恢复原始状态
            restoreOriginalState(type) {
                switch (type) {
                    case 'camera':
                        const cameraBtn = document.getElementById('startCamera');
                        const captureBtn = document.getElementById('captureBtn');
                        const videoElement = document.getElementById('video');
                        
                        if (cameraBtn) {
                            cameraBtn.style.display = '';
                            cameraBtn.disabled = false;
                        }
                        if (captureBtn) {
                            captureBtn.style.display = '';
                            captureBtn.disabled = false;
                        }
                        if (videoElement) {
                            videoElement.style.display = '';
                        }
                        break;
                        
                    case 'ocr':
                        const quantityInput = document.getElementById('outboundQuantity');
                        if (quantityInput) {
                            quantityInput.style.border = '';
                            quantityInput.style.boxShadow = '';
                        }
                        break;
                        
                    case 'network':
                        window.skipImageProcessing = false;
                        break;
                }
            }

            // 记录降级历史
            recordFallback(type, strategy, context) {
                this.fallbackHistory.push({
                    type,
                    strategy: strategy.name,
                    timestamp: new Date(),
                    context,
                    active: true
                });
            }

            // 设置降级UI
            setupFallbackUI() {
                // 创建降级状态指示器
                const fallbackIndicator = document.createElement('div');
                fallbackIndicator.id = 'fallbackIndicator';
                fallbackIndicator.className = 'fallback-indicator';
                fallbackIndicator.style.cssText = `
                    position: fixed;
                    bottom: 10px;
                    left: 10px;
                    background: #f8f9fa;
                    border: 1px solid #dee2e6;
                    border-radius: 5px;
                    padding: 10px;
                    font-size: 0.8em;
                    z-index: 1000;
                    display: none;
                    max-width: 300px;
                `;
                
                document.body.appendChild(fallbackIndicator);
            }

            // 更新降级UI
            updateFallbackUI() {
                const indicator = document.getElementById('fallbackIndicator');
                if (!indicator) return;

                if (this.currentFallbacks.size === 0) {
                    indicator.style.display = 'none';
                    return;
                }

                let content = '<strong>当前降级方案：</strong><br>';
                this.currentFallbacks.forEach(type => {
                    const strategy = this.fallbackStrategies.get(type);
                    if (strategy) {
                        content += `• ${strategy.name}<br>`;
                    }
                });

                indicator.innerHTML = content;
                indicator.style.display = 'block';
            }

            // 获取降级状态
            getFallbackStatus() {
                return {
                    activeFallbacks: Array.from(this.currentFallbacks),
                    fallbackHistory: this.fallbackHistory,
                    availableStrategies: Array.from(this.fallbackStrategies.keys())
                };
            }
        }

        // 离线处理器
        class OfflineHandler {
            constructor() {
                this.isOnline = navigator.onLine;
                this.offlineQueue = [];
                this.offlineData = new Map();
                this.syncInProgress = false;
                
                this.init();
            }

            init() {
                this.setupNetworkListeners();
                this.setupOfflineStorage();
                this.createOfflineUI();
            }

            // 设置网络监听
            setupNetworkListeners() {
                window.addEventListener('online', () => {
                    this.isOnline = true;
                    this.handleOnline();
                });

                window.addEventListener('offline', () => {
                    this.isOnline = false;
                    this.handleOffline();
                });
            }

            // 处理上线事件
            handleOnline() {
                showStatus('网络连接已恢复', 'success');
                this.updateOfflineUI();
                
                // 自动同步离线数据
                if (this.offlineQueue.length > 0) {
                    this.syncOfflineData();
                }
            }

            // 处理离线事件
            handleOffline() {
                showStatus('网络连接已断开，已启用离线模式', 'warning');
                this.updateOfflineUI();
                
                // 激活网络降级方案
                if (window.fallbackManager) {
                    window.fallbackManager.activateFallback('network');
                }
            }

            // 设置离线存储
            setupOfflineStorage() {
                // 检查localStorage支持
                if (typeof Storage === 'undefined') {
                    console.warn('LocalStorage not supported, offline functionality limited');
                    return;
                }

                // 加载离线队列
                const savedQueue = localStorage.getItem('offlineQueue');
                if (savedQueue) {
                    try {
                        this.offlineQueue = JSON.parse(savedQueue);
                    } catch (error) {
                        console.error('Failed to load offline queue:', error);
                        this.offlineQueue = [];
                    }
                }
            }

            // 添加离线操作
            addOfflineOperation(operation) {
                const offlineOp = {
                    id: Date.now(),
                    timestamp: new Date().toISOString(),
                    type: operation.type,
                    data: operation.data,
                    retryCount: 0,
                    maxRetries: 3
                };

                this.offlineQueue.push(offlineOp);
                this.saveOfflineQueue();
                this.updateOfflineUI();

                showStatus(`操作已保存到离线队列 (${this.offlineQueue.length})`, 'info');
            }

            // 同步离线数据
            async syncOfflineData() {
                if (this.syncInProgress || !this.isOnline || this.offlineQueue.length === 0) {
                    return;
                }

                this.syncInProgress = true;
                showStatus('正在同步离线数据...', 'processing');

                const successfulSyncs = [];
                const failedSyncs = [];

                for (const operation of this.offlineQueue) {
                    try {
                        const result = await this.syncOperation(operation);
                        if (result.success) {
                            successfulSyncs.push(operation);
                        } else {
                            operation.retryCount++;
                            if (operation.retryCount >= operation.maxRetries) {
                                failedSyncs.push(operation);
                            }
                        }
                    } catch (error) {
                        console.error('Sync operation failed:', error);
                        operation.retryCount++;
                        if (operation.retryCount >= operation.maxRetries) {
                            failedSyncs.push(operation);
                        }
                    }
                }

                // 移除成功同步的操作
                successfulSyncs.forEach(op => {
                    const index = this.offlineQueue.indexOf(op);
                    if (index > -1) {
                        this.offlineQueue.splice(index, 1);
                    }
                });

                // 移除失败次数过多的操作
                failedSyncs.forEach(op => {
                    const index = this.offlineQueue.indexOf(op);
                    if (index > -1) {
                        this.offlineQueue.splice(index, 1);
                    }
                });

                this.saveOfflineQueue();
                this.syncInProgress = false;
                this.updateOfflineUI();

                if (successfulSyncs.length > 0) {
                    showStatus(`成功同步 ${successfulSyncs.length} 个操作`, 'success');
                }

                if (failedSyncs.length > 0) {
                    showStatus(`${failedSyncs.length} 个操作同步失败`, 'error');
                }
            }

            // 同步单个操作
            async syncOperation(operation) {
                switch (operation.type) {
                    case 'outbound_record':
                        return await this.syncOutboundRecord(operation.data);
                    case 'ocr_result':
                        return await this.syncOCRResult(operation.data);
                    default:
                        console.warn(`Unknown operation type: ${operation.type}`);
                        return { success: false };
                }
            }

            // 同步出库记录
            async syncOutboundRecord(data) {
                try {
                    const formData = new FormData();
                    Object.keys(data).forEach(key => {
                        formData.append(key, data[key]);
                    });

                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        body: formData
                    });

                    return { success: response.ok };
                } catch (error) {
                    console.error('Failed to sync outbound record:', error);
                    return { success: false };
                }
            }

            // 同步OCR结果
            async syncOCRResult(data) {
                // 这里可以实现OCR结果的同步逻辑
                // 例如：发送到分析服务器进行统计
                return { success: true };
            }

            // 保存离线队列
            saveOfflineQueue() {
                try {
                    localStorage.setItem('offlineQueue', JSON.stringify(this.offlineQueue));
                } catch (error) {
                    console.error('Failed to save offline queue:', error);
                }
            }

            // 创建离线UI
            createOfflineUI() {
                const offlineStatus = document.createElement('div');
                offlineStatus.id = 'offlineStatus';
                offlineStatus.className = 'offline-status';
                offlineStatus.style.cssText = `
                    position: fixed;
                    top: 10px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: #dc3545;
                    color: white;
                    padding: 8px 16px;
                    border-radius: 20px;
                    font-size: 0.8em;
                    z-index: 1500;
                    display: none;
                `;
                
                document.body.appendChild(offlineStatus);
            }

            // 更新离线UI
            updateOfflineUI() {
                const offlineStatus = document.getElementById('offlineStatus');
                if (!offlineStatus) return;

                if (!this.isOnline) {
                    offlineStatus.innerHTML = `🔌 离线模式 | 队列: ${this.offlineQueue.length}`;
                    offlineStatus.style.display = 'block';
                } else {
                    offlineStatus.style.display = 'none';
                }
            }

            // 获取离线状态
            getOfflineStatus() {
                return {
                    isOnline: this.isOnline,
                    queueLength: this.offlineQueue.length,
                    syncInProgress: this.syncInProgress,
                    offlineQueue: this.offlineQueue
                };
            }

            // 清除离线数据
            clearOfflineData() {
                this.offlineQueue = [];
                this.saveOfflineQueue();
                this.updateOfflineUI();
                showStatus('离线数据已清除', 'success');
            }
        }

        // 手动输入助手
        class ManualInputHelper {
            constructor() {
                this.inputPatterns = {
                    productCode: /^\d{10}$/,
                    quantity: /^\d+$/,
                    woxpjCode: /^WOXPJ\d+$/i
                };
                
                this.suggestions = new Map();
                this.inputHistory = [];
                
                this.init();
            }

            init() {
                this.setupInputValidation();
                this.setupAutoComplete();
                this.loadInputHistory();
            }

            // 设置输入验证
            setupInputValidation() {
                const quantityInput = document.getElementById('outboundQuantity');
                const remarkInput = document.getElementById('remark');

                if (quantityInput) {
                    quantityInput.addEventListener('input', (e) => {
                        this.validateQuantityInput(e.target);
                    });
                    
                    quantityInput.addEventListener('blur', (e) => {
                        this.finalizeQuantityInput(e.target);
                    });
                }

                if (remarkInput) {
                    remarkInput.addEventListener('input', (e) => {
                        this.validateRemarkInput(e.target);
                    });
                    
                    remarkInput.addEventListener('keydown', (e) => {
                        this.handleRemarkKeydown(e);
                    });
                }
            }

            // 验证数量输入
            validateQuantityInput(input) {
                const value = input.value.trim();
                const isValid = this.inputPatterns.quantity.test(value);
                
                // 实时反馈
                if (value && !isValid) {
                    input.style.borderColor = '#dc3545';
                    this.showInputHint(input, '请输入有效的数字', 'error');
                } else if (value && isValid) {
                    const quantity = parseInt(value);
                    const maxQuantity = this.getMaxQuantity();
                    
                    if (quantity > maxQuantity) {
                        input.style.borderColor = '#ffc107';
                        this.showInputHint(input, `数量不能超过 ${maxQuantity}`, 'warning');
                    } else {
                        input.style.borderColor = '#28a745';
                        this.showInputHint(input, '✓ 数量有效', 'success');
                    }
                } else {
                    input.style.borderColor = '';
                    this.hideInputHint(input);
                }
            }

            // 完成数量输入
            finalizeQuantityInput(input) {
                const value = input.value.trim();
                if (value) {
                    this.recordInputHistory('quantity', value);
                }
            }

            // 验证备注输入
            validateRemarkInput(input) {
                const value = input.value.trim();
                
                // 检测产品编码模式
                const productCodeMatch = value.match(/\d{10}/);
                if (productCodeMatch) {
                    this.highlightProductCode(input, productCodeMatch[0]);
                }
                
                // 检测WOXPJ编码
                const woxpjMatch = value.match(/WOXPJ\d+/i);
                if (woxpjMatch) {
                    this.highlightWOXPJCode(input, woxpjMatch[0]);
                }
                
                // 提供输入建议
                this.showInputSuggestions(input, value);
            }

            // 处理备注键盘事件
            handleRemarkKeydown(e) {
                // Tab键自动完成
                if (e.key === 'Tab' && this.currentSuggestion) {
                    e.preventDefault();
                    e.target.value = this.currentSuggestion;
                    this.hideInputSuggestions();
                }
                
                // 上下箭头选择建议
                if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                    this.navigateSuggestions(e.key === 'ArrowUp' ? -1 : 1);
                    e.preventDefault();
                }
            }

            // 高亮产品编码
            highlightProductCode(input, code) {
                this.showInputHint(input, `检测到产品编码: ${code}`, 'info');
            }

            // 高亮WOXPJ编码
            highlightWOXPJCode(input, code) {
                this.showInputHint(input, `检测到WOXPJ编码: ${code}`, 'info');
            }

            // 显示输入建议
            showInputSuggestions(input, value) {
                if (value.length < 2) {
                    this.hideInputSuggestions();
                    return;
                }

                const suggestions = this.getSuggestions(value);
                if (suggestions.length === 0) {
                    this.hideInputSuggestions();
                    return;
                }

                this.createSuggestionList(input, suggestions);
            }

            // 获取输入建议
            getSuggestions(value) {
                const suggestions = [];
                
                // 从历史记录中获取建议
                this.inputHistory.forEach(item => {
                    if (item.value.toLowerCase().includes(value.toLowerCase())) {
                        suggestions.push(item.value);
                    }
                });
                
                // 添加常用模式建议
                if (/^\d+$/.test(value)) {
                    suggestions.push(`${value} - 产品编码`);
                }
                
                if (/^WOXPJ/i.test(value)) {
                    suggestions.push(`${value.toUpperCase()} - 工单编码`);
                }
                
                return [...new Set(suggestions)].slice(0, 5);
            }

            // 创建建议列表
            createSuggestionList(input, suggestions) {
                this.hideSuggestionList();
                
                const suggestionList = document.createElement('div');
                suggestionList.className = 'input-suggestions';
                suggestionList.style.cssText = `
                    position: absolute;
                    top: 100%;
                    left: 0;
                    right: 0;
                    background: white;
                    border: 1px solid #ccc;
                    border-top: none;
                    max-height: 150px;
                    overflow-y: auto;
                    z-index: 1000;
                `;
                
                suggestions.forEach((suggestion, index) => {
                    const item = document.createElement('div');
                    item.className = 'suggestion-item';
                    item.textContent = suggestion;
                    item.style.cssText = `
                        padding: 8px 12px;
                        cursor: pointer;
                        border-bottom: 1px solid #eee;
                    `;
                    
                    item.addEventListener('mouseenter', () => {
                        this.highlightSuggestion(index);
                    });
                    
                    item.addEventListener('click', () => {
                        input.value = suggestion;
                        this.hideInputSuggestions();
                        input.focus();
                    });
                    
                    suggestionList.appendChild(item);
                });
                
                // 设置相对定位容器
                const container = input.parentNode;
                if (container.style.position !== 'relative') {
                    container.style.position = 'relative';
                }
                
                container.appendChild(suggestionList);
                this.currentSuggestionList = suggestionList;
                this.currentSuggestions = suggestions;
                this.selectedSuggestionIndex = -1;
            }

            // 隐藏建议列表
            hideSuggestionList() {
                if (this.currentSuggestionList) {
                    this.currentSuggestionList.remove();
                    this.currentSuggestionList = null;
                }
            }

            // 导航建议
            navigateSuggestions(direction) {
                if (!this.currentSuggestions || this.currentSuggestions.length === 0) {
                    return;
                }
                
                this.selectedSuggestionIndex += direction;
                
                if (this.selectedSuggestionIndex < 0) {
                    this.selectedSuggestionIndex = this.currentSuggestions.length - 1;
                } else if (this.selectedSuggestionIndex >= this.currentSuggestions.length) {
                    this.selectedSuggestionIndex = 0;
                }
                
                this.highlightSuggestion(this.selectedSuggestionIndex);
                this.currentSuggestion = this.currentSuggestions[this.selectedSuggestionIndex];
            }

            // 高亮建议项
            highlightSuggestion(index) {
                const items = document.querySeleor = '#007bff';
     ctorAll('.         it {
            }
               wInputHint(input, message,      = 'info')      }
                t              int(input);
        /nt.style.c/      cossTexnst hin 显示输入提.createEleme
                    top:   0%; 8px;
        border-radi: 3px;
                         `
                //              white-space: n -index: 1000;
                    ch (type) {
                        h         .backgroundColo  ca      ror;
     ':         hinite';
              break;
            hint       case:.style.baColor = '#ffc10
                     nt.style '#21252
           pa       case 'success'      break;
                        hint.style.bafon  undColor =un#17a2b8';
       dColo            hintr = '#28  or = 'white';
                }
         t:  }
                
                setTimeou     cone
              r.自动隐藏s.hideInputHi
              app, 3000);endChild(hint
            }
示
            hideIHint(input) {
              const constingHint) {ta= input.parentNode;
                    existingHint consve();
    t           }
            }ions() {t();
         this.currenuggeststion = tions = nulnu
                thll;ectedSuggestiox = -
            }
       this.curr
            /this.hideSuggestion
e               con type,
        st history  value,ate(),
               frequency: 1
             
                // 检查是否已存};inlue
             exist       in cy++;stamp = new Date()
                } epush(historym);
            }
                /        uency -story = this a.frtHistory0);
       }
      
                this.saveInputH
            }

        // 加载输入
            loa }
   }
       
      
            getMaxQuantity() {
     // 获取      // 从页面中获取最大允许最大Outbound ||
                ret      th.max(0, p     cotity - totalOutbound数量   lanQuantity =       /nt(document.query/ dector('[data-totaocument.qd]')?.dataset.tu  输入历史put hi'[data-plan-quantitystorytaset.planQuant;
     c      }自动完成
            setute() {
            /           this.showR inputsputs(input);
                .forE/;
              完成功能.qut =ener('focus> {=> {
            }this.inputHist
                }
                });
  ilter         tats.mostFrequennputHistory
                  .slice(0, ( 10);
     +  }

        so   }理器
   r     t((aurn stats;
       , b) => b.fre1;.tamp)
             freHi    story
         que        .sort((ncy)=> b.timestam
                 .slice(0,Inputs = this.i
                s                    item =>, rec = inpuamp - a.timestampentInpu
                t输入统计
                  (stats.inputsByType[
                  recentIn       ][item.typ
                th  stats.inpuis.inputHis        Each(item => {
                 tFrequent: [],
     eSu     iggesnputsByTyptnputStats()io.inputHish,
           
                    totalInputs:         = {
                         thi           if (recentIn  ts.length > 0) {
 n   ap(item     (0,.valu 3)
                .sort((a, b) => b'; recentInpu
            
            // 显示最近输入put.name || 'unk
       uer  showRecentInputType = input.id |puts(in      input.addEventySelectorAll('ie="text"], input[ter"], textarea');
                
           const inputs = doc
        /
 onst totaund = pars
                } catch (error)or('Failedd   veInputHistory() if (saved) Inp         It   {ey:',m('inp(this.inputHistory));
uistor error        c);
                     ocalS     e.setItem('input       ', JSON.s         y');  this.inputHistory
                        t rror) {'Failed to load i
                thisionsole.estory = JSON.parse(try {orage.g
                } catch            }
           .inpu const saved = local             this.inpif (story.sort((a, b) this.i      thiry.lengths.in00) {
        putHis
                    existing.freqd(item =(existing) {> 
        item.t && item.value 
                const   stins.inputHis
    recor          timestamp: n
               xist   istory(type, value    hideInp       // 隐藏输入建议ingHint = conquerySelector('.input);
      
                         (   //con 设置相对n = 'relatr.style.posi定位rive';
   elative') {
          container.style.po
             
       0;   const ainer =
                          nt.style   bfault:
   reak;   
 n                  hint.style.color n: absol';
           ute;
   
             hintint.textContent = mes.classe = `input-hint input-he}`;
             
        示         i      yle.color = '';
     emsuggee.em.style.backgroucolor = = '';
  'whstion-it
                                         item.style.b   citems. (i === index)forEach((item, i) => {
     lass InteractionManager {
            constructor() {
                this.fillOperations = [];
                this.maxOperations = 10;
                this.highlightedElements = new Set();
                this.shortcuts = {
                    undo: 'ctrl+z',
                    redo: 'ctrl+y',
                    clear: 'ctrl+shift+c',
                    refill: 'ctrl+r'
                };

                this.init();
            }

            init() {
                this.setupKeyboardShortcuts();
                this.createInteractionUI();
                this.setupTooltips();
            }

            // 记录填充操作
            recordFillOperation(operation) {
                const fillOp = {
                    id: Date.now(),
                    timestamp: new Date(),
                    type: 'fill',
                    field: operation.field,
                    element: operation.element,
                    oldValue: operation.oldValue,
                    newValue: operation.newValue,
                    source: operation.source,
                    confidence: operation.confidence,
                    canUndo: true
                };

                this.fillOperations.push(fillOp);

                // 限制操作历史大小
                if (this.fillOperations.length > this.maxOperations) {
                    this.fillOperations.shift();
                }

                this.updateInteractionUI();
                return fillOp.id;
            }

            // 高亮填充结果
            highlightFillResult(element, options = {}) {
                const defaultOptions = {
                    duration: 3000,
                    showBadge: true,
                    showTooltip: true,
                    animationType: 'pulse'
                };

                const config = { ...defaultOptions, ...options };

                // 添加高亮样式
                element.classList.add('fill-highlighted');
                this.highlightedElements.add(element);

                // 添加填充徽章
                if (config.showBadge) {
                    this.addFillBadge(element, config);
                }

                // 添加工具提示
                if (config.showTooltip) {
                    this.addFillTooltip(element, config);
                }

                // 添加动画效果
                this.addFillAnimation(element, config.animationType);

                // 自动移除高亮
                setTimeout(() => {
                    this.removeHighlight(element);
                }, config.duration);
            }

            // 添加填充徽章
            addFillBadge(element, config) {
                // 移除现有徽章
                const existingBadge = element.parentNode.querySelector('.fill-badge');
                if (existingBadge) {
                    existingBadge.remove();
                }

                const badge = document.createElement('span');
                badge.className = 'fill-badge';
                badge.innerHTML = '✨ 自动填充';
                badge.style.cssText = `
                    position: absolute;
                    top: -8px;
                    right: -8px;
                    background: #28a745;
                    color: white;
                    font-size: 10px;
                    padding: 2px 6px;
                    border-radius: 10px;
                    z-index: 1000;
                    animation: badgeFadeIn 0.3s ease-out;
                `;

                // 确保父元素有相对定位
                if (getComputedStyle(element.parentNode).position === 'static') {
                    element.parentNode.style.position = 'relative';
                }

                element.parentNode.appendChild(badge);

                // 自动移除徽章
                setTimeout(() => {
                    if (badge.parentNode) {
                        badge.style.animation = 'badgeFadeOut 0.3s ease-out';
                        setTimeout(() => badge.remove(), 300);
                    }
                }, 2500);
            }

            // 添加工具提示
            addFillTooltip(element, config) {
                const tooltip = document.createElement('div');
                tooltip.className = 'fill-tooltip';
                tooltip.innerHTML = `
                    <div class="tooltip-content">
                        <strong>自动填充</strong><br>
                        来源: ${config.source || '未知'}<br>
                        置信度: ${config.confidence || 0}%<br>
                        <small>按 Ctrl+Z 撤销</small>
                    </div>
                `;

                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0,0,0,0.8);
                    color: white;
                    padding: 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    z-index: 1001;
                    pointer-events: none;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                `;

                document.body.appendChild(tooltip);

                // 定位工具提示
                const rect = element.getBoundingClientRect();
                tooltip.style.left = rect.left + 'px';
                tooltip.style.top = (rect.bottom + 5) + 'px';

                // 显示工具提示
                setTimeout(() => tooltip.style.opacity = '1', 100);

                // 自动移除工具提示
                setTimeout(() => {
                    tooltip.style.opacity = '0';
                    setTimeout(() => tooltip.remove(), 300);
                }, 2000);
            }

            // 添加填充动画
            addFillAnimation(element, animationType) {
                element.classList.add(`fill-animation-${animationType}`);

                setTimeout(() => {
                    element.classList.remove(`fill-animation-${animationType}`);
                }, 1000);
            }

            // 移除高亮
            removeHighlight(element) {
                element.classList.remove('fill-highlighted');
                this.highlightedElements.delete(element);

                // 移除相关元素
                const badge = element.parentNode.querySelector('.fill-badge');
                if (badge) badge.remove();
            }

            // 一键清除所有填充
            clearAllFills() {
                const confirmation = confirm('确定要清除所有自动填充的内容吗？');
                if (!confirmation) return;

                let clearedCount = 0;
                this.fillOperations.forEach(op => {
                    if (op.canUndo && op.element && op.element.value === op.newValue) {
                        op.element.value = op.oldValue;
                        op.element.classList.remove('is-valid', 'is-invalid');
                        this.removeHighlight(op.element);
                        clearedCount++;
                    }
                });

                // 清除操作历史
                this.fillOperations = [];
                this.updateInteractionUI();

                showStatus(`已清除 ${clearedCount} 个自动填充字段`, 'success', true);
            }

            // 重新填充最后的识别结果
            refillLastResults() {
                if (this.fillOperations.length === 0) {
                    showStatus('没有可重新填充的内容', 'warning');
                    return;
                }

                const lastOperations = this.fillOperations.slice(-2); // 最后两个操作
                let refilledCount = 0;

                lastOperations.forEach(op => {
                    if (op.element) {
                        op.element.value = op.newValue;
                        this.highlightFillResult(op.element, {
                            source: op.source + ' (重填)',
                            confidence: op.confidence
                        });
                        refilledCount++;
                    }
                });

                showStatus(`已重新填充 ${refilledCount} 个字段`, 'success', true);
            }

            // 撤销最后的填充操作
            undoLastFill() {
                const lastFillOp = [...this.fillOperations].reverse().find(op => op.canUndo);

                if (!lastFillOp) {
                    showStatus('没有可撤销的填充操作', 'warning');
                    return;
                }

                if (lastFillOp.element && lastFillOp.element.value === lastFillOp.newValue) {
                    lastFillOp.element.value = lastFillOp.oldValue;
                    lastFillOp.element.classList.remove('is-valid', 'is-invalid');
                    this.removeHighlight(lastFillOp.element);
                    lastFillOp.canUndo = false;

                    showStatus(`已撤销 ${lastFillOp.field} 字段的填充`, 'success', true);
                } else {
                    showStatus('该字段已被手动修改，无法撤销', 'warning');
                }

                this.updateInteractionUI();
            }

            // 设置键盘快捷键
            setupKeyboardShortcuts() {
                document.addEventListener('keydown', (e) => {
                    // Ctrl+Z - 撤销
                    if (e.ctrlKey && e.key === 'z' && !e.shiftKey) {
                        e.preventDefault();
                        this.undoLastFill();
                    }

                    // Ctrl+Shift+C - 清除所有
                    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
                        e.preventDefault();
                        this.clearAllFills();
                    }

                    // Ctrl+R - 重新填充
                    if (e.ctrlKey && e.key === 'r') {
                        e.preventDefault();
                        this.refillLastResults();
                    }
                });
            }

            // 创建交互UI
            createInteractionUI() {
                // 添加浮动操作按钮
                const floatingActions = document.createElement('div');
                floatingActions.id = 'floatingActions';
                floatingActions.className = 'floating-actions';
                floatingActions.innerHTML = `
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="undoFill" title="撤销填充 (Ctrl+Z)">
                        ↶ 撤销
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-warning" id="clearAllFills" title="清除所有 (Ctrl+Shift+C)">
                        🗑️ 清除
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-info" id="refillLast" title="重新填充 (Ctrl+R)">
                        🔄 重填
                    </button>
                `;

                floatingActions.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    display: flex;
                    gap: 5px;
                    z-index: 1000;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                `;

                document.body.appendChild(floatingActions);

                // 绑定事件
                document.getElementById('undoFill').addEventListener('click', () => this.undoLastFill());
                document.getElementById('clearAllFills').addEventListener('click', () => this.clearAllFills());
                document.getElementById('refillLast').addEventListener('click', () => this.refillLastResults());

                // 当有填充操作时显示浮动按钮
                this.updateInteractionUI();
            }

            // 更新交互UI
            updateInteractionUI() {
                const floatingActions = document.getElementById('floatingActions');
                if (!floatingActions) return;

                const hasOperations = this.fillOperations.length > 0;
                const hasUndoableOperations = this.fillOperations.some(op => op.canUndo);

                floatingActions.style.opacity = hasOperations ? '1' : '0';

                // 更新按钮状态
                const undoBtn = document.getElementById('undoFill');
                const clearBtn = document.getElementById('clearAllFills');
                const refillBtn = document.getElementById('refillLast');

                if (undoBtn) undoBtn.disabled = !hasUndoableOperations;
                if (clearBtn) clearBtn.disabled = !hasOperations;
                if (refillBtn) refillBtn.disabled = !hasOperations;
            }

            // 设置工具提示
            setupTooltips() {
                // 为表单字段添加交互提示
                const formFields = document.querySelectorAll('#outboundQuantity, #remarkInput');

                formFields.forEach(field => {
                    field.addEventListener('focus', () => {
                        if (!field.dataset.tooltipAdded) {
                            field.title = '支持自动填充 | 右键查看选项 | Ctrl+Z撤销';
                            field.dataset.tooltipAdded = 'true';
                        }
                    });

                    // 添加右键菜单
                    field.addEventListener('contextmenu', (e) => {
                        e.preventDefault();
                        this.showContextMenu(e, field);
                    });
                });
            }

            // 显示上下文菜单
            showContextMenu(event, field) {
                // 移除现有菜单
                const existingMenu = document.querySelector('.context-menu');
                if (existingMenu) existingMenu.remove();

                const menu = document.createElement('div');
                menu.className = 'context-menu';
                menu.innerHTML = `
                    <div class="context-menu-item" data-action="clear">清除内容</div>
                    <div class="context-menu-item" data-action="undo">撤销填充</div>
                    <div class="context-menu-item" data-action="refill">重新填充</div>
                    <hr class="context-menu-divider">
                    <div class="context-menu-item" data-action="copy">复制内容</div>
                `;

                menu.style.cssText = `
                    position: fixed;
                    left: ${event.clientX}px;
                    top: ${event.clientY}px;
                    background: white;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    z-index: 1002;
                    min-width: 120px;
                `;

                document.body.appendChild(menu);

                // 绑定菜单事件
                menu.addEventListener('click', (e) => {
                    const action = e.target.dataset.action;
                    this.handleContextMenuAction(action, field);
                    menu.remove();
                });

                // 点击其他地方关闭菜单
                setTimeout(() => {
                    document.addEventListener('click', () => menu.remove(), { once: true });
                }, 100);
            }

            // 处理上下文菜单操作
            handleContextMenuAction(action, field) {
                switch (action) {
                    case 'clear':
                        field.value = '';
                        field.classList.remove('is-valid', 'is-invalid');
                        this.removeHighlight(field);
                        showStatus('字段已清除', 'success', true);
                        break;
                    case 'undo':
                        this.undoLastFill();
                        break;
                    case 'refill':
                        this.refillLastResults();
                        break;
                    case 'copy':
                        navigator.clipboard.writeText(field.value).then(() => {
                            showStatus('内容已复制到剪贴板', 'success', true);
                        });
                        break;
                }
            }

            // 获取交互统计
            getInteractionStats() {
                return {
                    totalOperations: this.fillOperations.length,
                    undoableOperations: this.fillOperations.filter(op => op.canUndo).length,
                    highlightedElements: this.highlightedElements.size,
                    recentOperations: this.fillOperations.slice(-5)
                };
            }

            // 初始化样式
            initStyles() {
                const style = document.createElement('style');
                style.textContent = `
                    .fill-highlighted {
                        background-color: #e8f5e8 !important;
                        border-color: #28a745 !important;
                        box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25) !important;
                    }
                    
                    .fill-animation-pulse {
                        animation: fillPulse 0.6s ease-in-out;
                    }
                    
                    @keyframes fillPulse {
                        0% { transform: scale(1); }
                        50% { transform: scale(1.05); }
                        100% { transform: scale(1); }
                    }
                    
                    @keyframes badgeFadeIn {
                        from { opacity: 0; transform: scale(0.8); }
                        to { opacity: 1; transform: scale(1); }
                    }
                    
                    @keyframes badgeFadeOut {
                        from { opacity: 1; transform: scale(1); }
                        to { opacity: 0; transform: scale(0.8); }
                    }
                    
                    .floating-actions {
                        backdrop-filter: blur(10px);
                        background: rgba(255, 255, 255, 0.9);
                        padding: 8px;
                        border-radius: 8px;
                        border: 1px solid rgba(0, 0, 0, 0.1);
                    }
                    
                    .context-menu {
                        font-size: 14px;
                    }
                    
                    .context-menu-item {
                        padding: 8px 12px;
                        cursor: pointer;
                        transition: background-color 0.2s;
                    }
                    
                    .context-menu-item:hover {
                        background-color: #f8f9fa;
                    }
                    
                    .context-menu-divider {
                        margin: 4px 0;
                        border: none;
                        border-top: 1px solid #eee;
                    }
                `;
                document.head.appendChild(style);
            }
        }

        // 智能表单控制器
        class FormController {
            constructor() {
                this.formElements = {
                    quantity: document.getElementById('outboundQuantity'),
                    remark: document.getElementById('remarkInput'),
                    photo: document.querySelector('input[name="photo"]')
                };

                this.fillHistory = [];
                this.maxHistorySize = 20;
                this.validationRules = {
                    quantity: {
                        min: 1,
                        max: null, // 将在初始化时设置
                        required: true,
                        type: 'number'
                    },
                    remark: {
                        minLength: 1,
                        maxLength: 50,
                        required: false,
                        type: 'text'
                    }
                };

                this.autoFillSettings = {
                    enableQuantityFill: true,
                    enableRemarkFill: true,
                    showFillAnimation: true,
                    confirmBeforeFill: false,
                    highlightFilledFields: true
                };

                this.init();
            }

            init() {
                // 设置数量最大值
                if (this.formElements.quantity) {
                    this.validationRules.quantity.max = parseInt(this.formElements.quantity.max) || 999999;
                }

                // 添加实时验证
                this.addRealTimeValidation();

                // 添加填充历史功能
                this.addFillHistorySupport();

                // 初始化样式
                this.initStyles();
            }

            // 智能填充数量
            fillQuantity(value, source = '', confidence = 0) {
                if (!this.autoFillSettings.enableQuantityFill) {
                    return { success: false, reason: '数量自动填充已禁用' };
                }

                const validation = this.validateQuantity(value);
                if (!validation.isValid) {
                    return { success: false, reason: validation.message };
                }

                const fillData = {
                    field: 'quantity',
                    oldValue: this.formElements.quantity.value,
                    newValue: validation.adjustedValue,
                    source: source,
                    confidence: confidence,
                    timestamp: new Date(),
                    wasAdjusted: validation.wasAdjusted
                };

                // 执行填充
                this.performFill(fillData);

                return {
                    success: true,
                    value: validation.adjustedValue,
                    wasAdjusted: validation.wasAdjusted,
                    message: validation.message
                };
            }

            // 智能填充备注
            fillRemark(value, source = '', confidence = 0) {
                if (!this.autoFillSettings.enableRemarkFill) {
                    return { success: false, reason: '备注自动填充已禁用' };
                }

                const validation = this.validateRemark(value);
                if (!validation.isValid) {
                    return { success: false, reason: validation.message };
                }

                const fillData = {
                    field: 'remark',
                    oldValue: this.formElements.remark.value,
                    newValue: validation.value,
                    source: source,
                    confidence: confidence,
                    timestamp: new Date(),
                    wasAdjusted: false
                };

                // 执行填充
                this.performFill(fillData);

                return {
                    success: true,
                    value: validation.value,
                    message: validation.message
                };
            }

            // 执行填充操作
            performFill(fillData) {
                const element = this.formElements[fillData.field];

                if (this.autoFillSettings.showFillAnimation) {
                    this.animateFill(element, fillData.newValue);
                } else {
                    element.value = fillData.newValue;
                }

                // 使用InteractionManager进行高级交互处理
                if (this.autoFillSettings.highlightFilledFields) {
                    interactionManager.highlightFillResult(element, {
                        source: fillData.source,
                        confidence: fillData.confidence,
                        showBadge: true,
                        showTooltip: true,
                        animationType: 'pulse'
                    });
                }

                // 记录到InteractionManager
                const operationData = {
                    ...fillData,
                    element: element
                };
                interactionManager.recordFillOperation(operationData);

                // 记录填充历史
                this.addToFillHistory(fillData);

                // 触发change事件
                element.dispatchEvent(new Event('change', { bubbles: true }));
            }

            // 填充动画
            animateFill(element, newValue) {
                element.style.transition = 'all 0.3s ease';
                element.style.backgroundColor = '#e3f2fd';
                element.style.transform = 'scale(1.02)';

                setTimeout(() => {
                    element.value = newValue;
                    element.style.backgroundColor = '#c8e6c9';
                }, 150);

                setTimeout(() => {
                    element.style.backgroundColor = '';
                    element.style.transform = '';
                }, 1000);
            }

            // 高亮字段
            highlightField(element) {
                element.classList.add('auto-filled');
                setTimeout(() => {
                    element.classList.remove('auto-filled');
                }, 3000);
            }

            // 验证数量
            validateQuantity(value) {
                const result = {
                    isValid: false,
                    value: value,
                    adjustedValue: value,
                    wasAdjusted: false,
                    message: ''
                };

                // 类型检查
                const numValue = parseInt(value);
                if (isNaN(numValue)) {
                    result.message = '数量必须是有效数字';
                    return result;
                }

                // 范围检查
                const rules = this.validationRules.quantity;
                if (numValue < rules.min) {
                    result.message = `数量不能小于${rules.min}`;
                    return result;
                }

                if (numValue > rules.max) {
                    result.adjustedValue = rules.max;
                    result.wasAdjusted = true;
                    result.message = `数量超出最大值，已调整为${rules.max}`;
                } else {
                    result.message = `数量验证通过：${numValue}`;
                }

                result.isValid = true;
                result.value = numValue;

                return result;
            }

            // 验证备注
            validateRemark(value) {
                const result = {
                    isValid: false,
                    value: value,
                    message: ''
                };

                if (!value) {
                    result.isValid = true;
                    result.message = '备注为空，使用默认值';
                    return result;
                }

                const rules = this.validationRules.remark;

                if (value.length > rules.maxLength) {
                    result.message = `备注长度不能超过${rules.maxLength}个字符`;
                    return result;
                }

                result.isValid = true;
                result.message = `备注验证通过：${value}`;

                return result;
            }

            // 添加实时验证
            addRealTimeValidation() {
                // 数量字段验证
                if (this.formElements.quantity) {
                    this.formElements.quantity.addEventListener('input', (e) => {
                        const validation = this.validateQuantity(e.target.value);
                        this.showFieldValidation(e.target, validation);
                    });
                }

                // 备注字段验证
                if (this.formElements.remark) {
                    this.formElements.remark.addEventListener('input', (e) => {
                        const validation = this.validateRemark(e.target.value);
                        this.showFieldValidation(e.target, validation);
                    });
                }
            }

            // 显示字段验证结果
            showFieldValidation(element, validation) {
                // 移除之前的验证样式
                element.classList.remove('is-valid', 'is-invalid');

                // 添加新的验证样式
                if (validation.isValid) {
                    element.classList.add('is-valid');
                } else {
                    element.classList.add('is-invalid');
                }

                // 显示验证消息
                let feedbackElement = element.parentNode.querySelector('.validation-feedback');
                if (!feedbackElement) {
                    feedbackElement = document.createElement('div');
                    feedbackElement.className = 'validation-feedback small';
                    element.parentNode.appendChild(feedbackElement);
                }

                feedbackElement.textContent = validation.message;
                feedbackElement.className = `validation-feedback small ${validation.isValid ? 'text-success' : 'text-danger'}`;
            }

            // 添加填充历史支持
            addFillHistorySupport() {
                // 可以通过快捷键查看历史
                document.addEventListener('keydown', (e) => {
                    if (e.ctrlKey && e.key === 'h') {
                        e.preventDefault();
                        this.showFillHistory();
                    }
                });
            }

            // 显示填充历史
            showFillHistory() {
                if (this.fillHistory.length === 0) {
                    showStatus('暂无填充历史记录', 'info');
                    return;
                }

                let historyText = '填充历史记录：\n\n';
                this.fillHistory.slice(0, 10).forEach((record, index) => {
                    const time = new Date(record.timestamp).toLocaleTimeString();
                    historyText += `${index + 1}. ${time} - ${record.field}\n`;
                    historyText += `   ${record.oldValue} → ${record.newValue}\n`;
                    historyText += `   来源：${record.source} (${record.confidence}%)\n\n`;
                });

                // 在新窗口显示历史
                const historyWindow = window.open('', '_blank', 'width=500,height=400');
                historyWindow.document.write(`
                    <html>
                        <head><title>表单填充历史</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${historyText}
                        </body>
                    </html>
                `);
            }

            // 添加到填充历史
            addToFillHistory(fillData) {
                this.fillHistory.unshift(fillData);

                if (this.fillHistory.length > this.maxHistorySize) {
                    this.fillHistory = this.fillHistory.slice(0, this.maxHistorySize);
                }
            }

            // 初始化样式
            initStyles() {
                // 添加自定义CSS
                const style = document.createElement('style');
                style.textContent = `
                    .auto-filled {
                        background-color: #c8e6c9 !important;
                        border-color: #4caf50 !important;
                        box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25) !important;
                    }
                    
                    .form-control.is-valid {
                        border-color: #28a745;
                        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath fill='%2328a745' d='m2.3 6.73.94-.94 2.94 2.94L7.83 7.09 8.77 8.03 5.24 11.56z'/%3e%3c/svg%3e");
                        background-repeat: no-repeat;
                        background-position: right calc(0.375em + 0.1875rem) center;
                        background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
                    }
                    
                    .form-control.is-invalid {
                        border-color: #dc3545;
                        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23dc3545' viewBox='0 0 12 12'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath d='m5.8 4.6 1.4 1.4M7.2 7.4 5.8 6'/%3e%3c/svg%3e");
                        background-repeat: no-repeat;
                        background-position: right calc(0.375em + 0.1875rem) center;
                        background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
                    }
                    
                    .validation-feedback {
                        margin-top: 0.25rem;
                        font-size: 0.875em;
                    }
                `;
                document.head.appendChild(style);
            }

            // 重置表单
            resetForm() {
                Object.values(this.formElements).forEach(element => {
                    if (element && element.type !== 'file') {
                        element.value = '';
                        element.classList.remove('is-valid', 'is-invalid', 'auto-filled');
                    }
                });

                // 清除验证消息
                document.querySelectorAll('.validation-feedback').forEach(el => el.remove());

                showStatus('表单已重置', 'success', true);
            }

            // 获取表单数据
            getFormData() {
                return {
                    quantity: this.formElements.quantity ? parseInt(this.formElements.quantity.value) : null,
                    remark: this.formElements.remark ? this.formElements.remark.value : '',
                    hasPhoto: this.formElements.photo ? this.formElements.photo.files.length > 0 : false
                };
            }

            // 验证整个表单
            validateForm() {
                const data = this.getFormData();
                const errors = [];

                // 验证数量
                if (this.validationRules.quantity.required && !data.quantity) {
                    errors.push('出库数量不能为空');
                } else if (data.quantity) {
                    const quantityValidation = this.validateQuantity(data.quantity);
                    if (!quantityValidation.isValid) {
                        errors.push(quantityValidation.message);
                    }
                }

                // 验证备注
                if (data.remark) {
                    const remarkValidation = this.validateRemark(data.remark);
                    if (!remarkValidation.isValid) {
                        errors.push(remarkValidation.message);
                    }
                }

                return {
                    isValid: errors.length === 0,
                    errors: errors,
                    data: data
                };
            }

            // 更新设置
            updateSettings(newSettings) {
                this.autoFillSettings = { ...this.autoFillSettings, ...newSettings };
            }

            // 获取填充统计
            getFillStats() {
                const total = this.fillHistory.length;
                const quantityFills = this.fillHistory.filter(h => h.field === 'quantity').length;
                const remarkFills = this.fillHistory.filter(h => h.field === 'remark').length;

                return {
                    totalFills: total,
                    quantityFills: quantityFills,
                    remarkFills: remarkFills,
                    recentFills: this.fillHistory.slice(0, 5)
                };
            }
        }

        // 产品编码验证系统
        class ProductCodeValidator {
            constructor() {
                this.validationHistory = [];
                this.maxHistorySize = 50;
                this.similarityThreshold = 0.8;
                this.validationRules = {
                    exactMatch: { weight: 1.0, description: '完全匹配' },
                    partialMatch: { weight: 0.7, description: '部分匹配' },
                    similarMatch: { weight: 0.5, description: '相似匹配' },
                    noMatch: { weight: 0.0, description: '不匹配' }
                };
            }

            // 主要验证方法
            validateProductCode(recognizedCode, expectedCode, confidence = 0, pattern = '') {
                const validation = {
                    recognizedCode: recognizedCode,
                    expectedCode: expectedCode,
                    ocrConfidence: confidence,
                    pattern: pattern,
                    timestamp: new Date(),
                    matchType: null,
                    matchScore: 0,
                    similarity: 0,
                    isValid: false,
                    suggestions: [],
                    visualFeedback: null
                };

                // 执行各种验证检查
                validation.matchType = this.determineMatchType(recognizedCode, expectedCode);
                validation.matchScore = this.calculateMatchScore(recognizedCode, expectedCode);
                validation.similarity = this.calculateSimilarity(recognizedCode, expectedCode);
                validation.isValid = validation.matchType === 'exactMatch';
                validation.suggestions = this.generateSuggestions(recognizedCode, expectedCode);
                validation.visualFeedback = this.createVisualFeedback(validation);

                // 记录验证历史
                this.addToHistory(validation);

                return validation;
            }

            // 确定匹配类型
            determineMatchType(recognized, expected) {
                if (!recognized || !expected) return 'noMatch';

                if (recognized === expected) {
                    return 'exactMatch';
                }

                // 检查部分匹配（连续子串）
                const longestCommonSubstring = this.findLongestCommonSubstring(recognized, expected);
                if (longestCommonSubstring.length >= 6) {
                    return 'partialMatch';
                }

                // 检查相似匹配（编辑距离）
                const similarity = this.calculateSimilarity(recognized, expected);
                if (similarity >= this.similarityThreshold) {
                    return 'similarMatch';
                }

                return 'noMatch';
            }

            // 计算匹配分数
            calculateMatchScore(recognized, expected) {
                if (!recognized || !expected) return 0;

                const matchType = this.determineMatchType(recognized, expected);
                const baseScore = this.validationRules[matchType].weight;

                // 根据相似度调整分数
                const similarity = this.calculateSimilarity(recognized, expected);

                return Math.round(baseScore * similarity * 100);
            }

            // 计算字符串相似度（使用Levenshtein距离）
            calculateSimilarity(str1, str2) {
                if (!str1 || !str2) return 0;
                if (str1 === str2) return 1;

                const matrix = [];
                const len1 = str1.length;
                const len2 = str2.length;

                // 初始化矩阵
                for (let i = 0; i <= len1; i++) {
                    matrix[i] = [i];
                }
                for (let j = 0; j <= len2; j++) {
                    matrix[0][j] = j;
                }

                // 填充矩阵
                for (let i = 1; i <= len1; i++) {
                    for (let j = 1; j <= len2; j++) {
                        const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
                        matrix[i][j] = Math.min(
                            matrix[i - 1][j] + 1,      // 删除
                            matrix[i][j - 1] + 1,      // 插入
                            matrix[i - 1][j - 1] + cost // 替换
                        );
                    }
                }

                const distance = matrix[len1][len2];
                const maxLength = Math.max(len1, len2);

                return maxLength === 0 ? 1 : (maxLength - distance) / maxLength;
            }

            // 找到最长公共子串
            findLongestCommonSubstring(str1, str2) {
                if (!str1 || !str2) return '';

                let longest = '';
                for (let i = 0; i < str1.length; i++) {
                    for (let j = i + 1; j <= str1.length; j++) {
                        const substring = str1.slice(i, j);
                        if (str2.includes(substring) && substring.length > longest.length) {
                            longest = substring;
                        }
                    }
                }
                return longest;
            }

            // 生成修正建议
            generateSuggestions(recognized, expected) {
                const suggestions = [];

                if (!recognized || !expected) {
                    return [{ type: 'error', message: '无法生成建议：缺少必要信息' }];
                }

                const similarity = this.calculateSimilarity(recognized, expected);
                const commonSubstring = this.findLongestCommonSubstring(recognized, expected);

                // 基于相似度的建议
                if (similarity > 0.8) {
                    suggestions.push({
                        type: 'warning',
                        message: `识别结果与预期非常相似 (${Math.round(similarity * 100)}%)，可能是OCR识别错误`
                    });
                } else if (similarity > 0.5) {
                    suggestions.push({
                        type: 'info',
                        message: `识别结果与预期有一定相似性 (${Math.round(similarity * 100)}%)，建议检查原图`
                    });
                }

                // 基于公共子串的建议
                if (commonSubstring.length >= 6) {
                    suggestions.push({
                        type: 'info',
                        message: `发现公共部分："${commonSubstring}"，可能是部分识别正确`
                    });
                }

                // 长度差异建议
                const lengthDiff = Math.abs(recognized.length - expected.length);
                if (lengthDiff > 0) {
                    suggestions.push({
                        type: 'warning',
                        message: `长度不匹配：识别到${recognized.length}位，预期${expected.length}位`
                    });
                }

                // 字符差异分析
                const differentPositions = this.findDifferentPositions(recognized, expected);
                if (differentPositions.length > 0 && differentPositions.length <= 3) {
                    suggestions.push({
                        type: 'info',
                        message: `差异位置：第${differentPositions.join('、')}位字符不同`
                    });
                }

                return suggestions;
            }

            // 找到不同字符的位置
            findDifferentPositions(str1, str2) {
                const positions = [];
                const minLength = Math.min(str1.length, str2.length);

                for (let i = 0; i < minLength; i++) {
                    if (str1[i] !== str2[i]) {
                        positions.push(i + 1); // 1-based index
                    }
                }

                return positions;
            }

            // 创建视觉反馈
            createVisualFeedback(validation) {
                const feedback = {
                    type: validation.isValid ? 'success' : 'error',
                    icon: validation.isValid ? '✅' : '❌',
                    title: '',
                    message: '',
                    details: [],
                    actionButtons: []
                };

                switch (validation.matchType) {
                    case 'exactMatch':
                        feedback.title = '产品编码匹配成功';
                        feedback.message = `编码：${validation.recognizedCode}`;
                        feedback.details = [
                            `匹配模式：${validation.pattern}`,
                            `OCR置信度：${validation.ocrConfidence}%`,
                            `匹配分数：${validation.matchScore}/100`
                        ];
                        break;

                    case 'partialMatch':
                        feedback.type = 'warning';
                        feedback.icon = '⚠️';
                        feedback.title = '产品编码部分匹配';
                        feedback.message = `识别到：${validation.recognizedCode}\n预期：${validation.expectedCode}`;
                        feedback.details = [
                            `相似度：${Math.round(validation.similarity * 100)}%`,
                            `匹配分数：${validation.matchScore}/100`
                        ];
                        feedback.actionButtons = [
                            { text: '手动确认', action: 'manual_confirm' },
                            { text: '重新识别', action: 'retry_recognition' }
                        ];
                        break;

                    case 'similarMatch':
                        feedback.type = 'warning';
                        feedback.icon = '⚠️';
                        feedback.title = '产品编码相似匹配';
                        feedback.message = `识别到：${validation.recognizedCode}\n预期：${validation.expectedCode}`;
                        feedback.details = [
                            `相似度：${Math.round(validation.similarity * 100)}%`,
                            `可能是OCR识别错误`
                        ];
                        feedback.actionButtons = [
                            { text: '手动输入', action: 'manual_input' },
                            { text: '重新拍照', action: 'retake_photo' }
                        ];
                        break;

                    case 'noMatch':
                        feedback.title = '产品编码不匹配';
                        feedback.message = `识别到：${validation.recognizedCode}\n当前计划：${validation.expectedCode}`;
                        feedback.details = [
                            `相似度：${Math.round(validation.similarity * 100)}%`,
                            `请确认产品是否正确`
                        ];
                        feedback.actionButtons = [
                            { text: '切换计划', action: 'switch_plan' },
                            { text: '手动输入', action: 'manual_input' },
                            { text: '重新识别', action: 'retry_recognition' }
                        ];
                        break;
                }

                return feedback;
            }

            // 添加到验证历史
            addToHistory(validation) {
                this.validationHistory.unshift(validation);

                // 限制历史记录大小
                if (this.validationHistory.length > this.maxHistorySize) {
                    this.validationHistory = this.validationHistory.slice(0, this.maxHistorySize);
                }
            }

            // 获取验证统计
            getValidationStats() {
                if (this.validationHistory.length === 0) {
                    return { totalValidations: 0, successRate: 0, averageConfidence: 0 };
                }

                const total = this.validationHistory.length;
                const successful = this.validationHistory.filter(v => v.isValid).length;
                const totalConfidence = this.validationHistory.reduce((sum, v) => sum + v.ocrConfidence, 0);

                return {
                    totalValidations: total,
                    successRate: Math.round((successful / total) * 100),
                    averageConfidence: Math.round(totalConfidence / total),
                    recentValidations: this.validationHistory.slice(0, 5)
                };
            }

            // 清除历史记录
            clearHistory() {
                this.validationHistory = [];
            }
        }

        // 高级文本解析器
        class TextParser {
            constructor() {
                // 产品编码识别模式（按优先级排序）
                this.productCodePatterns = [
                    {
                        name: '物料名称标签',
                        pattern: /(?:物料名称|物料编码|产品名称)[：:\s]*(\d{10})/gi,
                        priority: 1,
                        confidence: 0.95
                    },
                    {
                        name: '产品编码标签',
                        pattern: /(?:产品编码|商品编码|货品编码)[：:\s]*(\d{10})/gi,
                        priority: 2,
                        confidence: 0.9
                    },
                    {
                        name: '物料标签',
                        pattern: /(?:物料|材料)[：:\s]*(\d{10})/gi,
                        priority: 3,
                        confidence: 0.85
                    },
                    {
                        name: '编码标签',
                        pattern: /(?:编码|代码|CODE)[：:\s]*(\d{10})/gi,
                        priority: 4,
                        confidence: 0.8
                    },
                    {
                        name: '条形码模式',
                        pattern: /(?:条形码|条码|BARCODE)[：:\s]*(\d{10})/gi,
                        priority: 5,
                        confidence: 0.75
                    },
                    {
                        name: '纯数字模式',
                        pattern: /(?:^|\s)(\d{10})(?:\s|$)/g,
                        priority: 6,
                        confidence: 0.6
                    }
                ];

                // 数量识别模式（按准确性排序）
                this.quantityPatterns = [
                    {
                        name: '数量标签',
                        pattern: /(?:数量|qty|quantity)[：:\s]*(\d+)/gi,
                        priority: 1,
                        confidence: 0.95
                    },
                    {
                        name: '个数标签',
                        pattern: /(?:个数|件数|总数)[：:\s]*(\d+)/gi,
                        priority: 2,
                        confidence: 0.9
                    },
                    {
                        name: '单位后缀',
                        pattern: /(\d+)\s*(?:个|件|只|支|条|根|张|片)/g,
                        priority: 3,
                        confidence: 0.85
                    },
                    {
                        name: '数量描述',
                        pattern: /(?:共|总共|合计)\s*(\d+)/gi,
                        priority: 4,
                        confidence: 0.8
                    },
                    {
                        name: '英文单位',
                        pattern: /(\d+)\s*(?:pcs|pieces|units|items)/gi,
                        priority: 5,
                        confidence: 0.75
                    }
                ];

                // WOXPJ编码模式
                this.woxpjPatterns = [
                    {
                        name: 'WOXPJ标准格式',
                        pattern: /WOXPJ[：:\s]*(\d+)/gi,
                        priority: 1,
                        confidence: 0.95
                    },
                    {
                        name: 'WO编码格式',
                        pattern: /WO[：:\s]*(\d+)/gi,
                        priority: 2,
                        confidence: 0.8
                    },
                    {
                        name: '工单编码',
                        pattern: /(?:工单|工作单)[：:\s]*(\w+\d+)/gi,
                        priority: 3,
                        confidence: 0.75
                    }
                ];

                // 文本预处理规则
                this.preprocessRules = [
                    // 统一冒号格式
                    { from: /：/g, to: ':' },
                    // 移除多余空格
                    { from: /\s+/g, to: ' ' },
                    // 统一数字格式
                    { from: /[０-９]/g, to: (match) => String.fromCharCode(match.charCodeAt(0) - 0xFF10 + 0x30) },
                    // 移除特殊字符
                    { from: /[^\w\s\d：:，。、！？（）【】《》""'']/g, to: ' ' }
                ];
            }

            // 主要解析方法
            parseText(text, confidence = 0) {
                console.log('开始高级文本解析:', text);

                // 预处理文本
                const cleanText = this.preprocessText(text);
                console.log('预处理后文本:', cleanText);

                const results = {
                    productCode: this.extractProductCode(cleanText),
                    quantity: this.extractQuantity(cleanText),
                    woxpjCode: this.extractWoxpjCode(cleanText),
                    confidence: confidence,
                    rawText: text,
                    cleanText: cleanText
                };

                // 计算综合置信度
                results.overallConfidence = this.calculateOverallConfidence(results);

                console.log('解析结果:', results);
                return results;
            }

            // 文本预处理
            preprocessText(text) {
                let cleanText = text;

                for (const rule of this.preprocessRules) {
                    cleanText = cleanText.replace(rule.from, rule.to);
                }

                return cleanText.trim();
            }

            // 提取产品编码
            extractProductCode(text) {
                const matches = [];

                for (const pattern of this.productCodePatterns) {
                    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
                    let match;

                    while ((match = regex.exec(text)) !== null) {
                        const code = match[1];
                        if (this.validateProductCode(code)) {
                            matches.push({
                                code: code,
                                pattern: pattern.name,
                                priority: pattern.priority,
                                confidence: pattern.confidence,
                                position: match.index
                            });
                        }
                    }
                }

                // 按优先级和置信度排序
                matches.sort((a, b) => {
                    if (a.priority !== b.priority) return a.priority - b.priority;
                    return b.confidence - a.confidence;
                });

                return matches.length > 0 ? matches[0] : null;
            }

            // 提取数量信息
            extractQuantity(text) {
                const matches = [];

                for (const pattern of this.quantityPatterns) {
                    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
                    let match;

                    while ((match = regex.exec(text)) !== null) {
                        const quantity = parseInt(match[1]);
                        if (this.validateQuantity(quantity)) {
                            matches.push({
                                quantity: quantity,
                                pattern: pattern.name,
                                priority: pattern.priority,
                                confidence: pattern.confidence,
                                position: match.index
                            });
                        }
                    }
                }

                matches.sort((a, b) => {
                    if (a.priority !== b.priority) return a.priority - b.priority;
                    return b.confidence - a.confidence;
                });

                return matches.length > 0 ? matches[0] : null;
            }

            // 提取WOXPJ编码
            extractWoxpjCode(text) {
                const matches = [];

                for (const pattern of this.woxpjPatterns) {
                    const regex = new RegExp(pattern.pattern.source, pattern.pattern.flags);
                    let match;

                    while ((match = regex.exec(text)) !== null) {
                        const code = match[1];
                        matches.push({
                            code: code,
                            pattern: pattern.name,
                            priority: pattern.priority,
                            confidence: pattern.confidence,
                            position: match.index
                        });
                    }
                }

                matches.sort((a, b) => {
                    if (a.priority !== b.priority) return a.priority - b.priority;
                    return b.confidence - a.confidence;
                });

                if (matches.length > 0) {
                    const bestMatch = matches[0];
                    // 提取后3位数字
                    const lastThreeDigits = bestMatch.code.replace(/\D/g, '').slice(-3);
                    return {
                        ...bestMatch,
                        lastThreeDigits: lastThreeDigits
                    };
                }

                return null;
            }

            // 验证产品编码
            validateProductCode(code) {
                // 必须是10位数字
                return /^\d{10}$/.test(code);
            }

            // 验证数量
            validateQuantity(quantity) {
                // 数量必须是正整数且在合理范围内
                return Number.isInteger(quantity) && quantity > 0 && quantity <= 999999;
            }

            // 计算综合置信度
            calculateOverallConfidence(results) {
                let totalConfidence = results.confidence || 0;
                let factorCount = 1;

                if (results.productCode) {
                    totalConfidence += results.productCode.confidence * 100;
                    factorCount++;
                }

                if (results.quantity) {
                    totalConfidence += results.quantity.confidence * 100;
                    factorCount++;
                }

                if (results.woxpjCode) {
                    totalConfidence += results.woxpjCode.confidence * 100;
                    factorCount++;
                }

                return Math.round(totalConfidence / factorCount);
            }

            // 获取解析统计信息
            getParsingStats(results) {
                return {
                    foundProductCode: !!results.productCode,
                    foundQuantity: !!results.quantity,
                    foundWoxpjCode: !!results.woxpjCode,
                    overallConfidence: results.overallConfidence,
                    textLength: results.rawText.length,
                    cleanTextLength: results.cleanText.length
                };
            }
        }

        // 图像预处理器
        class ImageProcessor {
            constructor() {
                this.canvas = document.createElement('canvas');
                this.ctx = this.canvas.getContext('2d');
                this.processingOptions = {
                    brightness: 1.2,
                    contrast: 1.3,
                    sharpness: 1.1,
                    denoise: true,
                    autoRotate: true,
                    resize: true,
                    maxWidth: 1920,
                    maxHeight: 1080
                };
            }

            async processImage(imageData, options = {}) {
                const settings = { ...this.processingOptions, ...options };

                try {
                    // 如果是File对象，先转换为Image
                    let img;
                    if (imageData instanceof File || imageData instanceof Blob) {
                        img = await this._loadImageFromBlob(imageData);
                    } else {
                        img = imageData;
                    }

                    // 设置画布尺寸
                    const { width, height } = this._calculateOptimalSize(img.width, img.height, settings);
                    this.canvas.width = width;
                    this.canvas.height = height;

                    // 清空画布
                    this.ctx.clearRect(0, 0, width, height);

                    // 绘制原始图像
                    this.ctx.drawImage(img, 0, 0, width, height);

                    // 应用图像处理
                    if (settings.brightness !== 1 || settings.contrast !== 1) {
                        this._adjustBrightnessContrast(settings.brightness, settings.contrast);
                    }

                    if (settings.sharpness > 1) {
                        this._applySharpen(settings.sharpness);
                    }

                    if (settings.denoise) {
                        this._applyDenoise();
                    }

                    // 转换为Blob返回
                    return new Promise((resolve) => {
                        this.canvas.toBlob((blob) => {
                            resolve(blob);
                        }, 'image/jpeg', 0.95);
                    });

                } catch (error) {
                    console.error('图像处理失败:', error);
                    throw new Error('图像处理失败: ' + error.message);
                }
            }

            _loadImageFromBlob(blob) {
                return new Promise((resolve, reject) => {
                    const img = new Image();
                    const url = URL.createObjectURL(blob);

                    img.onload = () => {
                        URL.revokeObjectURL(url);
                        resolve(img);
                    };

                    img.onerror = () => {
                        URL.revokeObjectURL(url);
                        reject(new Error('图像加载失败'));
                    };

                    img.src = url;
                });
            }

            _calculateOptimalSize(originalWidth, originalHeight, settings) {
                let { width, height } = { width: originalWidth, height: originalHeight };

                if (settings.resize) {
                    const maxWidth = settings.maxWidth;
                    const maxHeight = settings.maxHeight;

                    if (width > maxWidth || height > maxHeight) {
                        const ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = Math.round(width * ratio);
                        height = Math.round(height * ratio);
                    }
                }

                return { width, height };
            }

            _adjustBrightnessContrast(brightness, contrast) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;

                for (let i = 0; i < data.length; i += 4) {
                    // 调整亮度和对比度 (RGB通道)
                    for (let j = 0; j < 3; j++) {
                        let value = data[i + j];

                        // 应用对比度
                        value = ((value / 255 - 0.5) * contrast + 0.5) * 255;

                        // 应用亮度
                        value = value * brightness;

                        // 限制在0-255范围内
                        data[i + j] = Math.max(0, Math.min(255, value));
                    }
                }

                this.ctx.putImageData(imageData, 0, 0);
            }

            _applySharpen(intensity) {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;

                // 锐化卷积核
                const kernel = [
                    0, -1 * intensity, 0,
                    -1 * intensity, 1 + 4 * intensity, -1 * intensity,
                    0, -1 * intensity, 0
                ];

                const newData = new Uint8ClampedArray(data);

                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) { // RGB通道
                            let sum = 0;
                            for (let ky = -1; ky <= 1; ky++) {
                                for (let kx = -1; kx <= 1; kx++) {
                                    const idx = ((y + ky) * width + (x + kx)) * 4 + c;
                                    const kernelIdx = (ky + 1) * 3 + (kx + 1);
                                    sum += data[idx] * kernel[kernelIdx];
                                }
                            }
                            const idx = (y * width + x) * 4 + c;
                            newData[idx] = Math.max(0, Math.min(255, sum));
                        }
                    }
                }

                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }

            _applyDenoise() {
                const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
                const data = imageData.data;
                const width = this.canvas.width;
                const height = this.canvas.height;

                // 简单的中值滤波降噪
                const newData = new Uint8ClampedArray(data);

                for (let y = 1; y < height - 1; y++) {
                    for (let x = 1; x < width - 1; x++) {
                        for (let c = 0; c < 3; c++) { // RGB通道
                            const neighbors = [];

                            for (let dy = -1; dy <= 1; dy++) {
                                for (let dx = -1; dx <= 1; dx++) {
                                    const idx = ((y + dy) * width + (x + dx)) * 4 + c;
                                    neighbors.push(data[idx]);
                                }
                            }

                            neighbors.sort((a, b) => a - b);
                            const median = neighbors[Math.floor(neighbors.length / 2)];

                            const idx = (y * width + x) * 4 + c;
                            newData[idx] = median;
                        }
                    }
                }

                const newImageData = new ImageData(newData, width, height);
                this.ctx.putImageData(newImageData, 0, 0);
            }

            // 获取处理后的图像预览
            getPreviewDataURL() {
                return this.canvas.toDataURL('image/jpeg', 0.8);
            }

            // 更新处理选项
            updateOptions(newOptions) {
                this.processingOptions = { ...this.processingOptions, ...newOptions };
            }

            // 获取当前处理选项
            getOptions() {
                return { ...this.processingOptions };
            }
        }

        // OCR识别引擎
        class OCREngine {
            constructor() {
                this.isProcessing = false;
                this.retryCount = 0;
                this.maxRetries = 2;

                // 基础配置
                this.baseOptions = {
                    lang: 'chi_sim+eng',
                    logger: (m) => {
                        if (m.status === 'recognizing text') {
                            const progress = Math.round(m.progress * 100);
                            showStatus(`识别进度: ${progress}%`, 'processing');
                        }
                    }
                };

                // 优化的Tesseract配置
                this.optimizedConfig = {
                    // 页面分割模式 - 6: 单一文本块
                    tessedit_pageseg_mode: '6',

                    // 字符白名单 - 只识别数字、英文字母和常用中文字符
                    tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz：:，。、！？（）【】《》""''物料名称编码数量个件WOXPJ',

                    // OCR引擎模式 - 1: 神经网络LSTM引擎
                    tessedit_ocr_engine_mode: '1',

                    // 启用字典
                    load_system_dawg: '1',
                    load_freq_dawg: '1',

                    // 提高识别质量的参数
                    textord_min_linesize: '2.5',
                    preserve_interword_spaces: '1',

                    // 降噪参数
                    textord_noise_sizefraction: '10.0',
                    textord_noise_sizelimit: '0.7'
                };

                // 针对不同场景的配置预设
                this.presets = {
                    // 高精度模式 - 用于清晰图片
                    highAccuracy: {
                        ...this.optimizedConfig,
                        tessedit_pageseg_mode: '6',
                        classify_bln_numeric_mode: '1'
                    },

                    // 快速模式 - 用于模糊图片
                    fastMode: {
                        ...this.optimizedConfig,
                        tessedit_pageseg_mode: '8',
                        tessedit_ocr_engine_mode: '2'
                    },

                    // 数字优化模式 - 专门识别产品编码
                    numberOptimized: {
                        ...this.optimizedConfig,
                        tessedit_char_whitelist: '0123456789',
                        classify_bln_numeric_mode: '1',
                        tessedit_pageseg_mode: '8'
                    }
                };

                this.currentPreset = 'highAccuracy';
            }

            async recognizeText(imageData, preset = null) {
                if (this.isProcessing) {
                    showStatus('正在处理中，请稍候...', 'warning');
                    return;
                }

                this.isProcessing = true;
                this.retryCount = 0;

                return this._recognizeWithRetry(imageData, preset);
            }

            async _recognizeWithRetry(imageData, preset = null) {
                const currentPreset = preset || this.currentPreset;
                const config = this.presets[currentPreset];

                showStatus(`正在预处理图像...`, 'processing');

                try {
                    // 图像预处理
                    let processedImage = imageData;

                    // 根据识别模式选择不同的预处理参数
                    const processingOptions = this._getProcessingOptions(currentPreset);

                    if (imageData instanceof File || imageData instanceof Blob) {
                        processedImage = await imageProcessor.processImage(imageData, processingOptions);
                        showStatus(`图像预处理完成，开始识别 (${currentPreset}模式)...`, 'processing');
                    } else {
                        showStatus(`正在识别文字 (${currentPreset}模式)...`, 'processing');
                    }

                    const result = await Tesseract.recognize(processedImage, this.baseOptions.lang, {
                        logger: this.baseOptions.logger,
                        ...config
                    });

                    const text = result.data.text.trim();
                    const confidence = result.data.confidence;

                    console.log(`OCR结果 - 置信度: ${confidence}%, 文本长度: ${text.length}`);

                    // 如果置信度太低且还有重试机会，尝试其他模式
                    if (confidence < 60 && this.retryCount < this.maxRetries) {
                        this.retryCount++;
                        const nextPreset = this._getNextPreset(currentPreset);
                        showStatus(`置信度较低(${confidence}%)，尝试${nextPreset}模式...`, 'processing');
                        return this._recognizeWithRetry(imageData, nextPreset);
                    }

                    if (!text || text.length < 3) {
                        throw new Error('未识别到有效文字，请确保图片清晰且包含文字内容');
                    }

                    showStatus(`识别完成！置信度: ${confidence}%`, 'success', true);
                    statusManager.showResult(text);

                    // 解析识别结果
                    this.parseRecognitionResult(text, confidence);

                    return { text, confidence };
                } catch (error) {
                    console.error('OCR Error:', error);

                    // 如果还有重试机会，尝试其他配置
                    if (this.retryCount < this.maxRetries) {
                        this.retryCount++;
                        const nextPreset = this._getNextPreset(currentPreset);
                        showStatus(`识别失败，尝试${nextPreset}模式...`, 'processing');
                        return this._recognizeWithRetry(imageData, nextPreset);
                    }

                    showStatus(`识别失败：${error.message}`, 'error');
                    throw error;
                } finally {
                    this.isProcessing = false;
                }
            }

            _getNextPreset(currentPreset) {
                const presetOrder = ['highAccuracy', 'fastMode', 'numberOptimized'];
                const currentIndex = presetOrder.indexOf(currentPreset);
                return presetOrder[(currentIndex + 1) % presetOrder.length];
            }

            _getProcessingOptions(preset) {
                const processingPresets = {
                    highAccuracy: {
                        brightness: 1.2,
                        contrast: 1.4,
                        sharpness: 1.2,
                        denoise: true,
                        resize: true,
                        maxWidth: 1920,
                        maxHeight: 1080
                    },
                    fastMode: {
                        brightness: 1.1,
                        contrast: 1.2,
                        sharpness: 1.0,
                        denoise: false,
                        resize: true,
                        maxWidth: 1280,
                        maxHeight: 720
                    },
                    numberOptimized: {
                        brightness: 1.3,
                        contrast: 1.5,
                        sharpness: 1.3,
                        denoise: true,
                        resize: true,
                        maxWidth: 1600,
                        maxHeight: 900
                    }
                };

                return processingPresets[preset] || processingPresets.highAccuracy;
            }

            parseRecognitionResult(text, confidence = 0) {
                console.log('开始高级文本解析...');

                // 使用高级文本解析器
                const parseResults = textParser.parseText(text, confidence);

                // 处理产品编码结果
                if (parseResults.productCode) {
                    const productCode = parseResults.productCode.code;
                    const patternName = parseResults.productCode.pattern;
                    const patternConfidence = Math.round(parseResults.productCode.confidence * 100);

                    // 使用高级验证系统
                    const validation = productCodeValidator.validateProductCode(
                        productCode,
                        currentProductCode,
                        patternConfidence,
                        patternName
                    );

                    // 显示详细的验证结果
                    this.displayValidationResult(validation);

                } else {
                    showProductMatch('⚠️ 未识别到有效的10位产品编码', 'error');

                    // 记录未识别的情况
                    const validation = productCodeValidator.validateProductCode(
                        null,
                        currentProductCode,
                        confidence,
                        '未识别'
                    );
                }

                // 处理数量结果
                if (parseResults.quantity) {
                    const quantity = parseResults.quantity.quantity;
                    const patternName = parseResults.quantity.pattern;
                    const patternConfidence = Math.round(parseResults.quantity.confidence * 100);

                    // 使用智能表单控制器填充数量
                    const fillResult = formController.fillQuantity(
                        quantity,
                        patternName,
                        patternConfidence
                    );

                    if (fillResult.success) {
                        if (fillResult.wasAdjusted) {
                            showStatus(
                                `识别到数量${quantity} (${patternName})，已调整为${fillResult.value}`,
                                'warning'
                            );
                        } else {
                            showStatus(
                                `已自动填充数量：${fillResult.value} (${patternName}, ${patternConfidence}%)`,
                                'success',
                                true
                            );
                        }
                    } else {
                        showStatus(`数量填充失败：${fillResult.reason}`, 'error');
                    }
                }

                // 处理WOXPJ编码结果
                if (parseResults.woxpjCode) {
                    const lastThreeDigits = parseResults.woxpjCode.lastThreeDigits;
                    const patternName = parseResults.woxpjCode.pattern;
                    const patternConfidence = Math.round(parseResults.woxpjCode.confidence * 100);

                    if (lastThreeDigits) {
                        // 使用智能表单控制器填充备注
                        const fillResult = formController.fillRemark(
                            lastThreeDigits,
                            patternName,
                            patternConfidence
                        );

                        if (fillResult.success) {
                            showStatus(
                                `已自动填充备注：${fillResult.value} (${patternName}, ${patternConfidence}%)`,
                                'success',
                                true
                            );
                        } else {
                            showStatus(`备注填充失败：${fillResult.reason}`, 'error');
                        }
                    }
                }

                // 显示解析统计信息
                const stats = textParser.getParsingStats(parseResults);
                console.log('解析统计:', stats);

                // 如果综合置信度较低，给出提示
                if (parseResults.overallConfidence < 70) {
                    showStatus(
                        `识别置信度较低 (${parseResults.overallConfidence}%)，建议检查识别结果`,
                        'warning'
                    );
                }

                // 记录详细的识别结果
                this._logAdvancedRecognitionResults(parseResults);

                return parseResults;
            }

            displayValidationResult(validation) {
                const feedback = validation.visualFeedback;

                // 构建显示消息
                let message = `${feedback.icon} ${feedback.title}\n${feedback.message}`;

                if (feedback.details.length > 0) {
                    message += '\n\n' + feedback.details.join('\n');
                }

                // 显示主要反馈
                showProductMatch(message, feedback.type);

                // 显示建议
                if (validation.suggestions.length > 0) {
                    const suggestions = validation.suggestions
                        .map(s => `${this.getSuggestionIcon(s.type)} ${s.message}`)
                        .join('\n');

                    setTimeout(() => {
                        showStatus(`建议：\n${suggestions}`, 'info');
                    }, 1000);
                }

                // 如果有操作按钮，显示相关提示
                if (feedback.actionButtons.length > 0) {
                    const actions = feedback.actionButtons.map(btn => btn.text).join('、');
                    setTimeout(() => {
                        showStatus(`可选操作：${actions}`, 'warning');
                    }, 2000);
                }

                // 记录验证日志
                console.log('产品编码验证结果:', validation);
            }

            getSuggestionIcon(type) {
                const icons = {
                    error: '❌',
                    warning: '⚠️',
                    info: 'ℹ️',
                    success: '✅'
                };
                return icons[type] || 'ℹ️';
            }

            _logAdvancedRecognitionResults(results) {
                console.log('高级解析结果汇总:', {
                    产品编码: results.productCode ? {
                        编码: results.productCode.code,
                        模式: results.productCode.pattern,
                        置信度: results.productCode.confidence
                    } : null,
                    数量: results.quantity ? {
                        数量: results.quantity.quantity,
                        模式: results.quantity.pattern,
                        置信度: results.quantity.confidence
                    } : null,
                    WOXPJ编码: results.woxpjCode ? {
                        原始编码: results.woxpjCode.code,
                        后三位: results.woxpjCode.lastThreeDigits,
                        模式: results.woxpjCode.pattern
                    } : null,
                    综合置信度: results.overallConfidence + '%',
                    原始文本长度: results.rawText.length,
                    清理后文本长度: results.cleanText.length
                });

                // 显示验证统计
                const stats = productCodeValidator.getValidationStats();
                console.log('验证统计:', stats);
            }

            // 手动切换识别模式
            switchPreset(presetName) {
                if (this.presets[presetName]) {
                    this.currentPreset = presetName;
                    showStatus(`已切换到${presetName}模式`, 'success', true);
                }
            }

            // 获取当前配置信息
            getCurrentConfig() {
                return {
                    preset: this.currentPreset,
                    config: this.presets[this.currentPreset],
                    isProcessing: this.isProcessing
                };
            }
        }

        // 初始化组件
        const errorHandler = new ErrorHandler();
        const interactionManager = new InteractionManager();
        interactionManager.initStyles(); // 初始化样式
        const formController = new FormController();
        const productCodeValidator = new ProductCodeValidator();
        const textParser = new TextParser();
        const imageProcessor = new ImageProcessor();
        const ocrEngine = new OCREngine();

        // 照片预览管理器
        class PhotoPreviewManager {
            constructor() {
                this.previewDiv = document.getElementById('photoPreview');
                this.previewImage = document.getElementById('previewImage');
                this.retakeBtn = document.getElementById('retakeBtn');
                this.confirmBtn = document.getElementById('confirmPhotoBtn');
                this.currentBlob = null;

                this.initEventListeners();
            }

            initEventListeners() {
                // 重新拍照按钮
                this.retakeBtn.addEventListener('click', () => {
                    this.hidePreview();
                    statusManager.clearAll();
                    showStatus('请重新拍照', 'success');
                });

                // 确认照片按钮
                this.confirmBtn.addEventListener('click', () => {
                    if (this.currentBlob) {
                        this.hidePreview();
                        showStatus('开始识别照片...', 'processing');
                        ocrEngine.recognizeText(this.currentBlob);
                    }
                });
            }

            showPreview(blob) {
                this.currentBlob = blob;

                // 创建预览图片URL
                const imageUrl = URL.createObjectURL(blob);
                this.previewImage.src = imageUrl;

                // 显示预览界面
                this.previewDiv.style.display = 'flex';

                // 隐藏拍照按钮
                document.getElementById('captureBtn').style.display = 'none';

                // 清理之前的URL
                this.previewImage.onload = () => {
                    URL.revokeObjectURL(imageUrl);
                };
            }

            hidePreview() {
                this.previewDiv.style.display = 'none';
                document.getElementById('captureBtn').style.display = 'block';
                this.currentBlob = null;

                // 清理图片源
                if (this.previewImage.src) {
                    URL.revokeObjectURL(this.previewImage.src);
                    this.previewImage.src = '';
                }
            }
        }

        // 初始化预览管理器
        const photoPreviewManager = new PhotoPreviewManager();

        // 显示照片预览的便捷函数
        function showPhotoPreview(blob) {
            photoPreviewManager.showPreview(blob);
        }

        // 兼容性函数
        function recognizeText(imageData) {
            return ocrEngine.recognizeText(imageData);
        }

        // 页面加载完成后的初始化
        document.addEventListener('DOMContentLoaded', function () {
            // 检查相机支持
            if (!cameraController.isSupported()) {
                document.getElementById('startCamera').style.display = 'none';
                document.getElementById('captureBtn').style.display = 'none';
                document.getElementById('autoRecognize').style.display = 'none';
                showStatus('您的浏览器不支持相机功能，请使用图片上传功能', 'warning');
            }

            // 自动设置备注为产品编码后3位
            const productCode = currentProductCode;
            if (productCode.length >= 3) {
                document.getElementById('remarkInput').value = productCode.slice(-3);
            }

            // OCR配置面板事件处理
            document.querySelectorAll('input[name="ocrPreset"]').forEach(radio => {
                radio.addEventListener('change', function () {
                    if (this.checked) {
                        ocrEngine.switchPreset(this.value);
                    }
                });
            });

            // 图像预处理配置事件处理
            const brightnessSlider = document.getElementById('brightnessSlider');
            const contrastSlider = document.getElementById('contrastSlider');
            const sharpnessSlider = document.getElementById('sharpnessSlider');
            const denoiseSwitch = document.getElementById('denoiseSwitch');

            const brightnessValue = document.getElementById('brightnessValue');
            const contrastValue = document.getElementById('contrastValue');
            const sharpnessValue = document.getElementById('sharpnessValue');

            // 滑块事件处理
            brightnessSlider.addEventListener('input', function () {
                brightnessValue.textContent = this.value;
                updateImageProcessingOptions();
            });

            contrastSlider.addEventListener('input', function () {
                contrastValue.textContent = this.value;
                updateImageProcessingOptions();
            });

            sharpnessSlider.addEventListener('input', function () {
                sharpnessValue.textContent = this.value;
                updateImageProcessingOptions();
            });

            denoiseSwitch.addEventListener('change', function () {
                updateImageProcessingOptions();
            });

            // 更新图像处理选项
            function updateImageProcessingOptions() {
                const options = {
                    brightness: parseFloat(brightnessSlider.value),
                    contrast: parseFloat(contrastSlider.value),
                    sharpness: parseFloat(sharpnessSlider.value),
                    denoise: denoiseSwitch.checked
                };
                imageProcessor.updateOptions(options);
            }

            // 重置按钮
            document.getElementById('resetProcessing').addEventListener('click', function () {
                brightnessSlider.value = 1.2;
                contrastSlider.value = 1.3;
                sharpnessSlider.value = 1.1;
                denoiseSwitch.checked = true;

                brightnessValue.textContent = '1.2';
                contrastValue.textContent = '1.3';
                sharpnessValue.textContent = '1.1';

                updateImageProcessingOptions();
                showStatus('已重置为默认预处理参数', 'success', true);
            });

            // 预览效果按钮
            document.getElementById('previewProcessing').addEventListener('click', function () {
                if (photoPreviewManager.currentBlob) {
                    showStatus('正在生成预处理预览...', 'processing');

                    imageProcessor.processImage(photoPreviewManager.currentBlob)
                        .then(processedBlob => {
                            const previewUrl = URL.createObjectURL(processedBlob);
                            const previewWindow = window.open('', '_blank', 'width=600,height=400');
                            previewWindow.document.write(`
                                <html>
                                    <head><title>图像预处理预览</title></head>
                                    <body style="margin:0;display:flex;justify-content:center;align-items:center;background:#000;">
                                        <img src="${previewUrl}" style="max-width:100%;max-height:100%;" />
                                    </body>
                                </html>
                            `);
                            showStatus('预处理预览已打开', 'success', true);
                        })
                        .catch(error => {
                            showStatus('预览生成失败：' + error.message, 'error');
                        });
                } else {
                    showStatus('请先拍照后再预览处理效果', 'warning');
                }
            });

            // 验证统计相关事件处理
            document.getElementById('clearValidationHistory').addEventListener('click', function () {
                productCodeValidator.clearHistory();
                updateValidationStats();
                showStatus('验证历史已清除', 'success', true);
            });

            document.getElementById('showValidationDetails').addEventListener('click', function () {
                const stats = productCodeValidator.getValidationStats();

                if (stats.totalValidations === 0) {
                    showStatus('暂无验证记录', 'info');
                    return;
                }

                let details = `验证详情：\n`;
                details += `总次数：${stats.totalValidations}\n`;
                details += `成功率：${stats.successRate}%\n`;
                details += `平均置信度：${stats.averageConfidence}%\n\n`;

                if (stats.recentValidations.length > 0) {
                    details += `最近验证记录：\n`;
                    stats.recentValidations.forEach((v, i) => {
                        const time = new Date(v.timestamp).toLocaleTimeString();
                        details += `${i + 1}. ${time} - ${v.matchType} (${v.matchScore}分)\n`;
                    });
                }

                // 在新窗口显示详情
                const detailWindow = window.open('', '_blank', 'width=500,height=400');
                detailWindow.document.write(`
                    <html>
                        <head><title>验证统计详情</title></head>
                        <body style="font-family:monospace;padding:20px;white-space:pre-line;">
                            ${details}
                        </body>
                    </html>
                `);
            });

            // 更新验证统计显示
            function updateValidationStats() {
                const stats = productCodeValidator.getValidationStats();
                document.getElementById('totalValidations').textContent = stats.totalValidations;
                document.getElementById('successRate').textContent = stats.successRate;
                document.getElementById('averageConfidence').textContent = stats.averageConfidence;
            }

            // 定期更新统计显示
            setInterval(updateValidationStats, 2000);

            // 表单控制相关事件处理
            document.getElementById('enableQuantityFill').addEventListener('change', function () {
                formController.updateSettings({ enableQuantityFill: this.checked });
                showStatus(`数量自动填充已${this.checked ? '启用' : '禁用'}`, 'info', true);
            });

            document.getElementById('enableRemarkFill').addEventListener('change', function () {
                formController.updateSettings({ enableRemarkFill: this.checked });
                showStatus(`备注自动填充已${this.checked ? '启用' : '禁用'}`, 'info', true);
            });

            document.getElementById('showFillAnimation').addEventListener('change', function () {
                formController.updateSettings({ showFillAnimation: this.checked });
                showStatus(`填充动画已${this.checked ? '启用' : '禁用'}`, 'info', true);
            });

            document.getElementById('resetForm').addEventListener('click', function () {
                if (confirm('确定要重置表单吗？这将清除所有已填写的内容。')) {
                    formController.resetForm();
                }
            });

            document.getElementById('showFillHistory').addEventListener('click', function () {
                formController.showFillHistory();
            });

            // 添加键盘快捷键支持
            document.addEventListener('keydown', function (e) {
                // 按空格键拍照（仅在相机激活时且没有预览时）
                if (e.code === 'Space' && cameraController.isActive && photoPreviewManager.previewDiv.style.display !== 'flex') {
                    e.preventDefault();
                    document.getElementById('captureBtn').click();
                }

                // 按Escape键关闭相机或隐藏预览
                if (e.code === 'Escape') {
                    if (photoPreviewManager.previewDiv.style.display === 'flex') {
                        photoPreviewManager.hidePreview();
                    } else if (cameraController.isActive) {
                        document.getElementById('startCamera').click();
                    }
                }

                // 按Enter键确认照片（在预览模式下）
                if (e.code === 'Enter' && photoPreviewManager.previewDiv.style.display === 'flex') {
                    e.preventDefault();
                    document.getElementById('confirmPhotoBtn').click();
                }
            });

            // 添加拍照按钮的触摸反馈
            const captureBtn = document.getElementById('captureBtn');
            let touchStartTime = 0;

            captureBtn.addEventListener('touchstart', function (e) {
                touchStartTime = Date.now();
                this.style.transform = 'translateX(-50%) scale(0.9)';
            });

            captureBtn.addEventListener('touchend', function (e) {
                e.preventDefault(); // 防止触发click事件
                this.style.transform = 'translateX(-50%) scale(1)';
                const touchDuration = Date.now() - touchStartTime;

                // 短按拍照，长按显示提示
                if (touchDuration < 500) {
                    // 触发拍照
                    handleCaptureButtonClick.call(this, e);
                } else {
                    showStatus('💡 提示：短按拍照，长按可查看更多选项', 'success', true);
                }
            });

            // 也添加click事件作为备用
            captureBtn.addEventListener('click', handleCaptureButtonClick);
        });

        // 状态管理器
        class StatusManager {
            constructor() {
                this.statusDiv = document.getElementById('recognitionStatus');
                this.matchDiv = document.getElementById('productMatch');
                this.resultDiv = document.getElementById('ocrResult');
            }

            showStatus(message, type, autoHide = false) {
                this.statusDiv.style.display = 'block';
                this.statusDiv.textContent = message;
                this.statusDiv.className = `recognition-status status-${type}`;

                // 添加图标
                const icons = {
                    processing: '⏳',
                    success: '✅',
                    error: '❌',
                    warning: '⚠️'
                };

                if (icons[type]) {
                    this.statusDiv.textContent = `${icons[type]} ${message}`;
                }

                // 自动隐藏
                if (autoHide && type === 'success') {
                    setTimeout(() => {
                        this.statusDiv.style.display = 'none';
                    }, 3000);
                }
            }

            showMatch(message, type) {
                this.matchDiv.style.display = 'block';
                this.matchDiv.textContent = message;
                this.matchDiv.className = `product-match match-${type}`;
            }

            showResult(text) {
                this.resultDiv.style.display = 'block';
                this.resultDiv.textContent = `识别结果：\n${text}`;
            }

            clearAll() {
                this.statusDiv.style.display = 'none';
                this.matchDiv.style.display = 'none';
                this.resultDiv.style.display = 'none';
            }
        }

        // 初始化状态管理器
        const statusManager = new StatusManager();

        // 兼容性函数
        function showStatus(message, type, autoHide = false) {
            statusManager.showStatus(message, type, autoHide);
        }

        function showProductMatch(message, type) {
            statusManager.showMatch(message, type);
        }
    </script>
</body>

</html>