<?php
session_start();
require_once 'config.php';
require_once 'operation_logs_helper.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

// 检查并添加 deleted_at 字段（如果不存在）
try {
    $check = $pdo->query("SHOW COLUMNS FROM production_plans LIKE 'deleted_at'");
    if ($check->rowCount() == 0) {
        // 字段不存在，添加它
        $pdo->exec("
            ALTER TABLE production_plans 
            ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL 
            AFTER created_at
        ");
        // 添加索引
        try {
            $pdo->exec("CREATE INDEX idx_deleted_at ON production_plans(deleted_at)");
        } catch (PDOException $e) {
            // 索引可能已存在，忽略错误
        }
    }
} catch (PDOException $e) {
    // 忽略检查错误，继续执行
}

// 获取计划ID
if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$plan_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === 'admin';

// 获取计划信息
try {
    if ($is_admin) {
        $stmt = $pdo->prepare("SELECT * FROM production_plans WHERE id = ?");
        $stmt->execute([$plan_id]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM production_plans WHERE id = ? AND user_id = ?");
        $stmt->execute([$plan_id, $user_id]);
    }
    $plan = $stmt->fetch();
    
    if (!$plan) {
        header('Location: index.php');
        exit;
    }
} catch(PDOException $e) {
    $error = '获取计划信息失败：' . $e->getMessage();
}

// 处理删除请求（软删除，移到回收站）
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_delete'])) {
    try {
        // 软删除：设置 deleted_at 字段
        if ($is_admin) {
            $stmt = $pdo->prepare("UPDATE production_plans SET deleted_at = NOW() WHERE id = ?");
            $stmt->execute([$plan_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE production_plans SET deleted_at = NOW() WHERE id = ? AND user_id = ?");
            $stmt->execute([$plan_id, $user_id]);
        }
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('计划不存在或无权限删除');
        }
        
        // 记录操作日志
        log_operation($pdo, $user_id, $username, 'delete_plan', 'plan', $plan_id, 'plan',
            "删除计划：{$plan['plan_name']}（产品编码：{$plan['product_code']}，计划数量：{$plan['planned_quantity']}）",
            ['plan_name' => $plan['plan_name'], 'product_code' => $plan['product_code'], 'planned_quantity' => $plan['planned_quantity']], null);
        
        $success = '计划已移至回收站！';
        header('Location: index.php?success=1');
        exit;
    } catch(PDOException $e) {
        $error = '删除失败：' . $e->getMessage();
    } catch(Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>删除计划 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card { 
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .btn {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="report.php">一键报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="js.php">尾数计算</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="repeat_check.php">重复检测</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="trash.php">回收站</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_dashboard.php?page=users">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">删除计划</h1>
            <a href="index.php" class="btn btn-secondary">返回主页</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="alert alert-warning">
                    <h5 class="alert-heading">提示</h5>
                    <p>您确定要删除以下计划吗？删除后的计划将移至回收站，可以从回收站恢复。</p>
                </div>

                <div class="mb-4">
                    <h5>计划信息</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>计划名称：</strong><?php echo htmlspecialchars($plan['plan_name']); ?></p>
                            <p><strong>计划日期：</strong><?php echo $plan['plan_date']; ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>计划数量：</strong><?php echo $plan['planned_quantity']; ?></p>
                            <p><strong>创建时间：</strong><?php echo $plan['created_at']; ?></p>
                        </div>
                    </div>
                </div>

                <form method="POST">
                    <div class="d-grid gap-2">
                        <button type="submit" name="confirm_delete" class="btn btn-danger">确认删除</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 