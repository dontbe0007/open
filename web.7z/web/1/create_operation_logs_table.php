<?php
/**
 * 创建操作日志表
 * 用于记录系统所有关键操作
 */

require_once 'config.php';

try {
    $pdo->beginTransaction();
    
    echo "<h2>创建操作日志表...</h2>";
    echo "<pre>";
    
    // 创建操作日志表
    echo "正在创建 operation_logs 表...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `operation_logs` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
            `action_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型：create_plan, update_plan, delete_plan, outbound, inbound, update_inventory, delete_inventory, create_user, delete_user, backup, restore等',
            `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模块：plan, outbound, inbound, inventory, user, system等',
            `target_id` int(11) DEFAULT NULL COMMENT '目标记录ID',
            `target_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标类型：plan, outbound_record, inbound_record, inventory, user等',
            `description` text COLLATE utf8mb4_unicode_ci COMMENT '操作描述',
            `old_data` text COLLATE utf8mb4_unicode_ci COMMENT '操作前数据（JSON格式）',
            `new_data` text COLLATE utf8mb4_unicode_ci COMMENT '操作后数据（JSON格式）',
            `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
            `user_agent` text COLLATE utf8mb4_unicode_ci COMMENT '用户代理',
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `user_id` (`user_id`),
            KEY `action_type` (`action_type`),
            KEY `module` (`module`),
            KEY `target_id` (`target_id`),
            KEY `created_at` (`created_at`),
            CONSTRAINT `operation_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ operation_logs 表创建成功\n\n";
    
    $pdo->commit();
    
    echo "</pre>";
    echo "<h3 style='color: green;'>✓ 操作日志表创建成功！</h3>";
    echo "<p><a href='operation_logs.php' class='btn btn-primary'>查看操作日志</a></p>";
    echo "<p><a href='index.php' class='btn btn-secondary'>返回主页</a></p>";
    
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "</pre>";
    echo "<h3 style='color: red;'>✗ 创建表失败</h3>";
    echo "<p style='color: red;'>错误信息：" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><a href='index.php'>返回主页</a></p>";
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>创建操作日志表</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- PHP输出内容会显示在这里 -->
    </div>
</body>
</html>


