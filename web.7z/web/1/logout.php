<?php
// 设置session配置
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));

session_start();
require_once 'config.php';
require_once 'operation_logs_helper.php';

// 记录登出日志（在session销毁前）
if (isset($_SESSION['user_id']) && isset($_SESSION['username'])) {
    try {
        log_operation($pdo, $_SESSION['user_id'], $_SESSION['username'], 'logout', 'system', null, null,
            "用户登出：{$_SESSION['username']}", null, null);
    } catch (Exception $e) {
        // 忽略日志记录错误
    }
}

// 清除所有会话数据
session_unset();

// 销毁会话
session_destroy();

// 重定向到登录页面
header('Location: login.php');
exit; 