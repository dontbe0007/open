<?php
/**
 * 操作日志查看页面
 * 管理员可以查看所有操作日志
 */

session_start();
require_once 'config.php';
require_once 'operation_logs_helper.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

// 只有管理员和仓管可以查看操作日志
if (!$is_admin && !$is_storage) {
    header('Location: index.php');
    exit;
}

// 获取查询参数
$search_user = trim($_GET['search_user'] ?? '');
$search_action = trim($_GET['search_action'] ?? '');
$search_module = trim($_GET['search_module'] ?? '');
$start_date = trim($_GET['start_date'] ?? '');
$end_date = trim($_GET['end_date'] ?? '');
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 50;
$offset = ($page - 1) * $per_page;

// 构建查询条件
$where_conditions = [];
$params = [];

if (!empty($search_user)) {
    $where_conditions[] = "username LIKE ?";
    $params[] = '%' . $search_user . '%';
}

if (!empty($search_action)) {
    $where_conditions[] = "action_type = ?";
    $params[] = $search_action;
}

if (!empty($search_module)) {
    $where_conditions[] = "module = ?";
    $params[] = $search_module;
}

if (!empty($start_date)) {
    $where_conditions[] = "DATE(created_at) >= ?";
    $params[] = $start_date;
}

if (!empty($end_date)) {
    $where_conditions[] = "DATE(created_at) <= ?";
    $params[] = $end_date;
}

$where_sql = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// 获取总记录数
try {
    $count_sql = "SELECT COUNT(*) as total FROM operation_logs $where_sql";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_records = $count_stmt->fetch()['total'];
    $total_pages = ceil($total_records / $per_page);
    
    // 获取日志记录
    // LIMIT和OFFSET不能使用占位符，需要直接拼接
    $sql = "SELECT * FROM operation_logs $where_sql ORDER BY created_at DESC LIMIT " . (int)$per_page . " OFFSET " . (int)$offset;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 获取所有操作类型和模块（用于筛选）
    $action_types = $pdo->query("SELECT DISTINCT action_type FROM operation_logs ORDER BY action_type")->fetchAll(PDO::FETCH_COLUMN);
    $modules = $pdo->query("SELECT DISTINCT module FROM operation_logs ORDER BY module")->fetchAll(PDO::FETCH_COLUMN);
    
} catch (PDOException $e) {
    $error = "查询失败：" . $e->getMessage();
    $logs = [];
    $total_records = 0;
    $total_pages = 0;
    $action_types = [];
    $modules = [];
}

// 处理导出请求
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="operation_logs_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // 输出BOM，解决中文乱码
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // 输出表头
    fputcsv($output, ['ID', '时间', '用户', '操作类型', '模块', '目标ID', '描述', 'IP地址']);
    
    // 输出数据
    try {
        $export_sql = "SELECT id, created_at, username, action_type, module, target_id, description, ip_address 
                       FROM operation_logs $where_sql ORDER BY created_at DESC";
        $export_stmt = $pdo->prepare($export_sql);
        $export_stmt->execute($params);
        
        while ($row = $export_stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [
                $row['id'],
                $row['created_at'],
                $row['username'],
                get_action_type_name($row['action_type']),
                get_module_name($row['module']),
                $row['target_id'] ?? '',
                $row['description'] ?? '',
                $row['ip_address'] ?? ''
            ]);
        }
    } catch (PDOException $e) {
        // 错误处理
    }
    
    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>操作日志 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .table {
            font-size: 14px;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .badge-action {
            font-size: 12px;
            padding: 4px 8px;
        }
        .log-detail {
            max-width: 300px;
            word-break: break-word;
        }
        .search-form {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_dashboard.php">后台管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="operation_logs.php">操作日志</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">返回主页</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">📋 操作日志</h1>
            <div>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'csv'])); ?>" class="btn btn-success">
                    📥 导出CSV
                </a>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- 搜索表单 -->
        <div class="search-form">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">用户名</label>
                    <input type="text" name="search_user" class="form-control" 
                           value="<?php echo htmlspecialchars($search_user); ?>" 
                           placeholder="搜索用户名">
                </div>
                <div class="col-md-2">
                    <label class="form-label">操作类型</label>
                    <select name="search_action" class="form-control">
                        <option value="">全部</option>
                        <?php foreach ($action_types as $type): ?>
                            <option value="<?php echo htmlspecialchars($type); ?>" 
                                    <?php echo $search_action === $type ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars(get_action_type_name($type)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">模块</label>
                    <select name="search_module" class="form-control">
                        <option value="">全部</option>
                        <?php foreach ($modules as $mod): ?>
                            <option value="<?php echo htmlspecialchars($mod); ?>" 
                                    <?php echo $search_module === $mod ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars(get_module_name($mod)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">开始日期</label>
                    <input type="date" name="start_date" class="form-control" 
                           value="<?php echo htmlspecialchars($start_date); ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">结束日期</label>
                    <input type="date" name="end_date" class="form-control" 
                           value="<?php echo htmlspecialchars($end_date); ?>">
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">搜索</button>
                </div>
            </form>
            <?php if (!empty($search_user) || !empty($search_action) || !empty($search_module) || !empty($start_date) || !empty($end_date)): ?>
                <div class="mt-2">
                    <a href="operation_logs.php" class="btn btn-sm btn-secondary">清除筛选</a>
                </div>
            <?php endif; ?>
        </div>

        <!-- 统计信息 -->
        <div class="card">
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-3">
                        <h5 class="text-primary"><?php echo number_format($total_records); ?></h5>
                        <small class="text-muted">总记录数</small>
                    </div>
                    <div class="col-md-3">
                        <h5 class="text-success"><?php echo number_format(count($logs)); ?></h5>
                        <small class="text-muted">当前页记录</small>
                    </div>
                    <div class="col-md-3">
                        <h5 class="text-info"><?php echo $total_pages; ?></h5>
                        <small class="text-muted">总页数</small>
                    </div>
                    <div class="col-md-3">
                        <h5 class="text-warning"><?php echo $page; ?></h5>
                        <small class="text-muted">当前页</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- 日志列表 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">日志记录</h5>
            </div>
            <div class="card-body">
                <?php if (empty($logs)): ?>
                    <p class="text-muted text-center">暂无日志记录</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>时间</th>
                                    <th>用户</th>
                                    <th>操作类型</th>
                                    <th>模块</th>
                                    <th>描述</th>
                                    <th>IP地址</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td><?php echo date('m-d H:i:s', strtotime($log['created_at'])); ?></td>
                                        <td><?php echo htmlspecialchars($log['username']); ?></td>
                                        <td>
                                            <span class="badge bg-primary badge-action">
                                                <?php echo htmlspecialchars(get_action_type_name($log['action_type'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-info badge-action">
                                                <?php echo htmlspecialchars(get_module_name($log['module'])); ?>
                                            </span>
                                        </td>
                                        <td class="log-detail">
                                            <?php echo htmlspecialchars($log['description'] ?? '无'); ?>
                                        </td>
                                        <td>
                                            <small><?php echo htmlspecialchars($log['ip_address'] ?? '未知'); ?></small>
                                        </td>
                                        <td>
                                            <?php if ($log['old_data'] || $log['new_data']): ?>
                                                <button type="button" class="btn btn-sm btn-outline-info" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#detailModal<?php echo $log['id']; ?>">
                                                    详情
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <!-- 详情模态框 -->
                                    <?php if ($log['old_data'] || $log['new_data']): ?>
                                    <div class="modal fade" id="detailModal<?php echo $log['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">操作详情 - <?php echo htmlspecialchars(get_action_type_name($log['action_type'])); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <?php if ($log['old_data']): ?>
                                                        <div class="col-md-6">
                                                            <h6>操作前数据：</h6>
                                                            <pre style="background: #f8f9fa; padding: 10px; border-radius: 5px; max-height: 300px; overflow-y: auto;"><?php 
                                                                $old = json_decode($log['old_data'], true);
                                                                echo htmlspecialchars(json_encode($old, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                                                            ?></pre>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if ($log['new_data']): ?>
                                                        <div class="col-md-6">
                                                            <h6>操作后数据：</h6>
                                                            <pre style="background: #f8f9fa; padding: 10px; border-radius: 5px; max-height: 300px; overflow-y: auto;"><?php 
                                                                $new = json_decode($log['new_data'], true);
                                                                echo htmlspecialchars(json_encode($new, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                                                            ?></pre>
                                                        </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if ($log['user_agent']): ?>
                                                    <div class="mt-3">
                                                        <small class="text-muted">用户代理: <?php echo htmlspecialchars($log['user_agent']); ?></small>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- 分页 -->
                    <?php if ($total_pages > 1): ?>
                    <nav aria-label="日志分页">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">上一页</a>
                                </li>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">下一页</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.js"></script>
</body>
</html>

