<?php
/**
 * 网站头部SEO代码包含文件
 * 在<head>标签结束前输出
 */
if (!function_exists('get_site_setting')) {
    require_once 'get_site_setting.php';
}

// 获取头部SEO代码
$head_seo = get_site_setting('head_seo', '');

// 输出头部SEO代码（在</head>之前）
if (!empty($head_seo)) {
    echo $head_seo;
}
?>

