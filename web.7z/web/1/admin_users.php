<?php
// 用户管理页面
?>

<div class="content-header">
    <h2><i class="bi bi-people"></i> 用户管理</h2>
</div>

<div class="content-body">
    <?php if (!empty($user_success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($user_success); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($user_error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($user_error); ?></div>
    <?php endif; ?>
    
    <!-- 添加用户表单 -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-person-plus"></i> 添加新用户</h5>
        </div>
        <div class="card-body">
            <form method="POST" class="row g-3">
                <input type="hidden" name="user_action" value="add">
                <div class="col-md-3">
                    <label class="form-label">用户名</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">密码</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">角色</label>
                    <select name="role" class="form-control" required>
                        <option value="user">普通用户</option>
                        <option value="storage">仓管</option>
                        <option value="admin">管理员</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">添加用户</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 用户列表 -->
    <div class="card">
        <div class="card-header bg-light">
            <h5 class="mb-0"><i class="bi bi-list-ul"></i> 用户列表</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>用户名</th>
                            <th>角色</th>
                            <th>创建时间</th>
                            <th>最后登录</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($all_users)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">暂无用户</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($all_users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td>
                                        <?php
                                        $role_names = ['user' => '普通用户', 'storage' => '仓管', 'admin' => '管理员'];
                                        $role_badges = ['user' => 'secondary', 'storage' => 'info', 'admin' => 'danger'];
                                        $role = $user['role'];
                                        ?>
                                        <span class="badge bg-<?php echo $role_badges[$role] ?? 'secondary'; ?>">
                                            <?php echo $role_names[$role] ?? $role; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($user['created_at'])); ?></td>
                                    <td><?php echo $user['last_login'] ? date('Y-m-d H:i', strtotime($user['last_login'])) : '从未登录'; ?></td>
                                    <td>
                                        <?php if ($user['id'] != $user_id): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('确定要删除用户 <?php echo htmlspecialchars($user['username']); ?> 吗？');">
                                                <input type="hidden" name="user_action" value="delete">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="bi bi-trash"></i> 删除
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted">当前用户</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


