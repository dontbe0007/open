<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;
// 初始化变量为空
$planned = '';
$shipped = '';
$toShip = '';
$adjustment = 0;
$showResult = false;

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $planned = (int)($_POST['planned'] ?? 0);
    $shipped = (int)($_POST['shipped'] ?? 0);
    $toShip = (int)($_POST['to_ship'] ?? 0);
    $showResult = true;
    
    // 计算计划调整量
    $requiredTotal = $shipped + $toShip;
    $adjustment = $requiredTotal - $planned;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>尾数计算 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card, .calculator {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 15px;
        }
        h2, .h2 {
            color: #2c3e50;
            text-align: center;
            margin-top: 0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #3498db;
        }
        input[type="number"], .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            box-sizing: border-box;
        }
        button, .btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s;
        }
        button:hover, .btn:hover {
            background: #2980b9;
        }
        .result {
            margin-top: 25px;
            padding: 20px;
            background: #e8f4fc;
            border-radius: 6px;
            border-left: 4px solid #3498db;
        }
        .highlight {
            font-weight: bold;
            color: #e74c3c;
            font-size: 1.2em;
        }
        .explanation {
            margin-top: 15px;
            line-height: 1.5;
        }
        .note {
            margin-top: 15px;
            padding: 10px;
            background: #fff8e1;
            border-radius: 4px;
            border-left: 3px solid #ffc107;
            font-size: 0.9em;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light mb-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">仓库管理系统</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 flex-row flex-wrap">
                <li class="nav-item"><a class="nav-link" href="index.php">排产计划</a></li>
                <li class="nav-item"><a class="nav-link" href="daily_report.php">日报表</a></li>
                <li class="nav-item"><a class="nav-link" href="report.php">一键报表</a></li>
                <li class="nav-item"><a class="nav-link active" href="js.php">尾数计算</a></li>
                <li class="nav-item"><a class="nav-link" href="repeat_check.php">重复检测</a></li>
                <li class="nav-item"><a class="nav-link" href="product_outbound_records.php">产品出库记录</a></li>
                <li class="nav-item"><a class="nav-link" href="navigation.php">不迷路</a></li>
                <?php if ($is_admin): ?>
                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php?page=users">用户管理</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav mb-2 mb-lg-0 flex-row flex-wrap">
                <li class="nav-item"><span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span></li>
                <li class="nav-item"><a class="nav-link" href="change_password.php">修改密码</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">退出</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="card calculator">
        <h2>出库计划调整计算器</h2>
        <form method="post">
            <div class="form-group">
                <label for="planned">原计划数量：</label>
                <input type="number" id="planned" name="planned" value="<?= $planned ?>" min="0" required placeholder="请输入原计划数量">
            </div>
            
            <div class="form-group">
                <label for="shipped">已出库数量：</label>
                <input type="number" id="shipped" name="shipped" value="<?= $shipped ?>" min="0" required placeholder="请输入已出库数量">
            </div>
            
            <div class="form-group">
                <label for="to_ship">需要出库数量：</label>
                <input type="number" id="to_ship" name="to_ship" value="<?= $toShip ?>" min="0" required placeholder="请输入需要出库数量">
            </div>
            
            <button type="submit" class="btn btn-primary">计算计划调整量</button>
        </form>
        
        <?php if ($showResult): ?>
        <div class="result">
            <h3>计算结果：</h3>
            <p>计划需要调整量：<span class="highlight"><?= $adjustment >= 0 ? "+".$adjustment : $adjustment ?></span></p>
            
            <div class="explanation">
                <p>计算说明：</p>
                <ul>
                    <li>实际需要总量 = 已出库(<?= $shipped ?>) + 需出库(<?= $toShip ?>) = <strong><?= $shipped + $toShip ?></strong></li>
                    <li>计划调整量 = 实际需要总量 - 原计划(<?= $planned ?>)</li>
                    <li>调整后计划量：<strong><?= $planned + $adjustment ?></strong></li>
                </ul>
                <p>操作建议：</p>
                <p><?= 
                    $adjustment > 0 
                    ? "计划量需要 <strong class='highlight'>增加 {$adjustment}</strong> 才能完成出库" 
                    : ($adjustment < 0 
                        ? "计划量可以 <strong class='highlight'>减少 " . abs($adjustment) . "</strong>" 
                        : "计划量<strong class='highlight'>无需调整</strong>")
                ?></p>
            </div>
            
            <div class="note">
                <p>提示：正数(+)表示需要增加计划量，负数(-)表示可以减少计划量</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>