<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', '3nnmxnj28i222');
define('DB_USER', '3nnmxnj28i222');
define('DB_PASS', 'qq14856857');


// 用户角色定义
define('ROLE_ADMIN', 'admin');
define('ROLE_STORAGE', 'storage');  // 添加仓管角色
define('ROLE_USER', 'user');

// 设置时区为北京时间 (UTC+8)
date_default_timezone_set('Asia/Shanghai');

// 开启错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 设置 MySQL 时区为 UTC+8 (北京时间)
    $pdo->exec("SET time_zone = '+08:00'");
} catch(PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}
?> 