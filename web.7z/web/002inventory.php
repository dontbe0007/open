<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = $_SESSION['role'] === ROLE_ADMIN;
$is_storage = $_SESSION['role'] === ROLE_STORAGE;

$error = '';
$success = '';

// 检查并添加 deleted_at 字段（如果不存在）
try {
    $check = $pdo->query("SHOW COLUMNS FROM inventory LIKE 'deleted_at'");
    if ($check->rowCount() == 0) {
        // 字段不存在，添加它
        $pdo->exec("
            ALTER TABLE inventory 
            ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL 
            AFTER updated_at
        ");
        // 添加索引
        try {
            $pdo->exec("CREATE INDEX idx_inventory_deleted_at ON inventory(deleted_at)");
        } catch (PDOException $e) {
            // 索引可能已存在，忽略错误
        }
    }
} catch (PDOException $e) {
    // 忽略检查错误，继续执行
}

// 检查并添加 remark 字段（如果不存在）
try {
    $check = $pdo->query("SHOW COLUMNS FROM inventory LIKE 'remark'");
    if ($check->rowCount() == 0) {
        // 字段不存在，添加它
        $pdo->exec("
            ALTER TABLE inventory 
            ADD COLUMN remark TEXT NULL DEFAULT NULL 
            AFTER quantity
        ");
    }
} catch (PDOException $e) {
    // 忽略检查错误，继续执行
}

// 处理添加库存
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_inventory'])) {
    $product_code = trim($_POST['product_code']);
    $location = trim($_POST['location']);
    $quantity = (int)$_POST['quantity'];
    $remark = trim($_POST['remark'] ?? '');
    
    if (empty($product_code) || empty($location) || $quantity <= 0) {
        $error = '产品编码、库位和数量都必须填写，且数量必须大于0';
    } else {
        try {
            $pdo->beginTransaction();
            
            // 检查是否已存在（包括已删除的记录）
            $stmt = $pdo->prepare("
                SELECT id, deleted_at, quantity 
                FROM inventory 
                WHERE product_code = ? AND location = ?
            ");
            $stmt->execute([$product_code, $location]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                // 如果记录存在
                if (!empty($existing['deleted_at']) && $existing['deleted_at'] !== '0000-00-00 00:00:00' && $existing['deleted_at'] !== '0000-00-00') {
                    // 如果记录已被删除，恢复它并更新数量
                    $stmt = $pdo->prepare("
                        UPDATE inventory 
                        SET deleted_at = NULL, quantity = quantity + ?, remark = COALESCE(?, remark)
                        WHERE id = ?
                    ");
                    $stmt->execute([$quantity, $remark ?: null, $existing['id']]);
                } else {
                    // 如果记录未删除，直接更新数量和备注
                    $stmt = $pdo->prepare("
                        UPDATE inventory 
                        SET quantity = quantity + ?, remark = COALESCE(?, remark)
                        WHERE id = ? AND (deleted_at IS NULL OR deleted_at = '' OR deleted_at = '0000-00-00 00:00:00' OR deleted_at = '0000-00-00')
                    ");
                    $stmt->execute([$quantity, $remark ?: null, $existing['id']]);
                }
            } else {
                // 如果记录不存在，创建新记录
                $stmt = $pdo->prepare("
                    INSERT INTO inventory (product_code, location, quantity, remark) 
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$product_code, $location, $quantity, $remark ?: null]);
            }
            
            $pdo->commit();
            $success = '添加库存成功！';
            header('Location: inventory.php?success=1');
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = '添加库存失败：' . $e->getMessage();
        }
    }
}

// 处理修改库存
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_inventory'])) {
    $inventory_id = (int)$_POST['inventory_id'];
    $new_quantity = (int)$_POST['quantity'];
    $new_location = trim($_POST['location']);
    $old_location = trim($_POST['old_location']);
    $product_code = trim($_POST['product_code']);
    $remark = trim($_POST['remark'] ?? '');
    
    if ($new_quantity < 0 || empty($new_location)) {
        $error = '数量和库位必须填写，且数量不能为负数';
    } else {
        try {
            $pdo->beginTransaction();
            
            if ($old_location == $new_location) {
                // 同一库位，直接更新数量和备注
                $stmt = $pdo->prepare("
                    UPDATE inventory 
                    SET quantity = ?, remark = ?
                    WHERE id = ?
                ");
                $stmt->execute([$new_quantity, $remark ?: null, $inventory_id]);
                
                // 如果数量为0，删除记录
                if ($new_quantity == 0) {
                    $stmt = $pdo->prepare("DELETE FROM inventory WHERE id = ?");
                    $stmt->execute([$inventory_id]);
                }
            } else {
                // 不同库位，需要移动
                // 删除旧记录
                $stmt = $pdo->prepare("DELETE FROM inventory WHERE id = ?");
                $stmt->execute([$inventory_id]);
                
                // 如果新数量大于0，在新库位创建或更新记录
                if ($new_quantity > 0) {
                    // 检查新库位是否已有记录（包括已删除的）
                    $stmt = $pdo->prepare("
                        SELECT id, deleted_at 
                        FROM inventory 
                        WHERE product_code = ? AND location = ?
                    ");
                    $stmt->execute([$product_code, $new_location]);
                    $new_existing = $stmt->fetch();
                    
                    if ($new_existing) {
                        // 如果记录存在
                        if (!empty($new_existing['deleted_at']) && $new_existing['deleted_at'] !== '0000-00-00 00:00:00' && $new_existing['deleted_at'] !== '0000-00-00') {
                            // 如果记录已被删除，恢复它并设置数量
                            $stmt = $pdo->prepare("
                                UPDATE inventory 
                                SET deleted_at = NULL, quantity = ?
                                WHERE id = ?
                            ");
                            $stmt->execute([$new_quantity, $new_existing['id']]);
                        } else {
                            // 如果记录未删除，更新数量
                            $stmt = $pdo->prepare("
                                UPDATE inventory 
                                SET quantity = ?
                                WHERE id = ?
                            ");
                            $stmt->execute([$new_quantity, $new_existing['id']]);
                        }
                    } else {
                        // 如果记录不存在，创建新记录
                        $stmt = $pdo->prepare("
                            INSERT INTO inventory (product_code, location, quantity) 
                            VALUES (?, ?, ?)
                        ");
                        $stmt->execute([$product_code, $new_location, $new_quantity]);
                    }
                }
            }
            
            $pdo->commit();
            $success = '修改成功！';
            header('Location: inventory.php?success=1');
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = '修改失败：' . $e->getMessage();
        }
    }
}

// 处理删除库存（软删除，移到回收站）
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_inventory'])) {
    $inventory_id = (int)$_POST['inventory_id'];
    
    try {
        // 软删除：设置 deleted_at 字段
        $stmt = $pdo->prepare("UPDATE inventory SET deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$inventory_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('库存记录不存在');
        }
        
        $success = '库存已移至回收站！';
        header('Location: inventory.php?success=1');
        exit;
    } catch (PDOException $e) {
        $error = '删除失败：' . $e->getMessage();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// 获取成功消息
if (isset($_GET['success'])) {
    $success = '操作成功！';
}

// 获取搜索参数
$search_product = trim($_GET['search_product'] ?? '');
$search_location = trim($_GET['search_location'] ?? '');

// 查询库存
try {
    $params = [];
    $where_conditions = [];
    
    if (!empty($search_product)) {
        $where_conditions[] = "product_code LIKE ?";
        $params[] = '%' . $search_product . '%';
    }
    
    if (!empty($search_location)) {
        $where_conditions[] = "location LIKE ?";
        $params[] = '%' . $search_location . '%';
    }
    
    // 排除已删除的库存（检查多种无效值）
    $where_conditions[] = "(deleted_at IS NULL OR deleted_at = '' OR deleted_at = '0000-00-00 00:00:00' OR deleted_at = '0000-00-00')";
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
    
    $stmt = $pdo->prepare("
        SELECT id, product_code, location, quantity, COALESCE(remark, '') as remark, updated_at, deleted_at
        FROM inventory 
        $where_sql
        ORDER BY product_code, location
    ");
    $stmt->execute($params);
    $inventory_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 确保所有记录都有remark字段
    foreach ($inventory_list as &$item) {
        if (!isset($item['remark'])) {
            $item['remark'] = '';
        }
    }
    unset($item);
    
    // 双重检查：过滤掉已删除的记录（防止数据库字段问题）
    $inventory_list = array_filter($inventory_list, function($item) {
        $deleted_at = $item['deleted_at'] ?? null;
        if (empty($deleted_at) || $deleted_at === '0000-00-00 00:00:00' || $deleted_at === '0000-00-00') {
            return true; // 保留未删除的记录
        }
        return false; // 过滤掉已删除的记录
    });
    // 重新索引数组
    $inventory_list = array_values($inventory_list);
} catch (PDOException $e) {
    $error = '查询失败：' . $e->getMessage();
    $inventory_list = [];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>库存管理 - 仓库管理系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 15px;
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0 !important;
        }
        .form-control, .btn {
            border-radius: 5px;
        }
        .alert {
            border-radius: 10px;
        }
        .table {
            background-color: white;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            color: #333 !important;
        }
        .navbar-nav .nav-link {
            color: #333 !important;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff !important;
        }
        .navbar-nav .nav-link.active {
            color: #007bff !important;
        }
        .navbar-toggler {
            border-color: rgba(0, 0, 0, 0.1);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .btn-action {
            padding: 2px 8px;
            font-size: 12px;
            margin: 2px;
        }
        .search-form {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">仓库管理系统</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">排产计划</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="daily_report.php">日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="report.php">一键报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="js.php">尾数计算</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="repeat_check.php">重复检测</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product_outbound_records.php">产品出库记录</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound.php">产品入库</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="inventory.php">库存管理</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inbound_report.php">入库日报表</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory_trash.php">库存回收站</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="trash.php">计划回收站</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="navigation.php">不迷路</a>
                    </li>
                    <?php if ($is_admin): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">用户管理</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">欢迎，<?php echo htmlspecialchars($username); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="change_password.php">修改密码</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">退出</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="h3 mb-4">库存管理</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- 搜索表单 -->
        <div class="search-form">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">按产品编码搜索</label>
                    <input type="text" name="search_product" class="form-control" 
                           value="<?php echo htmlspecialchars($search_product); ?>" 
                           placeholder="输入产品编码（支持模糊搜索）">
                </div>
                <div class="col-md-4">
                    <label class="form-label">按库位搜索</label>
                    <input type="text" name="search_location" class="form-control" 
                           value="<?php echo htmlspecialchars($search_location); ?>" 
                           placeholder="输入库位（支持模糊搜索）">
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">搜索</button>
                    <a href="inventory.php" class="btn btn-secondary">清除</a>
                </div>
            </form>
        </div>

        <!-- 添加库存表单 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">添加库存</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">产品编码 <span class="text-danger">*</span></label>
                            <input type="text" name="product_code" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">库位 <span class="text-danger">*</span></label>
                            <input type="text" name="location" class="form-control" placeholder="例如：8-11" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">数量 <span class="text-danger">*</span></label>
                            <input type="number" name="quantity" class="form-control" min="1" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">备注</label>
                            <input type="text" name="remark" class="form-control" placeholder="可选">
                        </div>
                    </div>
                    <button type="submit" name="add_inventory" class="btn btn-primary">添加库存</button>
                </form>
            </div>
        </div>

        <!-- 库存列表 -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">库存列表</h5>
            </div>
            <div class="card-body">
                <?php if (empty($inventory_list)): ?>
                    <p class="text-muted">暂无库存记录</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>编码</th>
                                    <th>库位</th>
                                    <th>数量</th>
                                    <th>备注</th>
                                    <th>时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($inventory_list as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                                        <td><?php echo htmlspecialchars($item['location']); ?></td>
                                        <td><?php echo number_format($item['quantity']); ?></td>
                                        <td><?php echo htmlspecialchars($item['remark'] ?? ''); ?></td>
                                        <td><?php echo date('m-d H:i', strtotime($item['updated_at'])); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-primary btn-action" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editModal"
                                                    data-id="<?php echo $item['id']; ?>"
                                                    data-product-code="<?php echo htmlspecialchars($item['product_code']); ?>"
                                                    data-location="<?php echo htmlspecialchars($item['location']); ?>"
                                                    data-quantity="<?php echo $item['quantity']; ?>"
                                                    data-remark="<?php echo htmlspecialchars($item['remark'] ?? ''); ?>">
                                                修改
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger btn-action" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteModal"
                                                    data-id="<?php echo $item['id']; ?>"
                                                    data-product-code="<?php echo htmlspecialchars($item['product_code']); ?>"
                                                    data-location="<?php echo htmlspecialchars($item['location']); ?>">
                                                删除
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 修改模态框 -->
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">修改库存</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="inventory_id" id="edit_inventory_id">
                        <input type="hidden" name="old_location" id="edit_old_location">
                        <input type="hidden" name="product_code" id="edit_product_code">
                        
                        <div class="mb-3">
                            <label class="form-label">产品编码</label>
                            <input type="text" id="edit_product_code_display" class="form-control" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">库位 <span class="text-danger">*</span></label>
                            <input type="text" name="location" id="edit_location" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">数量 <span class="text-danger">*</span></label>
                            <input type="number" name="quantity" id="edit_quantity" class="form-control" min="0" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">备注</label>
                            <input type="text" name="remark" id="edit_remark" class="form-control" placeholder="可选">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" name="edit_inventory" class="btn btn-primary">保存修改</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 删除确认模态框 -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">确认删除</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="inventory_id" id="delete_inventory_id">
                        <p>确定要删除以下库存记录吗？</p>
                        <p><strong>产品编码：</strong><span id="delete_product_code"></span></p>
                        <p><strong>库位：</strong><span id="delete_location"></span></p>
                        <p class="text-warning">删除后库存将移至回收站，可以从回收站恢复。</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" name="delete_inventory" class="btn btn-danger">确认删除</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 编辑模态框数据填充
        const editModal = document.getElementById('editModal');
        if (editModal) {
            editModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                document.getElementById('edit_inventory_id').value = button.getAttribute('data-id');
                document.getElementById('edit_old_location').value = button.getAttribute('data-location');
                document.getElementById('edit_product_code').value = button.getAttribute('data-product-code');
                document.getElementById('edit_product_code_display').value = button.getAttribute('data-product-code');
                document.getElementById('edit_location').value = button.getAttribute('data-location');
                document.getElementById('edit_quantity').value = button.getAttribute('data-quantity');
                document.getElementById('edit_remark').value = button.getAttribute('data-remark') || '';
            });
        }

        // 删除模态框数据填充
        const deleteModal = document.getElementById('deleteModal');
        if (deleteModal) {
            deleteModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                document.getElementById('delete_inventory_id').value = button.getAttribute('data-id');
                document.getElementById('delete_product_code').textContent = button.getAttribute('data-product-code');
                document.getElementById('delete_location').textContent = button.getAttribute('data-location');
            });
        }
    </script>
</body>
</html>

