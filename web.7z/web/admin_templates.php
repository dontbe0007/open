<?php
/**
 * 模板管理页面
 * 注意：此文件被admin_dashboard.php包含，变量$pdo, $user_id, $username已定义
 */
if (!function_exists('log_operation')) {
    require_once 'operation_logs_helper.php';
}
require_once 'template_loader.php';

$template_success = '';
$template_error = '';

// 处理模板切换
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['switch_template'])) {
    $new_template = $_POST['template'] ?? 'default';
    
    // 验证模板是否存在
    $available_templates = get_available_templates();
    if (!isset($available_templates[$new_template])) {
        $template_error = '选择的模板不存在！';
    } else {
        try {
            $pdo->beginTransaction();
            
            // 保存模板设置
            $stmt = $pdo->prepare("
                INSERT INTO site_settings (setting_key, setting_value) 
                VALUES ('site_template', ?)
                ON DUPLICATE KEY UPDATE setting_value = ?
            ");
            $stmt->execute([$new_template, $new_template]);
            
            $pdo->commit();
            
            // 记录操作日志
            $operation_logs_exists = false;
            try {
                $check_table = $pdo->query("SHOW TABLES LIKE 'operation_logs'");
                $operation_logs_exists = $check_table->rowCount() > 0;
            } catch (PDOException $e) {}
            
            if ($operation_logs_exists) {
                log_operation($pdo, $user_id, $username, 'update_settings', 'system', null, null,
                    "切换网站模板为：{$available_templates[$new_template]['name']}", null, null);
            }
            
            $template_success = '模板切换成功！当前使用：' . $available_templates[$new_template]['name'];
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $template_error = '切换失败：' . $e->getMessage();
        }
    }
}

// 获取当前模板
$current_template = get_current_template();
$available_templates = get_available_templates();
?>

<div class="content-header">
    <h2><i class="bi bi-palette"></i> 模板管理</h2>
</div>

<div class="content-body">
    <?php if (!empty($template_success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($template_success); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($template_error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($template_error); ?></div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-info-circle"></i> 当前模板</h5>
        </div>
        <div class="card-body">
            <?php if (isset($available_templates[$current_template])): ?>
                <div class="d-flex align-items-center mb-3">
                    <div class="flex-grow-1">
                        <h4><?php echo htmlspecialchars($available_templates[$current_template]['name']); ?></h4>
                        <p class="text-muted mb-0"><?php echo htmlspecialchars($available_templates[$current_template]['description']); ?></p>
                        <small class="text-muted">版本：<?php echo htmlspecialchars($available_templates[$current_template]['version']); ?> | 
                        作者：<?php echo htmlspecialchars($available_templates[$current_template]['author']); ?></small>
                    </div>
                    <div>
                        <span class="badge bg-success">当前使用</span>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-muted">当前模板：<?php echo htmlspecialchars($current_template); ?></p>
            <?php endif; ?>
        </div>
    </div>
    
    <form method="POST">
        <input type="hidden" name="switch_template" value="1">
        
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-grid"></i> 可用模板</h5>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <?php foreach ($available_templates as $template_key => $template_info): ?>
                    <div class="col-md-6">
                        <div class="card h-100 <?php echo $template_key == $current_template ? 'border-primary border-2' : ''; ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h5 class="card-title"><?php echo htmlspecialchars($template_info['name']); ?></h5>
                                        <p class="card-text text-muted small"><?php echo htmlspecialchars($template_info['description']); ?></p>
                                    </div>
                                    <?php if ($template_key == $current_template): ?>
                                        <span class="badge bg-primary">当前</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mb-3">
                                    <small class="text-muted">
                                        <i class="bi bi-tag"></i> 版本 <?php echo htmlspecialchars($template_info['version']); ?><br>
                                        <i class="bi bi-person"></i> <?php echo htmlspecialchars($template_info['author']); ?>
                                    </small>
                                </div>
                                
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="template" 
                                           id="template_<?php echo htmlspecialchars($template_key); ?>" 
                                           value="<?php echo htmlspecialchars($template_key); ?>"
                                           <?php echo $template_key == $current_template ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="template_<?php echo htmlspecialchars($template_key); ?>">
                                        选择此模板
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <div class="text-center">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-check-circle"></i> 应用模板
            </button>
            <a href="admin_dashboard.php?page=dashboard" class="btn btn-secondary btn-lg">
                <i class="bi bi-arrow-left"></i> 返回
            </a>
        </div>
    </form>
    
    <div class="card mt-4">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0"><i class="bi bi-lightbulb"></i> 使用提示</h5>
        </div>
        <div class="card-body">
            <ul class="mb-0">
                <li>切换模板后，所有页面将使用新模板的样式</li>
                <li>模板切换是即时生效的，无需重启服务器</li>
                <li>建议在切换前先预览效果</li>
                <li>如果新模板出现问题，可以随时切换回默认模板</li>
            </ul>
        </div>
    </div>
</div>


