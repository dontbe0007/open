<?php
/**
 * 网站底部通用文件
 * 显示底部Logo、版权信息、联系信息等
 */
if (!function_exists('get_site_setting')) {
    require_once 'get_site_setting.php';
}

// 获取底部相关设置
$footer_logo = get_site_setting('footer_logo', '');
$footer_text = get_site_setting('footer_text', '');
$footer_seo = get_site_setting('footer_seo', '');
$contact_phone = get_site_setting('contact_phone', '');
$contact_email = get_site_setting('contact_email', '');
$contact_address = get_site_setting('contact_address', '');
?>
<footer class="site-footer mt-5 py-4" style="background-color: #f8f9fa; border-top: 1px solid #dee2e6;">
    <div class="container">
        <div class="row">
            <!-- 底部Logo -->
            <?php if (!empty($footer_logo) && file_exists($footer_logo)): ?>
            <div class="col-md-3 text-center mb-3">
                <img src="<?php echo htmlspecialchars($footer_logo); ?>" alt="Logo" style="max-height: 60px;">
            </div>
            <?php endif; ?>
            
            <!-- 联系信息 -->
            <div class="col-md-<?php echo !empty($footer_logo) && file_exists($footer_logo) ? '6' : '9'; ?> mb-3">
                <h6 class="mb-2">联系信息</h6>
                <?php if (!empty($contact_phone)): ?>
                <p class="mb-1">📞 电话：<?php echo htmlspecialchars($contact_phone); ?></p>
                <?php endif; ?>
                <?php if (!empty($contact_email)): ?>
                <p class="mb-1">📧 邮箱：<a href="mailto:<?php echo htmlspecialchars($contact_email); ?>"><?php echo htmlspecialchars($contact_email); ?></a></p>
                <?php endif; ?>
                <?php if (!empty($contact_address)): ?>
                <p class="mb-1">📍 地址：<?php echo htmlspecialchars($contact_address); ?></p>
                <?php endif; ?>
            </div>
            
            <!-- 版权信息 -->
            <div class="col-md-<?php echo !empty($footer_logo) && file_exists($footer_logo) ? '3' : '3'; ?> text-md-end mb-3">
                <?php if (!empty($footer_text)): ?>
                <p class="mb-0 text-muted"><?php echo htmlspecialchars($footer_text); ?></p>
                <?php else: ?>
                <p class="mb-0 text-muted">&copy; <?php echo date('Y'); ?> 仓库管理系统 版权所有</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</footer>

<?php
// 输出底部SEO代码（在</body>之前）
if (!empty($footer_seo)) {
    echo $footer_seo;
}
?>

