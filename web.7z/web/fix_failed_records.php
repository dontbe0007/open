<?php
/**
 * 修复导入失败的记录
 * 手动插入那5条导入失败的记录
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$failed_records = [
    // ID: 8160
    [
        'id' => 8160,
        'plan_id' => 1296,
        'user_id' => 4,
        'outbound_quantity' => 111,
        'remark' => '106-106-吴-20-38-001',
        'photo_path' => null,
        'outbound_date' => '2025-09-02 00:00:00',
        'created_at' => '2025-09-02 20:37:57'
    ],
    // ID: 8354
    [
        'id' => 8354,
        'plan_id' => 1315,
        'user_id' => 4,
        'outbound_quantity' => 203,
        'remark' => '202',
        'photo_path' => null,
        'outbound_date' => '2025-09-05 00:00:00',
        'created_at' => '2025-09-05 06:09:31'
    ],
    // ID: 8948
    [
        'id' => 8948,
        'plan_id' => 1391,
        'user_id' => 4,
        'outbound_quantity' => 390,
        'remark' => '247-247-010',
        'photo_path' => null,
        'outbound_date' => '2025-09-14 01:45:31',
        'created_at' => '2025-09-14 01:45:31'
    ],
    // ID: 10168
    [
        'id' => 10168,
        'plan_id' => 1537,
        'user_id' => 4,
        'outbound_quantity' => 330,
        'remark' => '042-005',
        'photo_path' => null,
        'outbound_date' => '2025-10-03 14:41:43',
        'created_at' => '2025-10-03 14:41:43'
    ],
    // ID: 10223
    [
        'id' => 10223,
        'plan_id' => 1543,
        'user_id' => 4,
        'outbound_quantity' => 200,
        'remark' => '394',
        'photo_path' => null,
        'outbound_date' => '2025-10-04 08:26:05',
        'created_at' => '2025-10-04 08:26:05'
    ]
];

echo "<h2>修复失败的记录</h2>";
echo "<pre>";

$success_count = 0;
$error_count = 0;
$errors = [];

try {
    $pdo->beginTransaction();
    
    foreach ($failed_records as $record) {
        try {
            // 检查记录是否已存在
            $check = $pdo->prepare("SELECT id FROM outbound_records WHERE id = ?");
            $check->execute([$record['id']]);
            
            if ($check->fetch()) {
                echo "记录 ID {$record['id']} 已存在，跳过\n";
                continue;
            }
            
            // 插入记录
            $stmt = $pdo->prepare("
                INSERT INTO outbound_records 
                (id, plan_id, user_id, outbound_quantity, remark, photo_path, outbound_date, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $record['id'],
                $record['plan_id'],
                $record['user_id'],
                $record['outbound_quantity'],
                $record['remark'],
                $record['photo_path'],
                $record['outbound_date'],
                $record['created_at']
            ]);
            
            $success_count++;
            echo "✓ 成功插入记录 ID {$record['id']}\n";
            
        } catch (PDOException $e) {
            $error_count++;
            $error_msg = "记录 ID {$record['id']} 插入失败: " . $e->getMessage();
            $errors[] = $error_msg;
            echo "✗ {$error_msg}\n";
        }
    }
    
    $pdo->commit();
    
    echo "\n";
    echo "========================================\n";
    echo "修复完成！\n";
    echo "成功: {$success_count} 条\n";
    echo "失败: {$error_count} 条\n";
    
    if (!empty($errors)) {
        echo "\n错误详情:\n";
        foreach ($errors as $error) {
            echo "  - {$error}\n";
        }
    }
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "发生错误: " . $e->getMessage() . "\n";
}

echo "</pre>";

echo "<p><a href='index.php' class='btn btn-primary'>返回主页</a></p>";
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修复失败的记录</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        pre {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- PHP输出内容会显示在这里 -->
    </div>
</body>
</html>




